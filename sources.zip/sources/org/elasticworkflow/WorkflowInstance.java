package org.elasticworkflow;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.cloudbus.cloudsim.Log;

import java.util.HashMap;

/**
 * WorkflowInstance is used to organize each workflow
 * @author added by Zhicheng Cai
 *
 */
public class WorkflowInstance {
	
	private String Name;
	private boolean finished=false;
	/**
	 * cluster �ļ���
	 */
	private HashMap<String,Cluster> clustermap=new HashMap<String,Cluster>();
	/**
	 * The list of tasks of this workflow
	 */
	private List<Task> taskList;
	  public boolean isFinished() {
		return finished;
	}

	public void setFinished(boolean finished) {
		this.finished = finished;
		
	}
	/**
     * The list of jobs submitted to broker.
     */
    protected List<Task> jobsSubmittedList;
    /**
     * The jobs have been completed.
     */
    protected List<Task> jobsCompletedList;
    
    /**
     * root tasks
     */
    private List<Task> roots = new ArrayList<>();
    
    /**
     * end tasks
     */
    private List<Task> ends = new ArrayList<>();
    /**
	 * Unique id of the workflow
	 */
	private int workflowid;
	/**
	 * Priority of the workflow
	 */
	private int priority;
    

	public List<Task> getRoots() {
		return roots;
	}

	public void AddRoot(Task root) {
		this.roots.add(root);
	}

	public List<Task> getEnds() {
		return ends;
	}

	public void AddEnds(Task end) {
		this.ends.add(end);
	}
	/**
     * this list contains which tasks will use the file
     * String filename
     * List<Task> task list
     */
    private Map<String, List<Task>> usedbytasksmap;
    
    /**
     * Clear the execution state for the next execution
     */
    public void ClearState()
    {
    	for(Task tsk:getTaskList())
		{
			try {
				if(!tsk.RecoveryCloudletlength())
				{
					Log.printLine("����"+tsk.getTaskname()+"û�ָܻ�ԭʼִ��ʱ��");
				}
				tsk.setCloudletStatus(0);
				tsk.setCloudletFinishedSoFar(0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
    	jobsCompletedList.clear();
		jobsSubmittedList.clear();
		setFinished(false);
		usedbytasksmap.clear();
    }
    public String getName() {
		return Name;
	}
	/**
     * Release time of the workflow
     */
	private double relaeasetime;
	
	public WorkflowInstance(int workflowid,String Name) {
		super();
		taskList=new ArrayList<>();
		jobsSubmittedList=new ArrayList<>();
		jobsCompletedList=new ArrayList<>();
		usedbytasksmap=new HashMap<String, List<Task>>();
		this.workflowid = workflowid;
		this.Name=Name;
	}
	
	/**
	 * Register that the file with filename is used by Task tsk
	 * @param filename
	 * @param tsk
	 */
	public void AddFileUsedbyTaskMap(String filename, Task tsk)
	{
		if(usedbytasksmap.containsKey(filename))
		{
			List<Task> tasklist=usedbytasksmap.get(filename);
			tasklist.add(tsk);
		}
		else
		{
			List<Task> tasklist=new ArrayList<>();
			tasklist.add(tsk);
			usedbytasksmap.put(filename, tasklist);
		}
	}
	
	/**
	 * Check the file with filename will be used by which tasks
	 * @param filename
	 * @return
	 */
	public List<Task> getFileUsedbyTasks(String filename)
	{
		if(usedbytasksmap.containsKey(filename))
		{
			return usedbytasksmap.get(filename);
		}
		else
		{
			return null;
		}
	}
	/**
	 * The workflow deadline
	 */
	private double deadline;
	public List<Task> getTaskList() {
		return taskList;
	}
	
	public List<Task> getJobsSubmittedList() {
		return jobsSubmittedList;
	}
	
	public List<Task> getJobsCompletedList() {
		return jobsCompletedList;
	}
	
	public double getRelaeasetime() {
		return relaeasetime;
	}
	public void setRelaeasetime(double relaeasetime) {
		this.relaeasetime = relaeasetime;
	}
	public double getDeadline() {
		return deadline;
	}
	public void setDeadline(double deadline) {
		this.deadline = deadline;
	}
	public int getWorkflowid() {
		return workflowid;
	}

	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	
	/**
	 * ��������һ������˳��Ϊ����������
	 */
	public void CalculateIndexs()
	{
		HashSet<Task> set=new HashSet<Task>();
		int index=1;
		while(set.size()<this.getTaskList().size())
		{
			for(Task ctsk:this.getTaskList())
			{
				if(set.contains(ctsk))
					continue;
				if(set.containsAll(ctsk.getParentList()))
				{
					ctsk.setIndex(index++);	
					set.add(ctsk);
				}
				else if(ctsk.getParentList().size()==0)
				{
					ctsk.setIndex(index++);	
					set.add(ctsk);
				}
			}
		}
		ConstructCluster();
	}
	/**
	 * ��������Ԫ
	 */
	public void ConstructCluster()
	{
		for(Task tsk:getTaskList())
		{
			String key=tsk.getType()+"_"+tsk.getDepth();
			if(this.clustermap.containsKey(key))
			{
				if(!this.clustermap.get(key).AddTask(tsk))
				{
					Log.printLine("ERROR:ConstructCluster");
				}
			}
			else
			{
				Cluster cluster=new Cluster(tsk.getType(),tsk.getDepth());
				cluster.AddTask(tsk);
				this.clustermap.put(key, cluster);
			}
		}
	}

}
