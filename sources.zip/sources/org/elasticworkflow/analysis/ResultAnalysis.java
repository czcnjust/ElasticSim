package org.elasticworkflow.analysis;

import java.io.File;
import java.io.FileFilter;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.cloudbus.cloudsim.Log;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.FileDialog;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

public class ResultAnalysis {

	private class Reitem
	{
		String distributiontype;
		String pricinginterval;
		String maxdev;
		String deadlinefactor;
		String instancename;
		String staticcost;
		String actualcost;
		String deadline;
		String staticfinishtime;
		String actualfinishtime;
	}
	public void Analysis()
	{
		 DirectoryDialog dialog=new DirectoryDialog(new Shell(),SWT.NONE);
		 dialog.setMessage("ѡ�����������ļ���");
		 String dir=dialog.open();
		File files = new File(dir);
		FileFilter filefilter = new FileFilter() {

			public boolean accept(File file) {
				//if the file extension is .txt return true, else false
				if (file.getName().endsWith(".xml")) {
					return true;
				}
				return false;
			}
		};
		List<Reitem> relist=new ArrayList<Reitem>();
		File[] filelist = files.listFiles(filefilter);
		for(File file:filelist)
		{
			Reitem re=AnalysisAFile(file.getAbsolutePath());
			relist.add(re);
		}
		OutpurResult(relist);
	}
	public ResultAnalysis() {
		// TODO Auto-generated constructor stub
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ResultAnalysis an=new ResultAnalysis();
		an.Analysis();
	}
	private void OutpurResult(List<Reitem> relist)
	{
		Workbook wb = new XSSFWorkbook();
		
	    Map<String, CellStyle> styles = createStyles(wb);
	    Sheet sheet = wb.createSheet("Uncertain");
	    //turn off gridlines
	    sheet.setDisplayGridlines(false);
	    sheet.setPrintGridlines(false);
	    sheet.setFitToPage(true);
	    sheet.setHorizontallyCenter(true);
	    PrintSetup printSetup = sheet.getPrintSetup();
	    printSetup.setLandscape(true);
	    String[] titles={"distributiontype","pricinginterval","maxdev","deadlinefactor",
	    		"instancename","staticcost","actualcost","increasecost_per","deadline","staticfinishtime","actualfinishtime","increasemakspan_per"};
	 
	    //the header row: centered text in 48pt font
        Row headerRow = sheet.createRow(0);
        headerRow.setHeightInPoints(12.75f);
        for (int i = 0; i < titles.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(titles[i]);
            cell.setCellStyle(styles.get("header"));
            sheet.setColumnWidth(i, 256*(titles[i].length()+3));
        }
        //freeze the first row
        sheet.createFreezePane(4, 1); 
        Row row;
        Cell cell;
        
        int rownum = 1;
        for(int i=0;i<relist.size();i++)
        {
        	row = sheet.createRow(rownum++);
        	Reitem item=relist.get(i);
        	int colnum=0;
        	//distributiontype
			cell = row.createCell(colnum++);
			cell.setCellValue(item.distributiontype);
			
			//pricinginterval
			cell = row.createCell(colnum++);
			cell.setCellValue(item.pricinginterval);
			
			//maxdev
			cell = row.createCell(colnum++);
			cell.setCellValue(item.maxdev);
			
			//deadlinefactor
			cell = row.createCell(colnum++);
			cell.setCellValue(item.deadlinefactor);
			
			//instancename
			cell = row.createCell(colnum++);
			cell.setCellValue(item.instancename);
			
			//staticcost
			cell = row.createCell(colnum++);
			cell.setCellStyle(styles.get("input_double"));
			cell.setCellValue(item.staticcost);
			
			//actualcost
			cell = row.createCell(colnum++);
			cell.setCellStyle(styles.get("input_double"));
			cell.setCellValue(item.actualcost);
			
			//actualcost
			cell = row.createCell(colnum++);
			cell.setCellStyle(styles.get("input_double"));
			double addper=(Double.valueOf(item.actualcost)-Double.valueOf(item.staticcost))/Double.valueOf(item.staticcost);
			cell.setCellValue(addper);
			
			//deadline
			cell = row.createCell(colnum++);
			cell.setCellStyle(styles.get("input_double"));
			cell.setCellValue(item.deadline);
			
			//staticfinishtime
			cell = row.createCell(colnum++);
			cell.setCellStyle(styles.get("input_double"));
			cell.setCellValue(item.staticfinishtime);
			
			//actualfinishtime
			cell = row.createCell(colnum++);
			cell.setCellStyle(styles.get("input_double"));
			cell.setCellValue(item.actualfinishtime);
			Log.printLine(item.instancename);
			
			double addmakespanper=(Double.valueOf(item.actualfinishtime)-Double.valueOf(item.staticfinishtime))/Double.valueOf(item.staticfinishtime);
			//actualfinishtime
			cell = row.createCell(colnum++);
			cell.setCellStyle(styles.get("input_double"));
			cell.setCellValue(addmakespanper);
		
			/*if(i==1000000)//||i==20000||i==30000||i==40000||i==50000)
			{
				try
				{
					String file = "D:\\ʵ������\\ʵ����\\��ȷ�����㷨���Cybershake16.4.6\\����\\UncertainResult"+i+".xls";
					if(wb instanceof XSSFWorkbook) file += "x";
					FileOutputStream out = new FileOutputStream(file);
					wb.write(out);
					out.close();
					
					//cur=0;
					sheet=null;
					wb=null;
					System.gc();
					wb = new XSSFWorkbook();
					sheet = wb.createSheet("SUAH");
					styles = createStyles(wb);
				    //turn off gridlines
				    sheet.setDisplayGridlines(false);
				    sheet.setPrintGridlines(false);
				    sheet.setFitToPage(true);
				    sheet.setHorizontallyCenter(true);
				    printSetup = sheet.getPrintSetup();
				    printSetup.setLandscape(true);
				 
				  
				    //the header row: centered text in 48pt font
			        headerRow = sheet.createRow(0);
			        headerRow.setHeightInPoints(12.75f);
			        for (int k = 0; k < titles.length; k++) {
			            cell = headerRow.createCell(k);
			            cell.setCellValue(titles[k]);
			            cell.setCellStyle(styles.get("header"));
			            sheet.setColumnWidth(k, 256*(titles[k].length()+3));
			        }
			        //freeze the first row
			        sheet.createFreezePane(4, 1); 
			        rownum=1;
			        
				}catch(Exception e)
				{
					
				}
			}*/
        }
        try
		{
        	FileDialog fileitem=new FileDialog(new Shell(),SWT.NONE);
        	
			String file = fileitem.open();
			if(wb instanceof XSSFWorkbook) file += "x";
			FileOutputStream out = new FileOutputStream(file);
			wb.write(out);
			out.close();
		}catch(Exception e)
		{
			
		}
	}
	private Reitem AnalysisAFile(String xmlfile)
	{
		Reitem result=new Reitem();
		  SAXBuilder builder = new SAXBuilder();
          try {
			//parse using builder to get DOM representation of the XML file
			Document dom = builder.build(new File(xmlfile));
			Element root = dom.getRootElement();
		
						
						result.distributiontype = root.getAttributeValue("distributiontype");
						result.pricinginterval = root.getAttributeValue("pricinginterval");
						result.maxdev = root.getAttributeValue("maxdev");
						result.deadlinefactor = root.getAttributeValue("deadlinefactor");
						result.instancename = root.getAttributeValue("InstanceName");
						List<Element> clist=root.getChildren();
						for (Element cnode : clist) 
						{
							switch (cnode.getName().toLowerCase()) 
							{
								case "staticcost":
									result.staticcost =cnode.getText();
									break;
								case "actualcost":
									result.actualcost =cnode.getText();
									break;
								case "deadline":
									result.deadline =cnode.getText();
									break;
								case "staticfinishtime":
									result.staticfinishtime =cnode.getText();
									break;
								case "actualfinishtime":
									result.actualfinishtime =cnode.getText();
									break;
							}
						}
						
			return result;
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
	}
	  /**
     * create a library of cell styles
     */
    private  Map<String, CellStyle> createStyles(Workbook wb){
        Map<String, CellStyle> styles = new HashMap<String, CellStyle>();
        CellStyle style;
        Font titleFont = wb.createFont();
        titleFont.setFontHeightInPoints((short)14);
        titleFont.setFontName("Trebuchet MS");
        style = wb.createCellStyle();
        style.setFont(titleFont);
        style.setBorderBottom(CellStyle.BORDER_DOTTED);
        style.setBottomBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        styles.put("title", style);
        
        Font headerFont = wb.createFont();
        headerFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
        style = createBorderedStyle(wb);
        style.setAlignment(CellStyle.ALIGN_CENTER);
        style.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        style.setFont(headerFont);
        styles.put("header", style);
        
        Font itemFont = wb.createFont();
        itemFont.setFontHeightInPoints((short)9);
        itemFont.setFontName("Trebuchet MS");
        style = wb.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_LEFT);
        style.setFont(itemFont);
        styles.put("item_left", style);

        style = wb.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_RIGHT);
        style.setFont(itemFont);
        styles.put("item_right", style);

        style = wb.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_RIGHT);
        style.setFont(itemFont);
        style.setBorderRight(CellStyle.BORDER_DOTTED);
        style.setRightBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderBottom(CellStyle.BORDER_DOTTED);
        style.setBottomBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderLeft(CellStyle.BORDER_DOTTED);
        style.setLeftBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderTop(CellStyle.BORDER_DOTTED);
        style.setTopBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setDataFormat(wb.createDataFormat().getFormat("_($* #,##0.00_);_($* (#,##0.00);_($* \"-\"??_);_(@_)"));
        styles.put("input_$", style);

        style = wb.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_RIGHT);
        style.setFont(itemFont);
        style.setBorderRight(CellStyle.BORDER_DOTTED);
        style.setRightBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderBottom(CellStyle.BORDER_DOTTED);
        style.setBottomBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderLeft(CellStyle.BORDER_DOTTED);
        style.setLeftBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderTop(CellStyle.BORDER_DOTTED);
        style.setTopBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        style.setDataFormat(wb.createDataFormat().getFormat("0.000%"));
        styles.put("input_%", style);

        style = wb.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_RIGHT);
        style.setFont(itemFont);
        style.setBorderRight(CellStyle.BORDER_DOTTED);
        style.setRightBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderBottom(CellStyle.BORDER_DOTTED);
        style.setBottomBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderLeft(CellStyle.BORDER_DOTTED);
        style.setLeftBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderTop(CellStyle.BORDER_DOTTED);
        style.setTopBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setDataFormat(wb.createDataFormat().getFormat("0.00"));
        styles.put("input_double", style);

        style = wb.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_CENTER);
        style.setFont(itemFont);
        style.setDataFormat(wb.createDataFormat().getFormat("m/d/yy"));
        styles.put("input_d", style);

        style = wb.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_RIGHT);
        style.setFont(itemFont);
        style.setBorderRight(CellStyle.BORDER_DOTTED);
        style.setRightBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderBottom(CellStyle.BORDER_DOTTED);
        style.setBottomBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderLeft(CellStyle.BORDER_DOTTED);
        style.setLeftBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderTop(CellStyle.BORDER_DOTTED);
        style.setTopBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setDataFormat(wb.createDataFormat().getFormat("$##,##0.00"));
        style.setBorderBottom(CellStyle.BORDER_DOTTED);
        style.setBottomBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        styles.put("formula_$", style);

        style = wb.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_RIGHT);
        style.setFont(itemFont);
        style.setBorderRight(CellStyle.BORDER_DOTTED);
        style.setRightBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderBottom(CellStyle.BORDER_DOTTED);
        style.setBottomBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderLeft(CellStyle.BORDER_DOTTED);
        style.setLeftBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBorderTop(CellStyle.BORDER_DOTTED);
        style.setTopBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setDataFormat(wb.createDataFormat().getFormat("0"));
        style.setBorderBottom(CellStyle.BORDER_DOTTED);
        style.setBottomBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        styles.put("formula_i", style);

        return styles;
    }

    private  CellStyle createBorderedStyle(Workbook wb){
        CellStyle style = wb.createCellStyle();
        style.setBorderRight(CellStyle.BORDER_THIN);
        style.setRightBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderBottom(CellStyle.BORDER_THIN);
        style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderLeft(CellStyle.BORDER_THIN);
        style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderTop(CellStyle.BORDER_THIN);
        style.setTopBorderColor(IndexedColors.BLACK.getIndex());
        return style;
    }
}
