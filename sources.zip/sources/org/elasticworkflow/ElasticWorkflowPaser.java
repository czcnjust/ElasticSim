package org.elasticworkflow;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.elasticworkflow.SystemParameters.DistributionType;
import org.elasticworkflow.SystemParameters.*;
import org.cloudbus.cloudsim.Log;
import org.elasticworkflow.SystemParameters.FileType;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.elasticworkflow.stochasticruntime.*;
public class ElasticWorkflowPaser{


	public ElasticWorkflowPaser(int userId) {
		super();
		 this.jobIdStartsFrom = 1;
		 workflowstartid=1;
	      /**
	         * @author Zhicheng Cai
	       */
		 workflowList=new ArrayList<>();
		 this.userId = userId;
		 this.mName2Task = new HashMap<>();
	}
	/**
	 * The workflow list for executing
	 * @author Zhicheng Cai
	 */
	protected List<WorkflowInstance> workflowList;
    public List<WorkflowInstance> getWorkflowList() {
		return workflowList;
	}

	/**
	 * The workflow unique id counter
	 */
	private int workflowstartid=1;
	
    /**
     * All tasks.
     */
    private List<Task> taskList;
    /**
     * User id. used to create a new task.
     */
    private final int userId;

    /**
     * current job id. In case multiple workflow submission
     */
    private int jobIdStartsFrom;

 
    /**
     * Map from task name to task.
     */
    protected Map<String, Task> mName2Task;

   
    /**
     * Start to parse a workflow which is a xml file(s).
     */
    public WorkflowInstance parse(String daxPath) {
        if (daxPath != null) {
        	WorkflowInstance winstance=parseXmlFile(daxPath);
           return winstance;
        } 
        else
        	return null;
    }
    /**
     * Start to parse workflows which is a set of xml files.
     */
    public List<WorkflowInstance>  parse(List<String> daxPaths) {
        if (daxPaths != null) {
        	List<WorkflowInstance> workflowList=new ArrayList<>();
            for (String path : daxPaths) {
            	WorkflowInstance wfinstance= parseXmlFile(path);
            	if(wfinstance!=null)
            		workflowList.add(wfinstance);
            }
            return workflowList;
        }
        else
        	return null;
    }

    /**
     * Sets the depth of a task
     *
     * @param task the task
     * @param depth the depth
     */
    private void setDepth(Task task, int depth) {
        if (depth > task.getDepth()) {
            task.setDepth(depth);
        }
        for (Task cTask : task.getChildList()) {
            setDepth(cTask, task.getDepth() + 1);
        }
    }

    /**
     * Parse a DAX file with jdom
     */
    private WorkflowInstance parseXmlFile(String path) {

        try {
        	File xmlfile=new File(path);
        	WorkflowInstance wfinstance=new WorkflowInstance(workflowstartid++,xmlfile.getName());
            SAXBuilder builder = new SAXBuilder();
            //parse using builder to get DOM representation of the XML file
            Document dom = builder.build(xmlfile);
            Element root = dom.getRootElement();
            List<Element> list = root.getChildren();
            for (Element node : list) {
                switch (node.getName().toLowerCase()) {
                    case "job":
                        long length = 0;
                        String nodeName = node.getAttributeValue("id");
                        String nodeType = node.getAttributeValue("name");
                        /**
                         * capture runtime. If not exist, by default the runtime
                         * is 0.1. Otherwise CloudSim would ignore this task.
                         * BUG/#11
                         */
                        double runtime;
                        if (node.getAttributeValue("runtime") != null) {
                            String nodeTime = node.getAttributeValue("runtime");
                            //this is a bug of CloudSim if the runtime is smaller than 0.1 (now is 0.01) it doesn't work at all
                            runtime = Double.parseDouble(nodeTime);
                         
                            runtime = 20000 *runtime;//
                            if (runtime < 500) {//if maxdev=0.5��the runtime will not <0.01
                                runtime = 500;
                            }
                            length = (long) runtime;
                        } else {
                            Log.printLine("Cannot find runtime for " + nodeName + ",set it to be 0");
                        }   //multiple the scale, by default it is 1.0
                        length *= SystemParameters.getRuntimeScale();
                        List<Element> fileList = node.getChildren();
                        List<FileItem> mFileList = new ArrayList<>();
                        for (Element file : fileList) {
                            if (file.getName().toLowerCase().equals("uses")) {
                                String fileName = file.getAttributeValue("name");//DAX version 3.3
                                if (fileName == null) {
                                    fileName = file.getAttributeValue("file");//DAX version 3.0
                                }
                                if (fileName == null) {
                                    Log.print("Error in parsing xml");
                                }

                                String inout = file.getAttributeValue("link");
                                double size = 0.0;

                                String fileSize = file.getAttributeValue("size");
                                if (fileSize != null) {
                                    size = Double.parseDouble(fileSize) /*/ 1024*/;
                                } else {
                                    Log.printLine("File Size not found for " + fileName);
                                }

                                /**
                                 * a bug of cloudsim, size 0 causes a problem. 1
                                 * is ok.
                                 */
                                if (size == 0) {
                                    size++;
                                }
                                /**
                                 * Sets the file type 1 is input 2 is output
                                 */
                                FileType type = FileType.NONE;
                                switch (inout) {
                                    case "input":
                                        type = FileType.INPUT;
                                        break;
                                    case "output":
                                        type = FileType.OUTPUT;
                                        break;
                                    default:
                                        Log.printLine("Parsing Error");
                                        break;
                                }
                                FileItem tFile;
                                /*
                                 * Already exists an input file (forget output file)
                                 */
                                if (size < 0) {
                                    /*
                                     * Assuming it is a parsing error
                                     */
                                    size = 0 - size;
                                    Log.printLine("Size is negative, I assume it is a parser error");
                                }
                                /*
                                 * Note that CloudSim use size as MB, in this case we use it as Byte
                                 */
                                if (type == FileType.OUTPUT) {
                                    /**
                                     * It is good that CloudSim does tell
                                     * whether a size is zero
                                     */
                                    tFile = new FileItem(fileName, size);
                                } else if (SystemSetting.containsFile(fileName)) {
                                    tFile = SystemSetting.getFile(fileName);
                                } else {

                                    tFile = new FileItem(fileName, size);
                                    SystemSetting.setFile(fileName, tFile);
                                }

                                tFile.setType(type);
                                mFileList.add(tFile);

                            }
                        }
                        Task task;
                        //In case of multiple workflow submission. Make sure the jobIdStartsFrom is consistent.
                        synchronized (this) {
                        	
                        	switch(SystemParameters.getSeltype())
                        	{
                        		case Uniform:
                        			UniformDistribution	uniobj=new UniformDistribution(SystemParameters.getMaxdev());
                        		
                        			uniobj.setSeedTime(length);
                        			
                        			task = new Task(this.jobIdStartsFrom, length);
                        			task.setDistributeobj(uniobj);
                        			break;
                        		case Gaussian:
                        			GaussianDistribution gausobj=new GaussianDistribution(SystemParameters.getTao(),SystemParameters.getMaxdev());
                        			gausobj.setSeedTime(length);
                        			task = new Task(this.jobIdStartsFrom, length);
                        			task.setDistributeobj(gausobj);
                        			break;
                        		case Undefined:
                        			task = new Task(this.jobIdStartsFrom, length);
                        			break;
                        		default:
                        				task = new Task(this.jobIdStartsFrom, length);
                        	}
                           
                            this.jobIdStartsFrom++;
                        }
                        task.setType(nodeType);
                        task.setUserId(userId);
                        task.setTaskname(nodeName);
                        mName2Task.put(nodeName, task);
                        for (FileItem file : mFileList) {
                            task.addRequiredFile(file.getName());
                            /**
                             * Register the file will be used by which tasks
                             * @author Zhicheng Cai
                             */
                            if(file.getType()==FileType.INPUT)
                            {
                            	wfinstance.AddFileUsedbyTaskMap(file.getName(), task);
                            }
                        }
                        task.setFileList(mFileList);
                        task.setParent(wfinstance);
                        wfinstance.getTaskList().add(task);

                        /**
                         * Add dependencies info.
                         */
                        break;
                    case "child":
                        List<Element> pList = node.getChildren();
                        String childName = node.getAttributeValue("ref");
                        if (mName2Task.containsKey(childName)) {

                            Task childTask = (Task) mName2Task.get(childName);

                            for (Element parent : pList) {
                                String parentName = parent.getAttributeValue("ref");
                                if (mName2Task.containsKey(parentName)) {
                                    Task parentTask = (Task) mName2Task.get(parentName);
                                    parentTask.addChild(childTask);
                                    childTask.addParent(parentTask);
                                }
                            }
                        }
                        break;
                }
            }
            Task start=new Task(this.jobIdStartsFrom, 2);
            this.jobIdStartsFrom++;
            start.setType("SourceNode");
            start.setUserId(userId);
            start.setTaskname("start");
            start.setParent(wfinstance);
            wfinstance.getTaskList().add(start);
            wfinstance.AddRoot(start);
            
            
            Task end=new Task(this.jobIdStartsFrom, 2);
            this.jobIdStartsFrom++;
            end.setType("EndNode");
            end.setUserId(userId);
            end.setTaskname("end");
            end.setParent(wfinstance);
            wfinstance.getTaskList().add(end);
            wfinstance.AddEnds(end);
            
            /**
             * If a task has no parent, then it is root task.
             */
         
            for (Task task : mName2Task.values()) {
                task.setDepth(0);
                if (task.getParentList().isEmpty()) {
                  
                    start.addChild(task);
                    task.addParent(start);
                }
            }
            for (Task task : mName2Task.values()) {
                
                if (task.getChildList().isEmpty()) {
                 
                    
                    task.addChild(end);
                    end.addParent(task);
                }
            }
            /**
             * Add depth from top to bottom.
             */
            for (Iterator it =wfinstance.getRoots().iterator(); it.hasNext();) {
                Task task = (Task) it.next();
                setDepth(task, 1);
            }
            //������������������
            wfinstance.CalculateIndexs();
            
            wfinstance.setRelaeasetime(0);
            
           
       
            /**
             * Clean them so as to save memory. Parsing workflow may take much
             * memory
             */
            this.mName2Task.clear();
            return wfinstance;

        } catch (JDOMException jde) {
            Log.printLine("JDOM Exception;Please make sure your dax file is valid");

        } catch (IOException ioe) {
            Log.printLine("IO Exception;Please make sure dax.path is correctly set in your config file");

        } catch (Exception e) {
            e.printStackTrace();
            Log.printLine("Parsing Exception");
        }
        return null;
    }
}
