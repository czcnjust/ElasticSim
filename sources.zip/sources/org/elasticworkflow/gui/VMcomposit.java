package org.elasticworkflow.gui;

import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.HashMap;
import org.cloudbus.cloudsim.CloudletScheduler;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.ResCloudlet;
import org.cloudbus.cloudsim.core.CloudSim;
import org.eclipse.swt.widgets.Composite;
import org.elasticworkflow.SystemSetting;
import org.elasticworkflow.Task;
import org.elasticworkflow.intervalpricing.IntervalPricingVM;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Label;
import swing2swt.layout.FlowLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;

public class VMcomposit extends Composite {

	private IntervalPricingVM vm;
	//�ؼ��߶ȣ���λΪ����
	/**
	 * �ؼ��߶ȣ���λΪ����
	 */
	private int height=20;
	/**
	 * ������������һ��task
	 */
	private Task lasttask=null;
	//�ؼ����ȣ���λΪ����
	/**
	 * �ؼ����ȣ���λΪ����
	 */
	private int width=0;
    private double pixrate=SystemSetting.getPixrate();
	
	/**
	 * �����Ѿ�ִ�й��������б�
	 */
	private ArrayList<Label> btlist=new ArrayList<Label>();
	
	/**
	 * ����button��ӳ��
	 */
	private HashMap<ResCloudlet,Label> btmap=new HashMap<ResCloudlet,Label>();

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public VMcomposit(Composite parent, int style,IntervalPricingVM pvm) {
		super(parent, style);
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
			}
		});
		setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		addPaintListener(new PaintListener() {
			public void paintControl(PaintEvent e) {
				M_paintControl(e);
			}
		});
		this.vm=pvm;
		width=0;
		this.setSize(257, 64);
		setLayout(null);
		
		
		

		
	
	}

	public IntervalPricingVM getVm() {
		return vm;
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
	public void UpdateTasks()
	{
		CloudletScheduler taskscheduler = vm.getCloudletScheduler();
		List<? extends ResCloudlet> cloudletExecList=taskscheduler.getCloudletExecList();
		//List<? extends ResCloudlet> cloudletWaitingList=taskscheduler.getCloudletWaitingList();
		boolean fresh=false;
		for(ResCloudlet reclet:cloudletExecList )
		{
			if(btmap.containsKey(reclet))
			{
				continue;
			}
		
			int width=(int)(reclet.getCloudletLength()/vm.getMips());
			double exetime=reclet.getCloudletLength()/vm.getMips();
			width=(int)Math.round(width*pixrate);
			if(width==0)
				width=1;
			int startx= (int)Math.round((reclet.getExecStartTime()-vm.getPricemodel().getPricingStarttime())*pixrate);
			double finishtime=reclet.getExecStartTime()+exetime;
			Label lblNewLabel = new Label(this, SWT.BORDER);
			//lblNewLabel.setBounds(63, 133, 80, 27);
			//lblNewLabel.setText("New Label");
			
			//Button btnNewButton_1 = new Button(this, SWT.FLAT);
			lblNewLabel.setBounds(startx, 0, width, height);
			double largestpox=startx+width;
		
			lasttask=(Task)reclet.getCloudlet();
			lblNewLabel.setText(lasttask.getTaskname());
			btlist.add(lblNewLabel);
			this.btmap.put(reclet, lblNewLabel);
			lblNewLabel.setData(reclet);
			lblNewLabel.setToolTipText("Tasktype:"+lasttask.getType()+",TaskName:"+lasttask.getTaskname()
			+"exetime:"+exetime+",Starttime:"+reclet.getExecStartTime()+",Finishtime:"+finishtime
			+",Deadline:"+lasttask.getTaskdeadline());
			Color bcolor= null;
			if(SystemSetting.getColorMap().containsKey(lasttask.getType()))
			{
				bcolor=SystemSetting.getColorMap().get(lasttask.getType());
			}
			else
			{
				Random r = new Random();
				bcolor= new Color(getDisplay(),r.nextInt(250), r.nextInt(250), r.nextInt(250));
				SystemSetting.getColorMap().put(lasttask.getType(), bcolor);
			}
			lblNewLabel.setBackground(bcolor);
			fresh=true;
		}
		String tasks="";
		for(int i=0;i<btlist.size();i++)
			tasks+=btlist.get(i).getText()+";";
		this.setToolTipText(tasks);
		int its=1;
		if(lasttask!=null&&!fresh)
		{
			return;
		}
		
		if(lasttask!=null)
		{
			double ltfinishtime=lasttask.getExecStartTime()+lasttask.getCloudletLength()/vm.getMips();
			
			its=(int)Math.ceil((ltfinishtime-vm.getPricemodel().getPricingStarttime())/vm.getPricemodel().getLengthofPriceInterval());
			//if(CloudSim.clock()-vm.getPricemodel().getPricingStarttime()==its*vm.getPricemodel().getLengthofPriceInterval())
			//	its++;
			// Log.printLine("its:"+its);
		}	
			int width=(int)Math.round(its*vm.getPricemodel().getLengthofPriceInterval()*this.pixrate);
			this.setSize(width, height+10);
		/*	Log.printLine("this.getBounds().width"+this.getBounds().width);
			if(this.getParent().getBounds().width<this.getBounds().x+this.getBounds().width+10)
			{
				this.getParent().setBounds(this.getParent().getBounds().x,this.getParent().getBounds().y,this.getBounds().x+this.getBounds().width+10, this.getParent().getBounds().height);
			
			    Log.printLine("this.getParent().getBounds()"+this.getParent().getBounds());
			  
			}*/
	//	this.getParent().getParent().setSize(this.getParent().getBounds().width+2, this.getParent().getBounds().height+2);
	}
	public void M_paintControl(PaintEvent e) {
		Color linecolor = new Color(this.getDisplay(),255, 255, 255);
		e.gc.setBackground(linecolor);
		e.gc.setLineWidth(2);
		int hourpoint=0;
		while(hourpoint<this.getBounds().width)
		{
			
			e.gc.drawLine(hourpoint, 0, hourpoint,this.getBounds().height);
			hourpoint+=Math.ceil(vm.getPricemodel().getLengthofPriceInterval()*this.pixrate);
		}
		//e.gc.drawLine(0, 0, 100, 100);
	}
}
