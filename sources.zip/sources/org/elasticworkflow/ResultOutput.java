package org.elasticworkflow;
import java.io.*;
import java.io.IOException;
import org.jdom2.Document;
import org.jdom2.Element;
import org.elasticworkflow.SystemParameters.DistributionType;
import org.jdom2.*;
import org.jdom2.util.*;
import org.jdom2.JDOMException;
import org.jdom2.output.XMLOutputter;
import org.jdom2.output.*;
public class ResultOutput {

	public static boolean  OutputStaticCompare(double staticcost,double actualcost,double deadline,
    double staticfinishtime,double actualfinishtime) {
		// TODO Auto-generated constructor stub
		XMLOutputter outbuilder=new XMLOutputter();
		Element rootel=new Element("Result");
		Document dom = new Document(rootel);
		try {
			
			rootel.setAttribute("InstanceName", SystemParameters.instancename);
			rootel.setAttribute("deadlinefactor", String.valueOf(SystemParameters.deadlinefactor));
			rootel.setAttribute("maxdev",String.valueOf(SystemParameters.maxdev));
			rootel.setAttribute("pricinginterval",String.valueOf(SystemParameters.pricinginterval));
			if(SystemParameters.seltype==DistributionType.Gaussian)
				rootel.setAttribute("distributiontype","Gaussian");
			else if(SystemParameters.seltype==DistributionType.Uniform)
				rootel.setAttribute("distributiontype","Uniform");
			
			Element staticcostel=new Element("StaticCost");
			staticcostel.setText(String.valueOf(staticcost));
			Element actualcostel=new Element("ActualCost");
			actualcostel.setText(String.valueOf(actualcost));
			
			Element deadlineel=new Element("deadline");
			deadlineel.setText(String.valueOf(deadline));
			
			Element staticfinishtimeel=new Element("staticfinishtime");
			staticfinishtimeel.setText(String.valueOf(staticfinishtime));
			
			Element actualfinishtimeel=new Element("actualfinishtime");
			actualfinishtimeel.setText(String.valueOf(actualfinishtime));
			
			rootel.getChildren().add(staticcostel);
			rootel.getChildren().add(actualcostel);
			rootel.getChildren().add(deadlineel);
			rootel.getChildren().add(staticfinishtimeel);
			rootel.getChildren().add(actualfinishtimeel);
			Format format = Format.getCompactFormat();
		    format.setEncoding("gb2312"); //����xml�ļ����ַ�Ϊgb2312
		    format.setIndent("    "); //����xml�ļ�������Ϊ4���ո�
			outbuilder.setFormat(format);
			outbuilder.output(dom,new FileOutputStream(SystemParameters.outputfile));
		
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
	}
	/**
	 * 
	 * @param staticcost ��̬�㷨���
	 * @param actualcost ʵ��ִ�гɱ�
	 * @param deadline ��ֹ��
	 * @param staticfinishtime ��̬�㷨ִ��ʱ��
	 * @param actualfinishtime ʵ��ִ��ʱ��
	 * @param dyndeadline ��̬�㷨��ֹ��
	 * @param dynacost ��̬�㷨�ɱ�
	 * @param dynafinishtime ��̬�㷨����ʱ��
	 * @return
	 */
	public static boolean  OutputStaticCompare2(double staticcost,double actualcost,double deadline,
		    double staticfinishtime,double actualfinishtime,
		    double dyndeadline,double dynacost,double dynafinishtime) {
				// TODO Auto-generated constructor stub
				XMLOutputter outbuilder=new XMLOutputter();
				Element rootel=new Element("Result");
				Document dom = new Document(rootel);
				try {
					
					rootel.setAttribute("InstanceName", SystemParameters.instancename);
					rootel.setAttribute("deadlinefactor", String.valueOf(SystemParameters.deadlinefactor));
					rootel.setAttribute("maxdev",String.valueOf(SystemParameters.maxdev));
					rootel.setAttribute("pricinginterval",String.valueOf(SystemParameters.pricinginterval));
					if(SystemParameters.seltype==DistributionType.Gaussian)
						rootel.setAttribute("distributiontype","Gaussian");
					else if(SystemParameters.seltype==DistributionType.Uniform)
						rootel.setAttribute("distributiontype","Uniform");
					
					Element staticcostel=new Element("StaticCost");
					staticcostel.setText(String.valueOf(staticcost));
					Element actualcostel=new Element("ActualCost");
					actualcostel.setText(String.valueOf(actualcost));
					
					Element deadlineel=new Element("deadline");
					deadlineel.setText(String.valueOf(deadline));
					
					Element staticfinishtimeel=new Element("staticfinishtime");
					staticfinishtimeel.setText(String.valueOf(staticfinishtime));
					
					Element actualfinishtimeel=new Element("actualfinishtime");
					actualfinishtimeel.setText(String.valueOf(actualfinishtime));
					
					Element dyndeadlineel=new Element("dyndeadline");
					dyndeadlineel.setText(String.valueOf(dyndeadline));
					
					Element dynacostel=new Element("dynacost");
					dynacostel.setText(String.valueOf(dynacost));
					
					Element dynafinishtimeel=new Element("dynafinishtime");
					dynafinishtimeel.setText(String.valueOf(dynafinishtime));
					
					rootel.getChildren().add(staticcostel);
					rootel.getChildren().add(actualcostel);
					rootel.getChildren().add(deadlineel);
					rootel.getChildren().add(staticfinishtimeel);
					rootel.getChildren().add(actualfinishtimeel);
					rootel.getChildren().add(dyndeadlineel);
					rootel.getChildren().add(dynacostel);
					rootel.getChildren().add(dynafinishtimeel);
					
					Format format = Format.getCompactFormat();
				    format.setEncoding("gb2312"); //����xml�ļ����ַ�Ϊgb2312
				    format.setIndent("    "); //����xml�ļ�������Ϊ4���ո�
					outbuilder.setFormat(format);
					outbuilder.output(dom,new FileOutputStream(SystemParameters.outputfile));
					return true;
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
					return false;
				}
			}
}
