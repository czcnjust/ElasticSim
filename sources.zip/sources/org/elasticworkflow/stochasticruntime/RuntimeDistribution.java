package org.elasticworkflow.stochasticruntime;

import org.elasticworkflow.SystemParameters.DistributionType;

public abstract class RuntimeDistribution {
	protected DistributionType type;
	protected double fixedtime=-1;
	public RuntimeDistribution() {
		// TODO Auto-generated constructor stub
	}
    public abstract double getRunTime();
    public abstract void setSeedTime(double seedtime);
    /**
     * Average time
     * @return
     */
    public abstract double getAverageTime();
    /**
     * Standard deviation
     * @return
     */
    public abstract double getStandardDeviation();
    
    public DistributionType getDistributeType()
    {
    	return type;
    }
    /**
     * Set Fixed time, if this value is not equal to -1, the get runtime function
     * will always get fixedtime 
     * @param fixedtime
     * @return
     */
    public void setFixedTime(double fixedtime)
    {
    	this.fixedtime=fixedtime;
    }
    
}
