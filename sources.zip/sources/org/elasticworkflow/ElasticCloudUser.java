package org.elasticworkflow;

import java.util.ArrayList;
import java.util.List;

import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;

public class ElasticCloudUser extends SimEntity {

	protected List<WorkflowInstance> workflowListfixedtime=new ArrayList<WorkflowInstance>();
	/**
	 * The broker of this user
	 */
	ElasticWorkflowScheduler scheduler;
	
	public List<WorkflowInstance> getWorkflowListfixedtime() {
		return workflowListfixedtime;
	}
	/**
	 * The workflow list for executing
	 */
	 protected List<WorkflowInstance> workflowList;
	 public List<WorkflowInstance> getWorkflowList() {
		return workflowList;
	}

	public void setWorkflowList(List<WorkflowInstance> workflowList) {
		this.workflowList = workflowList;
	}
	/**
     * The workflow parser.
     */
    protected ElasticWorkflowPaser parser;
	public ElasticCloudUser(String name,ElasticWorkflowScheduler scheduler) {
		super(name);
		// TODO Auto-generated constructor stub
		setWorkflowList(new ArrayList<>());
		this.scheduler=scheduler;
	}

	@Override
	public void startEntity() {
		// TODO Auto-generated method stub
		   Log.printLine("Starting WorkflowSim " + SystemParameters.getVersion());
	       Log.printLine(getName() + " is starting...");
	       schedule(getId(), 0, ElasticSimTags.START_SIMULATION);
	}

	@Override
	public void processEvent(SimEvent ev) {
		// TODO Auto-generated method stub
		 switch (ev.getTag()) {
         case ElasticSimTags.START_SIMULATION:
        	 StartSimulation();
             break;
         case CloudSimTags.END_OF_SIMULATION:
             shutdownEntity();
             break;
         // other unknown tags are processed by this method
         default:
             processOtherEvent(ev);
             break;
     }
	}
    
	private void StartSimulation()
	{
		if(workflowListfixedtime.size()>0)
		{
			Log.printLine("input data got from workflowListfixedtime list...");
			for(WorkflowInstance wfi:workflowListfixedtime)
			{
				wfi.ClearState();
				
			}
	        sendNow(scheduler.getId(), ElasticSimTags.JOB_SUBMIT, workflowListfixedtime);
		}
		else
		{
			 this.parser = new ElasticWorkflowPaser(scheduler.getId());  
			 WorkflowInstance wfi=getWorkflowParser().parse(SystemParameters.getDaxPath());
	         this.getWorkflowList().add(wfi);
	         
		     Log.printLine("input data parsed from XML File...");
	         sendNow(scheduler.getId(), ElasticSimTags.JOB_SUBMIT, getWorkflowList());
		}
	}
	@Override
	public void shutdownEntity() {
		// TODO Auto-generated method stub

	}
	 /**
     * Overrides this method when making a new and different type of Broker.
     * This method is called by {@link #body()} for incoming unknown tags.
     *
     * @param ev a SimEvent object
     * @pre ev != null
     * @post $none
     */
    protected void processOtherEvent(SimEvent ev) {
        if (ev == null) {
            Log.printLine(getName() + ".processOtherEvent(): " + "Error - an event is null.");
            return;
        }

        Log.printLine(getName() + ".processOtherEvent(): "
                + "Error - event unknown by this DatacenterBroker.");
    }
    /**
     * Gets the workflow parser
     *
     * @return the workflow parser
     */
    public ElasticWorkflowPaser getWorkflowParser() {
        return this.parser;
    }

}
