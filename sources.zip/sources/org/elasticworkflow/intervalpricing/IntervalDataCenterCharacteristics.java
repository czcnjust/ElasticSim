package org.elasticworkflow.intervalpricing;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.LinkedList;

import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Storage;
import org.elasticworkflow.SystemParameters;
import org.elasticworkflow.SystemSetting;

/**
 * IntervalDataCenterCharacteristics extends DatacenterCharacteristics
 * supporting description of interval based Vms
 * 
 * @author Zhicheng Cai
 * @since WorkflowSimPricing Toolkit 1.0
 * @date Nov 11, 2015
 */
public class IntervalDataCenterCharacteristics extends DatacenterCharacteristics {
	
	/**
	 * The configuration of Vms supported by this datacenter
	 */
	private Map<String, VMconfig> VMconfiglist;
	private List<Storage> storageList;
	public IntervalDataCenterCharacteristics(String architecture, String os, String vmm, List<? extends Host> hostList,
			double timeZone, double costPerSec, double costPerMem, double costPerStorage, double costPerBw) {
		super(architecture, os, vmm, hostList, timeZone, costPerSec, costPerMem, costPerStorage, costPerBw);
		// TODO Auto-generated constructor stub
		VMconfiglist=new HashMap<String,VMconfig>();
		constructVMconfigList();
	}
	public List<Storage> getStorageList() {
		return storageList;
	}
	public void setStorageList(List<Storage> storageList) {
		this.storageList = storageList;
	}
	/**
	 * return the list of vm configurations of this data center
	 * @return VMconfiglist, list of vm configurations of this data center
	 */
	public Map<String, VMconfig> getVMconfiglist() {
		return VMconfiglist;
	}
	public void setdatacenterid(int datercenterid)
	{
		for(VMconfig conf:VMconfiglist.values())
		{
			conf.setDatacenterid(datercenterid);
		}
	}
	/**
	 * Construct the vm configuration of this data center
	 */
	private void constructVMconfigList()
	{
		double pinterval=SystemParameters.pricinginterval;
		  //VM Parameters
		String VMtype="N_S";
        long size = 10000; //image size (MB)
        int ram = 1700; //vm memory (MB)
        int mips = 1000;
        long bw = 100;//(MB)
        int pesNumber = 1; //number of cpus
        String vmm = "Xen"; //VMM name
        double priceperinterv=0.06;
        double setuptime=SystemSetting.vmsetuptime;//in second
        VMconfig cf=new VMconfig(VMtype, size, mips, pesNumber, ram, bw, vmm,
        		priceperinterv, pinterval, this.getCostPerMem(), this.getCostPerStorage(), this.getCostPerBw(),
        		this.getId(),setuptime);
        VMconfiglist.put(VMtype, cf);
        VMtype="N_M";
        size = 10000; //image size (MB)
        ram = 3750; //vm memory (MB)
        mips = 2000;
        bw = 100;//(MB)
        pesNumber = 1; //number of cpus
        vmm = "Xen"; //VMM name
        priceperinterv=0.12;
        setuptime=SystemSetting.vmsetuptime;//in second
        cf=new VMconfig(VMtype, size, mips, pesNumber, ram, bw, vmm,
        		priceperinterv, pinterval, this.getCostPerMem(), this.getCostPerStorage(), this.getCostPerBw(),
        		this.getId(),setuptime);
        VMconfiglist.put(VMtype, cf);
        VMtype="N_L";
        size = 10000; //image size (MB)
        ram =7500; //vm memory (MB)
        mips = 4000;
        bw = 100;//(MB)
        pesNumber = 1; //number of cpus
        vmm = "Xen"; //VMM name
        priceperinterv=0.24;
        setuptime=SystemSetting.vmsetuptime;//in second
        cf=new VMconfig(VMtype, size, mips, pesNumber, ram, bw, vmm,
        		priceperinterv, pinterval, this.getCostPerMem(), this.getCostPerStorage(), this.getCostPerBw(),
        		this.getId(),setuptime);
        VMconfiglist.put(VMtype, cf);
        VMtype="N_EL";
        size = 10000; //image size (MB)
        ram =15000; //vm memory (MB)
        mips = 8000;
        bw = 100;//(MB)
        pesNumber = 1; //number of cpus
        vmm = "Xen"; //VMM name
        priceperinterv=0.48;
        setuptime=SystemSetting.vmsetuptime;//in second
        cf=new VMconfig(VMtype, size, mips, pesNumber, ram, bw, vmm,
        		priceperinterv, pinterval, this.getCostPerMem(), this.getCostPerStorage(), this.getCostPerBw(),
        		this.getId(),setuptime);
        VMconfiglist.put(VMtype, cf);
        VMtype="C_M";
        size = 10000; //image size (MB)
        ram =1700; //vm memory (MB)
        mips = 5000;
        bw = 100;//(MB)
        pesNumber = 1; //number of cpus
        vmm = "Xen"; //VMM name
        priceperinterv=0.145;
        setuptime=SystemSetting.vmsetuptime;//in second
        cf=new VMconfig(VMtype, size, mips, pesNumber, ram, bw, vmm,
        		priceperinterv, pinterval, this.getCostPerMem(), this.getCostPerStorage(), this.getCostPerBw(),
        		this.getId(),setuptime);
        VMconfiglist.put(VMtype, cf);
        VMtype="C_EL";
        size = 10000; //image size (MB)
        ram =7000; //vm memory (MB)
        mips = 20000;
        bw = 100;//(MB)
        pesNumber = 1; //number of cpus
        vmm = "Xen"; //VMM name
        priceperinterv=0.58;
        setuptime=SystemSetting.vmsetuptime;//in second
        cf=new VMconfig(VMtype, size, mips, pesNumber, ram, bw, vmm,
        		priceperinterv, pinterval, this.getCostPerMem(), this.getCostPerStorage(), this.getCostPerBw(),
        		this.getId(),setuptime);
        
        
        VMconfiglist.put(VMtype, cf);
	}

}
