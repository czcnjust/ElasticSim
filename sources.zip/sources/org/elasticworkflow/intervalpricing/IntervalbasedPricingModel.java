package org.elasticworkflow.intervalpricing;

import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.core.CloudSim;
import org.elasticworkflow.staticalgorithm.FuncLib;

public class IntervalbasedPricingModel implements PricingModelInterface {

	 /**
     * the time of starting pricing
     */
	double starttime;
	
	 /**
     * the price of vm per interval
     */
	double priceperinterval;
	
	/**
     * the length of pricing interval in time units
     */
	double intervallength;
	
	/**
	 * Construct the pricing model
	 * @param starttime, the time of starting pricing
	 * @param priceperinterval, price of vm per interval
	 * @param intervallength, the length of pricing interval in time units
	 */
	public IntervalbasedPricingModel(double starttime, double priceperinterval, double intervallength) {
		super();
		this.starttime = starttime;
		this.priceperinterval = priceperinterval;
		this.intervallength = intervallength;
		if(intervallength<1)
			intervallength=1;
	}

	
	@Override
	public double getCost(double curtime) {
		// TODO Auto-generated method stub
		if(curtime<starttime)
		{
			return 0;
		}
		double dv=(curtime-starttime)/intervallength;
		
		double ceildv=Math.ceil((curtime-starttime)/intervallength);
		double floordv=Math.floor((curtime-starttime)/intervallength);
		int intervals=(int)ceildv;
		if(FuncLib.EqualDouble(dv, floordv, -6))
		{
			intervals=(int)floordv;
		}
		
		Log.printLine("dv:"+dv);
		
		Log.printLine(CloudSim.clock()+" curtime:"+curtime+"-starttime:"+starttime+",intervals:"+intervals);
		
		return intervals*priceperinterval;
	}

	@Override
	public double getPricingStarttime() {
		// TODO Auto-generated method stub
		return starttime;
	}

	@Override
	public double getPricePerUnit() {
		// TODO Auto-generated method stub
		return priceperinterval;
	}

	@Override
	public double getLengthofPriceInterval() {
		// TODO Auto-generated method stub
		return intervallength;
	}

}
