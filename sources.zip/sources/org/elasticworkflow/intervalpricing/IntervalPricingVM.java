package org.elasticworkflow.intervalpricing;

import java.util.HashSet;

import org.cloudbus.cloudsim.CloudletScheduler;
import org.elasticworkflow.SystemParameters;
import org.cloudbus.cloudsim.Vm;
/**
 * IntervalPricingVM extends CondorVM, add the function of supporting interval based pricing models
 * @author Zhicheng Cai
 *@since WorkflowSimPricing Toolkit 1.0
 * @date Nov 11, 2015
 */
public class IntervalPricingVM extends BasicVM {

	/**
	 * Time of sending creation request
	 */
	private double creatingrequestsendtime=0;
	
	public double getCreatingrequestsendtime() {
		return creatingrequestsendtime;
	}

	public void setCreatingrequestsendtime(double creatingrequestsendtime) {
		this.creatingrequestsendtime = creatingrequestsendtime;
	}

	private HashSet<String> installedSoftware=new HashSet<>();
	/**
	 * VM configuration
	 */
	private VMconfig config;
	

	public VMconfig getConfig() {
		return config;
	}

	public HashSet<String> getInstalledSoftware() {
		return installedSoftware;
	}

	/**
     * pricing object of this vm
     */
    private PricingModelInterface pricemodel;

  
	public IntervalPricingVM(int id, int userId,VMconfig cf,
			CloudletScheduler cloudletScheduler) {
		super(id, userId, cf.getMips(), cf.getNumberOfPes(), cf.getRam(), cf.getBw(), cf.getStoragesize(), cf.getVmm(), cf.getPrice()/SystemParameters.pricinginterval, cf.getCostPerMem(), cf.getCostPerStorage(), cf.getCostPerBW(),
				cloudletScheduler);
		config=cf;
		// TODO Auto-generated constructor stub
	}
	  /**
     * get the pricing model object which contains the start time of pricing, price per interval and 
     * the length of pricing interval and so on 
     * @author Zhicheng Cai workflowsimPricing 1.0
     * @return pricemodel ,PricingModelInterface
     */
    public PricingModelInterface getPricemodel() {
		return pricemodel;
	}

    /**
     * set the pricing model of this vm, the object pricemodel has start to pricing.
     * @param pricemodel, the pricing model object which contains the start time of pricing, price per interval and 
     * the length of pricing interval and so on
     *  @author Zhicheng Cai workflowsimPricing 1.0
     */
	public void setPricemodel(PricingModelInterface pricemodel) {
		this.pricemodel = pricemodel;
	}
}
