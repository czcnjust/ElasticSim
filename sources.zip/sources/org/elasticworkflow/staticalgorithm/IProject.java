package org.elasticworkflow.staticalgorithm;

import java.util.Hashtable;


public interface IProject {

	/**
	 * @return  Returns the guid.
	 * @uml.property  name="GUID"
	 */
	public String getGUID();

	/**
	 * Setter of the property <tt>GUID</tt>
	 * @param GUID  The guid to set.
	 * @uml.property  name="GUID"
	 */
	public double getFinishTime();
	/**
	 * @return  Returns the jobTable.
	 * @uml.property  name="JobTable"
	 */
	public Hashtable<String, IJob> getJobTable();
    

	public double getEarliestFinishTime();
	//public Workflow getDpj();
	//public void setDpj(Workflow dpj);
	public Hashtable<IJob, Integer> getJbpostable();
	public Hashtable<Integer, IJob> getJbindextable();


	public int getJobNumber() ;


	public IJob getStartjb() ;


	public IJob getEndjb() ;
	public void DisplayScheduleResult();
	
}
