package org.elasticworkflow.staticalgorithm;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;

import org.elasticworkflow.SystemSetting;
public class NewDeadlineDivision {
	private double sfsetuptime=SystemSetting.susetuptime;//������Ԫ���л�ʱ��
	private double deadline;
	private double bandwidth=SystemSetting.storagetransferrate;
	private double curtime=0;
	private HashSet<IJob> assignedjobs=new HashSet<IJob>();//�ѵ�������
	private WorkflowRequest req;
	private IProject pj;
	private Hashtable<IJob,Double> EFT=new Hashtable<IJob,Double>();
	private Hashtable<IJob,Double> EST=new Hashtable<IJob,Double>();
	private Hashtable<IJob,Double> LST=new Hashtable<IJob,Double>();
	private Hashtable<IJob,Double> LFT=new Hashtable<IJob,Double>();
	public boolean Dividethedeadline(WorkflowRequest req,double Deadline,double curtime)
	{
		this.curtime=curtime;
		this.deadline=Deadline;
		this.req=req;
		pj=req.getPjinstance();
		pj.getEndjb().setFloatduration(0);//��Ϊÿ�ζ���������ʵ�ڵ㣬�����Ƚ��ýڵ���両������
		if(!GenerateEarliestFinishTime())
		{
			return false;
		}
		if(!GenerateLatestFinishTime())
		{
			return false;
		}
		//assignedjobs.add(pj.getEndjb());
		//assignedjobs.add(pj.getStartjb());
		
		if(!AssignParents(pj.getEndjb()))
		{
			return false;
		}
		CauculateSubdeadline(pj);
		return true;
	}
	/**
	 * ���ݸ����������ÿ��jb�Ľ�ֹʱ��deadline
	 * @param pj
	 */
	private void CauculateSubdeadline(IProject pj)
	{
		Hashtable<IJob,Double> FT=new Hashtable<IJob,Double>();//����ʱ��
		int jobcount=pj.getJobNumber();
		for(int i=1;i<=jobcount;i++)
		{
			IJob tempjb=pj.getJbindextable().get(i);
			/**
			 * �����翪ʼʱ��
			 */
			double EStime=this.curtime;
			if(tempjb.getPredecessor()!=null)
			{
				Enumeration<IJob> predeiter=tempjb.getPredecessor().elements();
				while(predeiter.hasMoreElements())
				{
					IJob prejb=predeiter.nextElement();
					double eFT=FT.get(prejb);
					if(eFT>EStime)
					{
						EStime=eFT;
					}
				}
			}
			double duration=tempjb.getFloatduration();
			double FTime=EStime+duration;
			FT.put(tempjb, FTime);
			tempjb.setDeadline(FTime);
		}
	}
	/**
	 * ��ȡ������Ĺؼ����ڵ�
	 * @param jb
	 * @return
	 */
	private IJob getCriticalParent(IJob jb)
	{
		if(jb.getPredecessor()==null)
			return null;
		double MaxFT=-1;
		
		IJob cparent=null;
		Enumeration<IJob> preiter=jb.getPredecessor().elements();
		while(preiter.hasMoreElements())
		{
			IJob prejb=preiter.nextElement();
			if(!assignedjobs.contains(prejb))
			{
				double eftime=EFT.get(prejb);
				if(eftime>MaxFT)
				{
					MaxFT=eftime;
					cparent=prejb;
				}
			}
		}
		
		return cparent;
	}
	/**
	 * ��ѯ�������Ƿ���δ���ȸ��׽ڵ�
	 * @param jb
	 * @return
	 */
	private boolean hasunassignedParents(IJob jb)
	{
		if(jb==null)
		{
			return false;
		}
		if(jb.getPredecessor()==null)
			return false;
		Enumeration<IJob> preiter=jb.getPredecessor().elements();
		while(preiter.hasMoreElements())
		{
			IJob prejb=preiter.nextElement();
			if(!assignedjobs.contains(prejb))
			{
				return true;
			}
		}
		return false;
	}
	/**
	 * ����sub-deadline
	 * @param jb
	 */
	private boolean AssignParents(IJob jb)
	{
		IJob cjb=null;
		if(jb==null)
		{
			return false;
		}
		while(hasunassignedParents(jb))
		{
			ArrayList<IJob> PCP=new ArrayList<IJob>();
			cjb=jb;
			while(hasunassignedParents(cjb))
			{
				IJob cparent=getCriticalParent(cjb);
				PCP.add(0, cparent);
				cjb=cparent;
			}
			
			
			if(!ProportionalDeadlineDivide(PCP))
			{
				return false;
			}
			
			for(int i=0;i<PCP.size();i++)
			{
				IJob tjb=PCP.get(i);
				if(!GenerateEarliestFinishTime())
				{
					return false;
				}
				if(!GenerateLatestFinishTime())
				{
					return false;
				}
				if(!AssignParents(tjb))
				{
					return false;
				}
			}
		}
		return true;
	}
	private boolean ProportionalDeadlineDivide2(ArrayList<IJob> PCP)
	{
		//�ӽ�ֹʱ�仮��
		//��ȡ���һ�������������ʱ��
		IJob lastjb=PCP.get(PCP.size()-1);
		IJob firstjb=PCP.get(0);
		double lastlft=LFT.get(lastjb);
		double firstest=EST.get(firstjb);
		double lasteft=EFT.get(lastjb);
		
		double base=0;
		for(int i=0;i<PCP.size();i++)
		{
			IJob tjb=PCP.get(i);
			double ft=EFT.get(tjb);
			double subdeadline=firstest+(ft-firstest)*(lastlft-firstest)/(lasteft-firstest);
			double lft=LFT.get(tjb);
		    
			if(FuncLib.LessDouble(lft, subdeadline, -4))//������Լ��
			{
				subdeadline=lft;
			}
		
			tjb.setDeadline(subdeadline);
			
			this.assignedjobs.add(tjb);
			Clog.LogInfo("Set sub-deadline:"+tjb.getGUID()+",subdeadline:"+subdeadline);
			
		}
		return true;
	}
	/**
	 * ��ö�ٷ�����·���ϻ�����Ž⣨���ں�ʱ�������ã�
	 * @param PCP
	 */
	private boolean ProportionalDeadlineDivide1(ArrayList<IJob> PCP)
	{
		
		//�ӽ�ֹʱ�仮��
			//��ȡ���һ�������������ʱ��
			IJob lastjb=PCP.get(PCP.size()-1);
			double lastlft=LFT.get(lastjb);
			double eft=EFT.get(lastjb);
			double floatduration=lastlft-eft;//���ʣ�ม��
			double totalduration=0;
			String path="";
			
			
			//���ݻ�����ģ̬����ռ��·�����л���ģ̬�����ܺ͵İٷֱȷ�̯��ʣ�ม��ֵ
			for(int i=0;i<PCP.size();i++)
			{
				IJob tjb=PCP.get(i);
				path+=tjb.getGUID()+", ";
				//tjb.getInputData(jb)
				try
				{
					totalduration+=tjb.getSelMode().getDurationDouble()+tjb.getMaximumDatatransfertime(bandwidth)+this.sfsetuptime;
				}catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			Clog.LogInfo("׼���Ż���"+path);
			double base=0;
			for(int i=0;i<PCP.size();i++)
			{
				IJob tjb=PCP.get(i);
				double ft=EFT.get(tjb);
				
				double lft=LFT.get(tjb);
				double duration=tjb.getSelMode().getDurationDouble()+tjb.getMaximumDatatransfertime(bandwidth)+this.sfsetuptime;
				
				double subfloat=floatduration*Double.valueOf(Double.valueOf(duration)/totalduration);
				
				if(i==PCP.size()-1)
					subfloat=floatduration-base;
				
				
				double newftime=ft+base+subfloat;
				if(FuncLib.LessDouble(lft, newftime, -4))//������Լ��
				{
					subfloat=subfloat-(newftime-lft);
				}
				base+=subfloat;
				tjb.setFloatduration(subfloat+duration);
				if(subfloat<0)
				{
					Clog.LogInfo("Set sub-deadline<0");
				}
				this.assignedjobs.add(tjb);
				Clog.LogInfo("Set sub-deadline:"+tjb.getGUID()+",newftime:"+newftime+" float:"+subfloat);
				
			}
		return true;
	}
	private boolean ProportionalDeadlineDivide(ArrayList<IJob> PCP)
	{
		
		//�ӽ�ֹʱ�仮��
			//��ȡ���һ�������������ʱ��
			IJob lastjb=PCP.get(PCP.size()-1);
			int count=0;
			while(true)
			{
				double lastlft=LFT.get(lastjb);
				/**
				 * �Ƚ���·�������еĸ��������ۼ�
				 * ������Ҫ��̯������ܴ���ʱ��
				 */
				count++;
				double totalfloat=0;//���ʣ�ม��
				double totalduration=0;//������Ҫ��̯������ܴ���ʱ��
				String path="";
				String oppath="";
				for(int i=0;i<PCP.size();i++)
				{
					IJob tjb=PCP.get(i);
					double ft=EFT.get(tjb);
					double lft=LFT.get(tjb);
					path+=tjb.getGUID()+", ";
					this.assignedjobs.add(tjb);
					//if(tjb.getSelMode().getDurationDouble()==0)
					//{
					//	continue;
					//}
					if(FuncLib.EqualDouble(lft, ft, -4))
					{
						continue;
					}
					double nextest=0;
					IJob njb=null;
					if(i+1<PCP.size())
					{
						njb=PCP.get(i+1);
						nextest=EST.get(njb);
						totalfloat+=nextest-ft;
					}
					else
					{
						totalfloat+=lastlft-ft;
					}
					
					try
					{
						if(tjb.getFloatduration()==-1)
						{
							Clog.LogInfo("tjb.getFloatduration()==-1");
							return false;
						}
						totalduration+=tjb.getFloatduration();
					}catch(Exception e)
					{
						e.printStackTrace();
					}
					oppath+=tjb.getGUID()+", ";
				}
				Clog.LogInfo("��·����"+path);
				Clog.LogInfo("׼�����両�����䵽��"+oppath);
				
				if(FuncLib.EqualLessDouble(totalfloat, 0, -4))
				{
					Clog.LogInfo(" �������η���");
					break;
				}
				for(int i=0;i<PCP.size();i++)
				{
					IJob tjb=PCP.get(i);
					Clog.LogInfo(tjb.getGUID()+"--------------------------------------------");
					double ft=EFT.get(tjb);
					double est=EST.get(tjb);
					double lft=LFT.get(tjb);
					if(FuncLib.EqualLessDouble(lft,ft , -4))
					{
						Clog.LogInfo(tjb.getGUID()+"lft:"+lft+"<ft"+ft+"���Ż�");
						continue;
					}
					if(tjb.getSelMode().getDurationDouble()==0)
					{
						Clog.LogInfo(tjb.getGUID()+"tjb.getSelMode().getDurationDouble()==0");
						continue;
					}
					double duration=tjb.getFloatduration();
					
					double subfloat=totalfloat*Double.valueOf(Double.valueOf(duration)/totalduration);
					
					//if(i==PCP.size()-1)
					//	subfloat=floatduration-base;
					
					
					double newftime=ft+subfloat;
					if(FuncLib.LessDouble(lft, newftime, -4))//������Լ��
					{
						subfloat=lft-ft;
						newftime=lft;
						if(FuncLib.LessDouble(subfloat, 0, -4))
						{
							Clog.LogInfo("subfloat<0");
						}
					}
					EFT.put(tjb, newftime);
					Clog.LogInfo("Set sub-deadline:"+tjb.getGUID()+",starttime:"+est+",sub-deadline:"+newftime+" float:"+subfloat+",lft:"+lft);
					
					tjb.setFloatduration(newftime-est);
				
					if(!UpdateEarliestFinishTime(tjb))
					{
						return false;
					}
				}
				if(!GenerateLatestFinishTime())
				{
					return false;
				}
			}
		return true;
	}
	
	/**
	 * ����startjb��������������翪ʼʱ��
	 * @param startjb
	 * @return
	 */
	private boolean UpdateEarliestFinishTime(IJob startjb)
	{
		ArrayList<IJob> alllist=new ArrayList<IJob>();//������Ҫˢ�µ�����
		//HashSet<IJob> updatedlist=new HashSet<IJob>();//�ѵ�������
		ArrayList<IJob> jblist=new ArrayList<IJob>();
		jblist.add(startjb);
		IJob readyjb=startjb;
		while(readyjb!=null)
		{
			alllist.add(readyjb);
			jblist.remove(readyjb);
			/**
			 * ��������ӵ�����
			 */
			if(readyjb.getSuccessor()!=null)
			{
				Enumeration<IJob> sureiter=readyjb.getSuccessor().elements();
				while(sureiter.hasMoreElements())
				{
					IJob surjb=sureiter.nextElement();
					//Ҫ�ж��Ƿ��Ѿ��������ˣ������Ѿ�����չ��
					if(!alllist.contains(surjb)&&!jblist.contains(surjb))
						jblist.add(surjb);
				}
			}
			if(jblist.size()>0)
				readyjb=jblist.get(0);
			else
				readyjb=null;
		}
		readyjb=startjb;
		
		while(readyjb!=null)
		{
			if(!readyjb.equals(startjb))
			{
				/**
				 * �����翪ʼʱ��
				 */
				double EStime=0;
				if(readyjb.getPredecessor()!=null)
				{
					Enumeration<IJob> predeiter=readyjb.getPredecessor().elements();
					while(predeiter.hasMoreElements())
					{
						IJob prejb=predeiter.nextElement();
						double eFT=EFT.get(prejb);
						if(eFT>EStime)
						{
							EStime=eFT;
						}
					}
				}
				EST.put(readyjb, EStime);
				//IMode EFmode=tempjb.getSelMode();
				double fduration=readyjb.getFloatduration();
				if(fduration==-1)
				{
					Clog.LogInfo("tjb.getFloatduration()==-1");
					return false;
					
				}
				EFT.put(readyjb, EStime+fduration);
				
				double ftime=EStime+fduration;
				//Clog.LogInfo(tempjb.getGUID()+"EStime:"+EStime+"ftime:"+ftime);
				if(FuncLib.LessDouble(this.deadline, ftime, -4))
				{
					Clog.LogInfo("EStime+fduration>this.deadline ��ֹ�ڹ���,ftime:"+ftime+",deadline:"+this.deadline);
					return false;
				}
			}
			
			/**
			 * ��ǵ�ǰ����Ϊ�Ѿ�ˢ��EST
			 */
			//updatedlist.add(readyjb);
			/**
			 * ����ǰ����Ӵ�ˢ�¶���ɾ��
			 */
			alllist.remove(readyjb);
			
			/**
			 * �����µ�readyjb
			 */
			readyjb=null;
			for(int i=0;i<alllist.size();i++)
			{
				IJob tjb=alllist.get(i);
				boolean allpredeupdated=true;//�ж��Ƿ�����ǰ����ˢ�µ�EST
				if(tjb.getPredecessor()!=null)
				{
					Enumeration<IJob> predeiter=tjb.getPredecessor().elements();
					while(predeiter.hasMoreElements())
					{
						IJob prejb=predeiter.nextElement();
						if(alllist.contains(prejb))//˵����ûˢ��
						{
							allpredeupdated=false;
							break;
						}
					}
				}
				if(allpredeupdated)
				{
					readyjb=tjb;
					break;
				}	
			}
			
		}
		return true;
	}
	/**
	 * ÿ���ѡ�����������ģ̬,Schedule�п�����Щ���ģ̬�Ѿ�ȷ��
	 */
	private boolean GenerateEarliestFinishTime()
	{
		
		int jobcount=pj.getJobNumber();
		for(int i=1;i<=jobcount;i++)
		{
			IJob tempjb=pj.getJbindextable().get(i);
			/**
			 * �����翪ʼʱ��
			 */
			double EStime=0;
			if(tempjb.getPredecessor()!=null)
			{
				Enumeration<IJob> predeiter=tempjb.getPredecessor().elements();
				while(predeiter.hasMoreElements())
				{
					IJob prejb=predeiter.nextElement();
					double eFT=EFT.get(prejb);
					if(eFT>EStime)
					{
						EStime=eFT;
					}
				}
			}
			EST.put(tempjb, EStime);
			//IMode EFmode=tempjb.getSelMode();
			double fduration=tempjb.getFloatduration();
			if(fduration==-1)
			{
				Clog.LogInfo("tjb.getFloatduration()==-1");
				return false;
			}
			EFT.put(tempjb, EStime+fduration);
			
			double ftime=EStime+fduration;
			//Clog.LogInfo(tempjb.getGUID()+"EStime:"+EStime+"ftime:"+ftime);
			if(FuncLib.LessDouble(this.deadline, ftime, -4))
			{
				Clog.LogInfo("EStime+fduration>this.deadline ��ֹ�ڹ���,ftime:"+ftime+",deadline:"+this.deadline);
				return false;
			}
		}
		
		return true;
	}
	/**
	 * ��ȡ��������ʱ�䣬
	 * @param schedule����ĳЩ���ģ̬�Ѿ�������ȷ����
	 * @return
	 */
	private boolean GenerateLatestFinishTime()
	{
		
		int jobcount=pj.getJobNumber();
		for(int i=jobcount;i>=1;i--)
		{
			IJob tempjb=pj.getJbindextable().get(i);
			double LFtime=deadline;//��������ʱ��
			if(tempjb.getSuccessor()!=null)
			{
				Enumeration<IJob> sureiter=tempjb.getSuccessor().elements();
				while(sureiter.hasMoreElements())
				{
					IJob surjb=sureiter.nextElement();
					double surlst=LST.get(surjb);
					if(surlst<LFtime)
					{
						LFtime=surlst;
					}
				}
			}
			LFT.put(tempjb, LFtime);
			double fduration=tempjb.getFloatduration();
			if(fduration==-1)
			{
				Clog.LogInfo("tjb.getFloatduration()==-1");
				return false;
			}
			if(FuncLib.LessDouble(LFtime-fduration, 0, -4))
			{
				
				Clog.LogInfo("GenerateLatestFinishTime LFtime-fduration<0 ��ֹ�ڹ���");
				return false;
			}
			LST.put(tempjb, LFtime-fduration);
		}
		return true;
	}
	
}
