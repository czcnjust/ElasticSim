package org.elasticworkflow.staticalgorithm;

public enum TASKTYPE {

	ComputeIntensive,
	MEMIntensive,
	IOIntensive,
	NORMAL
}
