package org.elasticworkflow.staticalgorithm;
public enum RequestState {
	Suspended,
	Scheduled,
	UnderExecution,
	Finished
}
