package org.elasticworkflow.staticalgorithm;

public class VirtualMachine {

	/**
	 * CPU��С
	 */
	private double CPU;
	/**
	 * �ڴ��С
	 */
	private double MEM;
	/**
	 * IO��С
	 */
	private double IO;
	
	/**
	 * ������۸� 
	 */
	private double Price;
	
	/**
	 * ����� ������
	 */
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		Price = price;
	}
	public double getCPU() {
		return CPU;
	}
	public void setCPU(double cPU) {
		CPU = cPU;
	}
	public double getMEM() {
		return MEM;
	}
	public void setMEM(double mEM) {
		MEM = mEM;
	}
	public double getIO() {
		return IO;
	}
	public void setIO(double iO) {
		IO = iO;
	}
	
}
