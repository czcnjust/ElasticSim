package org.elasticworkflow.staticalgorithm;


/**
 * ʱ��Ƭ�࣬��¼��ʱ��Ƭ�Ŀ�ʼʱ��ͽ���ʱ��
 * @author czc
 *
 */
public class TimeSlot {

	//private int from;
	//private int to;
	private double dfrom;//double�汾
	private double dto;//double�汾
	private VMInstance vmins;
	private double readystart;//׼�����õĿ�ʼʱ��
	private double readyend;//׼������ �Ľ���ʱ��
	private boolean reinstalledSU=false;//�Ƿ���Ҫ���°�װ������Ԫ
	private double datatransfertime=0;//���ݴ���ʱ��
	private String transferedfiles;//ʵ�ʴ�����ļ�
	public String getTransferedfiles() {
		return transferedfiles;
	}
	public void setTransferedfiles(String transferedfiles) {
		this.transferedfiles = transferedfiles;
	}
	public double getDatatransfertime() {
		return datatransfertime;
	}
	public void setDatatransfertime(double datatransfertime) {
		this.datatransfertime = datatransfertime;
	}
	public boolean isReinstalledSU() {
		return reinstalledSU;
	}
	public void setReinstalledSU(boolean reinstalledSU) {
		this.reinstalledSU = reinstalledSU;
	}
	public double getReadystart() {
		return readystart;
	}
	public void setReadystart(double readystart) {
		this.readystart = readystart;
	}
	public double getReadyend() {
		return readyend;
	}
	public void setReadyend(double readyend) {
		this.readyend = readyend;
	}
	private int[] rentflag;
	public VMInstance getVmins() {
		return vmins;
	}
	/**
	 * double�汾
	 * @return
	 */
	public double getDfrom() {
		return dfrom;
	}
	public void setDfrom(double dfrom) {
		this.dfrom = dfrom;
	}
	public double getDto() {
		return dto;
	}
	public void setDto(double dto) {
		this.dto = dto;
	}
	private String preSoftUnit="";//ǰһ�������ʱ��Ƭ��װ����ʲô������Ԫ
	public String getPreSoftUnit() {
		if(predecessor==null)
			return null;
		long base=(long)Math.floor(predecessor.dto-vmins.getStartrentingtime());
		long thisbase=(long)Math.floor(this.dfrom-vmins.getStartrentingtime());
		if(thisbase-base<2&&predecessor.getAssignedjb()!=null)
			preSoftUnit=predecessor.getAssignedjb().getSoftUnit();
		return preSoftUnit;
	}
	public void setPreSoftUnit(String preSoftUnit) {
		this.preSoftUnit = preSoftUnit;
	}
	/**
	 * �жϸ�slot�ǲ�����ȫ��Ҫ������
	 * @return
	 */
	public boolean IsTotallyNewRented()
	{
		
		long slotfrombase=(long)Math.floor((dfrom-vmins.getStartrentingtime())/vmins.getVMType().getInterval());
		long slottobase=(long)Math.floor((dto-vmins.getStartrentingtime())/vmins.getVMType().getInterval());
		boolean istotallynew=true;
		for(long base=slotfrombase;base<slottobase;base++)
		{
			if(this.vmins.rentedhour.contains(base))
			{
				istotallynew=false;
				break;
			}
		}
		if(slottobase*vmins.getVMType().getInterval()<dto-vmins.getStartrentingtime())
		{
			if(this.vmins.rentedhour.contains(slottobase))
			{
				istotallynew=false;
			}
		}
		return istotallynew;
	}
	private TimeSlot sucessor;
	private TimeSlot predecessor;
	private IJob assignedjb;
	public IJob getAssignedjb() {
		return assignedjb;
	}
	public void setAssignedjb(IJob assignedjb) {
		this.assignedjb = assignedjb;
	}
	public TimeSlot getSucessor() {
		return sucessor;
	}
	public void setSucessor(TimeSlot sucessor) {
		this.sucessor = sucessor;
	}
	public TimeSlot getPredecessor() {
		return predecessor;
	}
	public void setPredecessor(TimeSlot predecessor) {
		this.predecessor = predecessor;
	}
	
	public TimeSlot(VMInstance vmins,double from, double to) {
		super();
		this.dfrom = from;
		this.dto = to;
		this.vmins = vmins;
	}
	/**
	 * ���޸�slot��Ӧ�������ʵ��
	 * @return
	 */
	public void RentSlot()
	{
		if(dfrom==dto)
			return;
		long slotfrombase=(long)Math.floor((dfrom-vmins.getStartrentingtime())/vmins.getVMType().getInterval());
		long slottobase=(long)Math.floor((dto-vmins.getStartrentingtime())/vmins.getVMType().getInterval());
		
		for(long base=slotfrombase;base<slottobase;base++)
		{
			if(!this.vmins.rentedhour.contains(base))
			{
				this.vmins.rentedhour.add(base);
			}
		}
		if(slottobase*vmins.getVMType().getInterval()<(dto-vmins.getStartrentingtime()))
		{
			if(!this.vmins.rentedhour.contains(slottobase))
			{
				this.vmins.rentedhour.add(slottobase);
			}
		}
	
	}
	public void ReleaseSlot()
	{
		if(dfrom==dto)
			return;
		long slotfrombase=(long)Math.floor((dfrom-vmins.getStartrentingtime())/vmins.getVMType().getInterval());
		long slottobase=(long)Math.floor((dto-vmins.getStartrentingtime())/vmins.getVMType().getInterval());
		
		if(this.predecessor!=null)
		{
			if(predecessor.getDto()-vmins.getStartrentingtime()<=slotfrombase*vmins.getVMType().getInterval())
			{
				if(this.vmins.rentedhour.contains(slotfrombase))
				{
					this.vmins.rentedhour.remove(slotfrombase);
				}
				else
				{
					Clog.LogInfo("������󣬸����޵�û����----");
				}
			}
			
		}
		else
		{
			this.vmins.rentedhour.remove(slotfrombase);
		}
		
		
		for(long base=slotfrombase+1;base<slottobase;base++)
		{
			if(this.vmins.rentedhour.contains(base))
			{
				this.vmins.rentedhour.remove(base);
			}
		}
		if(this.sucessor!=null)
		{
			if(sucessor.getDfrom()-vmins.getStartrentingtime()>=(slottobase+1)*vmins.getVMType().getInterval())
			{
				if(this.vmins.rentedhour.contains(slottobase))
				{
					this.vmins.rentedhour.remove(slottobase);
				}
				else
				{
					Clog.LogInfo("������󣬸����޵�û����2");
				}
			}
		}
		else
		{
			this.vmins.rentedhour.remove(slottobase);
		}
		
	}
}
