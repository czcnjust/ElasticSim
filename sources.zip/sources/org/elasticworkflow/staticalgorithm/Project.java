package org.elasticworkflow.staticalgorithm;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.elasticworkflow.SystemSetting;
import org.elasticworkflow.Task;
import org.elasticworkflow.WorkflowInstance;

public class Project implements IProject {

	private WorkflowInstance dpj=null;
	private double EFTime=0;
	private double EFTime2=0;
	public double getEFTime2() {
		return EFTime2;
	}

	public WorkflowInstance getDpj() {
		return dpj;
	}

	public void setDpj(WorkflowInstance dpj,Map<Integer, DatacenterCharacteristics> datacenterCharacteristicsList) {
		this.dpj = dpj;
		
		Construct(datacenterCharacteristicsList);
	}
	/**
	 * ����Ŀ��������ҵ
	 */
	private Hashtable<String, IJob> jobTable=new Hashtable<String, IJob>();
	/**
	 * ��¼jobλ�õ�hash��
	 */
	private Hashtable<IJob,Integer> jbpostable=new Hashtable<IJob,Integer>();
	private Hashtable<Integer,IJob> jbindextable=new Hashtable<Integer,IJob>();
	public Hashtable<Integer, IJob> getJbindextable() {
		return jbindextable;
	}



	public Hashtable<IJob, Integer> getJbpostable() {
		return jbpostable;
	}


	public int getJobNumber() {
		return jobTable.size();
	}


	public IJob getStartjb() {
		return startjb;
	}


	public IJob getEndjb() {
		return endjb;
	}
	private double cheapestcost=0;
	public double getCheapestcost() {
		return cheapestcost;
	}

	private int JobNumber=0;
	private IJob startjb=null;
	private IJob endjb=null;
	@Override
	public String getGUID() {
		// TODO Auto-generated method stub
		return String.valueOf(dpj.getWorkflowid());
	}

	@Override
	public double getFinishTime() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Hashtable<String, IJob> getJobTable() {
		// TODO Auto-generated method stub
		return jobTable;
	}

	@Override
	public double getEarliestFinishTime() {
		// TODO Auto-generated method stub
		
		return EFTime;
	}
	/**
	 * ������ʵ�幹������
	 */
	public void Construct(Map<Integer, DatacenterCharacteristics> datacenterCharacteristicsList)
	{
		JobNumber=0;
		for(Task tsk:this.dpj.getTaskList())
		{
			Job jb=new Job();
			jb.Construct(tsk,datacenterCharacteristicsList);
			jobTable.put(jb.getGUID(), jb);
			jbpostable.put(jb, jb.getInerIndex());
			jbindextable.put(jb.getInerIndex(), jb);
			JobNumber++;
			if(this.dpj.getRoots().contains(tsk))
			{
				this.startjb=jb;
			}
			if(this.dpj.getEnds().contains(tsk))
			{
				this.endjb=jb;
			}
			jb.setLevel(tsk.getDepth());
		}
		Enumeration<IJob> jobiter= jobTable.elements();
		while(jobiter.hasMoreElements())
		{
			IJob cjob=jobiter.nextElement();
			for(Task tsk:cjob.getTask().getChildList())
			{
				IJob succesorjob= null;
			
				succesorjob=this.jbindextable.get(tsk.getIndex());
				if(succesorjob!=null)
				{
					cjob.AddSuccessor(succesorjob);
					succesorjob.AddPredecessor(cjob);
				}
				else
				{
					Clog.LogInfo("Error:"+cjob.getGUID()+"���ù�����ϵʱδ���ҵ���Ӧ��Jobʵ��,jobguid:"+tsk.getIndex());
				}
			}
			
		}
		
		
		
		/**
		 * ��������ķ���㼶 14.3.12
		 */
		for(int i=this.getJobNumber();i>=1;i--)
		{
			IJob tempjb=jbindextable.get(i);
			/**
			 * �����翪ʼʱ��
			 */
			int largestbackdepth=-1;
			if(tempjb.getSuccessor()!=null)
			{
				Enumeration<IJob> predeiter=tempjb.getSuccessor().elements();
				while(predeiter.hasMoreElements())
				{
					IJob surjb=predeiter.nextElement();
					int plevel=surjb.getBackdepth();
					if(plevel>largestbackdepth)
					{
						largestbackdepth=plevel;
					}
				}
			}
			tempjb.setBackdepth(largestbackdepth+1);
		}
		//�����ģ̬���������ʱ��HEFT����
		Schedule sh=new Schedule();
		Hashtable<IJob,Double> EST=new Hashtable<IJob,Double>();//���翪ʼʱ��
		Hashtable<IJob,Double> EFT=new Hashtable<IJob,Double>();//�������ʱ��
		FuncLib.GenerateEarliestFinishSchedule2(this, sh, EFT, EST,SystemSetting.storagetransferrate,SystemSetting.susetuptime);
		this.EFTime=EFT.get(this.getEndjb());
		//Clog.LogInfo("EFTime:"+this.EFTime);
		//sh.Display();
		//Clog.LogInfo("//////////////////////////////////");
		//�������ģ̬����С�ɱ�
		Schedule sh2=new Schedule();
		Hashtable<IJob,Double> EST2=new Hashtable<IJob,Double>();//���翪ʼʱ��
		Hashtable<IJob,Double> EFT2=new Hashtable<IJob,Double>();//�������ʱ��
		FuncLib.GenerateCheapestSchedule(this, sh2, EFT2, EST2);
		this.cheapestcost=sh2.getCost();
		//Clog.LogInfo("cheapestcost:"+this.cheapestcost);
		double finishtime=EFT2.get(this.getEndjb());
		//Clog.LogInfo("EFTime2:"+finishtime);
		//sh2.Display();
		//Clog.LogInfo("//////////////////////////////////");
		
		Schedule sh3=new Schedule();
		Hashtable<IJob,Double> EST3=new Hashtable<IJob,Double>();//���翪ʼʱ��
		Hashtable<IJob,Double> LFT3=new Hashtable<IJob,Double>();//�������ʱ��
		FuncLib.GenerateLatestFinishSchedule2(this, sh3, LFT3, EST3,SystemSetting.storagetransferrate,SystemSetting.susetuptime);
		
		this.EFTime2=LFT3.get(this.getEndjb());
		
		//Clog.LogInfo("cheapestcost:"+sh3.getCost());
	
		//Clog.LogInfo("EFTime3:"+EFTime2);
		//sh3.Display();
		//Clog.LogInfo("//////////////////////////////////");
		/**
		 * ��job�б�
		 *//*
		Set<DJob> jobset= dpj.getJobs();//��ȡ��project�����Ļ
		Iterator<DJob> iter= jobset.iterator();
		while(iter.hasNext())
		{
			try
			{
				DJob djb=iter.next();
				Job jb=new Job();
				jb.setDjb(djb);
				jobTable.put(jb.getGUID(), jb);
				jbpostable.put(jb, jb.getInerIndex());
				jbindextable.put(jb.getInerIndex(), jb);
			}catch(Exception e) 
			{
				Clog.LogError("Project:Construct:��job�б�", e);
		 	}
		}
		*//**
		 * ����job֮���Լ����ϵ
		 *//*
		Enumeration<IJob> jobiter= jobTable.elements();
		while(jobiter.hasMoreElements())
		{
			IJob cjob=jobiter.nextElement();
			DJob newdjb=cjob.getDjb();
			ArrayList<String> succesorarray=new ArrayList<String>();
			String strsuccessor=newdjb.getSuccessors();
			if(strsuccessor!=null)
			{
				String[] successors=strsuccessor.split("\\|");
				succesorarray.clear();
				for(int i=0;i<successors.length;i++)
				{
					succesorarray.add(successors[i]);
				}
			}
			
			for(int i=0;i<succesorarray.size();i++)
			{
				String strtemp=succesorarray.get(i);
				if(strtemp==null||strtemp.equalsIgnoreCase(""))
				{
					continue;
				}
				int index=-1;
				try
				{
					index=Integer.parseInt(strtemp);
				}
				catch(Exception e)
				{
					
				}
				
				
				IJob succesorjob= null;
				if(index==-1)
					succesorjob=jobTable.get(strtemp);
				else
				{
					succesorjob=this.jbindextable.get(index);
				}
				if(succesorjob!=null)
				{
					cjob.AddSuccessor(succesorjob);
					succesorjob.AddPredecessor(cjob);
				}
				else
				{
					Clog.LogInfo("Error:"+cjob.getGUID()+"���ù�����ϵʱδ���ҵ���Ӧ��Jobʵ��,jobguid:"+strtemp);
				}
			}
			
		}
		JobNumber=0;
		Enumeration<IJob> jbiter=jobTable.elements();
		while(jbiter.hasMoreElements())
		{
			IJob jb=jbiter.nextElement();
			JobNumber++;
			if(jb.getPredecessor().size()==0)
			{
				this.startjb=jb;
			}
			else if(jb.getSuccessor().size()==0)
			{
				this.endjb=jb;
			}
		}*/
		
		
	}
	/**
	 * ��jobsת�� �� �ַ��� 
	 * @return
	 */
	public String getJobsString()
	{
		String strjbs="";
		Enumeration<IJob> jobiter= jobTable.elements();
		while(jobiter.hasMoreElements())
		{
			IJob cjob=jobiter.nextElement();
			strjbs+=cjob.getJobString()+"##";
			//Clog.LogInfo("strjbs.length():"+strjbs.length());
		}
		return strjbs;
	}
	/**
	 * ��ʾ���Ƚ��
	 */
	@Override
	public void DisplayScheduleResult()
	{
		NumberFormat format = NumberFormat.getInstance();  
		format.setMinimumFractionDigits( 0 );   
		format.setMaximumFractionDigits(6); 
		int jobcount=getJobNumber();
		for(int i=1;i<=jobcount;i++)
		{
			IJob tempjb=jbindextable.get(i);
			ArrayList<IMode> modes=tempjb.getModes();
			IMode selmode=tempjb.getSelMode();
			Clog.LogInfo("///////////////////////////////////////////////////////////");
			Clog.LogInfo("Jbname:"+tempjb.getGUID());
			Clog.LogInfo("SU:"+tempjb.getSoftUnit());
			Clog.LogInfo("Modes:"+tempjb.getJobString());
			for(int m=0;m<modes.size();m++)
			{
				IMode md=modes.get(m);
				Clog.LogInfo("Mode_"+m+":"+md.getVMType()+"-Du:"+md.getDurationDouble()+"-Cost:"+md.getCost());
			}
			
			if(selmode!=null)
				Clog.LogInfo("SelMode:"+selmode.getVMType()+"-Du:"+selmode.getDurationDouble()+"-Cost:"+selmode.getCost());
			Clog.LogInfo("FloatDuration:"+tempjb.getFloatduration());
			Clog.LogInfo("SubDeadLine:"+tempjb.getDeadline());
		}
	}
	
}
