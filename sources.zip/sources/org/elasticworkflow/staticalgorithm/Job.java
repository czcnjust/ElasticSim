package org.elasticworkflow.staticalgorithm;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;

import org.cloudbus.cloudsim.Consts;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Storage;
import org.elasticworkflow.FileItem;
import org.elasticworkflow.FuncLib;
import org.elasticworkflow.SystemSetting;
import org.elasticworkflow.Task;
import org.elasticworkflow.SystemParameters.FileType;
import org.elasticworkflow.intervalpricing.IntervalDataCenterCharacteristics;
import org.elasticworkflow.intervalpricing.VMconfig;

public class Job implements IJob {

	private String name;
	private int index;
	private String SoftUnit;
	private TASKTYPE ttype;
	private double MEMTASK;
	private double CPUTASK;
	private String successors;
	private int level;//����������Ŀ�Ĳ㼶
	private IMode selmode;//ѡ���ģ̬
	private double floatduration=-1;//������ĸ�����ִ������
	private double seedtime;//dax�ļ��и������ִ��ʱ��
	private double deadline=-1;//��deadline����
	private TimeSlot assiganedslot;//���Ȱ��ŵ�ʱ��Ƭ
	private int backdepth;//���� ���
	private ISoftUnit sunitobject=null;
	private Task task;
	public Task getTask() {
		return task;
	}
	public void setTask(Task task) {
		this.task = task;
	}
	public ISoftUnit getSunitobject() {
		return sunitobject;
	}
	public void setSunitobject(ISoftUnit sunitobject) {
		this.sunitobject = sunitobject;
	}
	public int getBackdepth() {
		return backdepth;
	}
	public void setBackdepth(int backdepth) {
		this.backdepth = backdepth;
	}
	public TimeSlot getAssiganedslot() {
		return assiganedslot;
	}
	public void setAssiganedslot(TimeSlot assiganedslot) {
		this.assiganedslot = assiganedslot;
		
	}
	@Override
	public double getDeadline() {
		return deadline;
	}
	@Override
	public void setDeadline(double deadline) {
		this.deadline = deadline;
	}
	@Override
	public String getSuccessors() {
		return successors;
	}
	@Override
	public double getSeedtime() {
		return seedtime;
	}
	@Override
	public void setSeedtime(double seedtime) {
		this.seedtime = seedtime;
	}
	@Override
	public double getFloatduration() {
		//if(floatduration==-1&&this.getSelMode()!=null)
		//{
		//	floatduration=this.getSelMode().getDurationDouble();
		//}
		return floatduration;
	}
	@Override
	public void setFloatduration(double floatduration) {
	
		this.floatduration = floatduration;
	}
	@Override
	public IMode getSelMode() {
		// TODO Auto-generated method stub
		
		return selmode;
	}
	@Override
	public boolean setSelMode(VMconfig vmtype) {
		// TODO Auto-generated method stub
		for(int j=0;j<modes.size();j++)
		{
			IMode tmode=modes.get(j);
			if(tmode.getVMType()==vmtype)
			{
				this.selmode=tmode;
				return true;
			}
		}
		return false;
	}
	@Override
	public void setSelMode(IMode selmode) {
		// TODO Auto-generated method stub
		this.selmode=selmode;
	}
	@Override
	public int getLevel() {
		// TODO Auto-generated method stub
		return this.level;
	}
	@Override
	public void setLevel(int level) {
		// TODO Auto-generated method stub
		this.level=level;
	}
	@Override
	public void setSuccessors(String successors) {
		this.successors = successors;
	}
	@Override
	public double getMEMTASK() {
		return MEMTASK;
	}
	@Override
	public void setMEMTASK(double mEMTASK) {
		MEMTASK = mEMTASK;
	}
	@Override
	public double getCPUTASK() {
		return CPUTASK;
	}
	@Override
	public void setCPUTASK(double cPUTASK) {
		CPUTASK = cPUTASK;
	}
	
	@Override
	public void setGUID(String name) {
		// TODO Auto-generated method stub
		this.name=name;
	}
	@Override
	public void serInerIndex(int index) {
		// TODO Auto-generated method stub
		this.index=index;
	}
	@Override
	public String getGUID() {
		// TODO Auto-generated method stub
		return name;
	}
	/**
	 * ��ȡ���������index
	 * @return
	 */
	public Integer getInerIndex()
	{
		return index;
	}
	/**
	 * ���
	 */
	private Hashtable<String,IJob> successortable=new Hashtable<String,IJob>();
	/**
	 * ǰ��
	 */
	private Hashtable<String,IJob> predecessortable=new Hashtable<String,IJob>();
	/**
	 * ���ݴ���,ÿһ��ǰ�����񣬴������������
	 */
	private Hashtable<String,Double> datatransferfrom=new Hashtable<String,Double>();
	
	
	public Hashtable<String, Double> getDatatransferfrom() {
		return datatransferfrom;
	}
	@Override
	public Hashtable<String, IJob> getPredecessor() {
		// TODO Auto-generated method stub
		return predecessortable;
	}

	@Override
	public double getInputData(String jb) {
		// TODO Auto-generated method stub
		if(datatransferfrom.containsKey(jb))
			return datatransferfrom.get(jb);
		return 0;
	}
	@Override
	public void AddPredecessor(IJob jb) {
		// TODO Auto-generated method stub
		if(jb!=null)
			predecessortable.put(jb.getGUID(), jb);
	}

	@Override
	public Hashtable<String, IJob> getSuccessor() {
		// TODO Auto-generated method stub
		return successortable;
	}

	@Override
	public void AddSuccessor(IJob jb) {
		// TODO Auto-generated method stub
		if(jb!=null)
			successortable.put(jb.getGUID(), jb);
	}
	/**
	 * ��ȡʱ���origmode�̵� ����˵�ģ̬�е����ģ̬
	 * @param origmode
	 * @return
	 */
	public IMode getNextCandidateMode(IMode origmode)
	{
		IMode destmode=null;
		for(int j=0;j<modes.size();j++)
		{
			IMode tmode=modes.get(j);
			if(tmode.getDurationDouble()<origmode.getDurationDouble())
			{
				if(destmode==null
				||FuncLib.EqualDouble(tmode.getCost(), destmode.getCost(), -6)&&tmode.getDurationDouble()>destmode.getDurationDouble()
				||FuncLib.LessDouble(tmode.getCost(), destmode.getCost(), -6))
				{
					destmode=tmode;
				}
			}
		}
		return destmode;
	}
	/**
	 * ѡ������˵�ģ̬��ִ��ʱ�����
	 * @return
	 */
	public IMode getLongestCheapestMode()
	{
		IMode selmode=null;
		//ѡ������˵ģ�����ִ��ʱ�����
	
		for(int j=0;j<modes.size();j++)
		{
			IMode tempmode=modes.get(j);
			if(selmode==null
			||FuncLib.EqualDouble(tempmode.getCost(), selmode.getCost(),-6)&&tempmode.getDurationDouble()>selmode.getDurationDouble()
			||FuncLib.LessDouble(tempmode.getCost(), selmode.getCost(),-6))
			{
				selmode=tempmode;
			}
		}
		return selmode;
	}
	@Override
	public IMode getMode(VMconfig VMtype) {
		// TODO Auto-generated method stub
		for(int j=0;j<modes.size();j++)
		{
			IMode tempmode=modes.get(j);
			if(tempmode.getVMType()==VMtype)
			{
				return tempmode;
			}
		}
		return null;
	}
	/**
	 * Modes
	 */
	private ArrayList<IMode> modes=new ArrayList<IMode>();
	@Override
	public ArrayList<IMode> getModes() {
		// TODO Auto-generated method stub
		return modes;
	}
	@Override
	public void AddMode(IMode md)
	{
		modes.add(md);
	/*	this.djb.setModenum(new BigDecimal(modes.size()));
		String strmodes="|";
		for(int i=0;i<modes.size();i++)
		{
			IMode cmode=modes.get(i);
			strmodes+=cmode.getDuration()+"-"+cmode.getCost();
			strmodes+="|";
		}
		this.djb.setModes(strmodes);*/
	}
	
	@Override
	public String getJobString() {
		// TODO Auto-generated method stub
		String strjb="";
		strjb+="name:"+this.name;
		strjb+=",index:"+this.index;
		strjb+=",softunit:"+this.SoftUnit;
		strjb+=",CPUTASK:"+this.CPUTASK;
		strjb+=",MEMTASK:"+this.MEMTASK;
		strjb+=",sucessors:";
		Enumeration<IJob> jbiter=successortable.elements();
		while(jbiter.hasMoreElements())
		{
			IJob surjb=jbiter.nextElement();
			strjb+=surjb.getGUID()+"|";
		}
		strjb+=",datatransfer:";
		NumberFormat format1 = NumberFormat.getInstance();  
		format1.setMinimumFractionDigits( 0 );   
		format1.setMaximumFractionDigits(0); 
		format1.setGroupingUsed(false);
		Enumeration<IJob> preiter=predecessortable.elements();
		while(preiter.hasMoreElements())
		{
			IJob prejb=preiter.nextElement();
			Double transfer=this.datatransferfrom.get(prejb.getGUID());
			if(transfer==null)
				transfer=0d;
			strjb+=prejb.getGUID()+"-"+format1.format(transfer)+"|";
		}
		
		NumberFormat format = NumberFormat.getInstance();  
		format.setMinimumFractionDigits( 0 );   
		format.setMaximumFractionDigits(8); 
		format.setGroupingUsed(false);
		strjb+=",modes:";
		for(int i=0;i<modes.size();i++)
		{
			IMode mode=modes.get(i);
			String strduration=format.format(mode.getDurationDouble());
			strjb+=strduration+"-"+mode.getTransferTime()+"-"+mode.getVMType()+"-"+mode.getUnitnum()+"|";
		 }
		return strjb;
	}
	@Override
	public String getSoftUnit() {
		// TODO Auto-generated method stub
		return this.SoftUnit;
	}
	@Override
	public void setSoftUnit(String su) {
		// TODO Auto-generated method stub
		this.SoftUnit=su;
	}
	@Override
	public TASKTYPE getTASKTYPE() {
		// TODO Auto-generated method stub
		return ttype;
	}
	@Override
	public void setTASKTYPE(TASKTYPE type) {
		// TODO Auto-generated method stub
		this.ttype=type;
	}
	
	
	@Override
	public double getMaximumDatatransfertime(double bandwidth) {
		// TODO Auto-generated method stub
		double datatransfertime=0;
		for (FileItem file : getTask().getFileList()) {
			 if (!file.isRealInputFile(getTask().getFileList()))
				 	continue;
				double transtime = file.getSize() / (double) Consts.MILLION / bandwidth;
				datatransfertime += transtime;
			
		}
	
		return datatransfertime;
	}
	private double getEstimatedDataTransferTimeOnnewVM(Task ctask,VMconfig conf,Map<Integer, DatacenterCharacteristics> datacenterCharacteristicsList)
	{
		 double datatransfertime=0;
		 List<FileItem> fList = ctask.getFileList();
	     for (FileItem file : fList) 
	     {
	        if (file.isRealInputFile(fList))//output file
	        {
	        	 switch (SystemSetting.getFileSystem()) {
                 case SHARED:
                	 double maxRate = Double.MIN_VALUE;
                	 for(DatacenterCharacteristics chalist:datacenterCharacteristicsList.values())
                	 {
                		 IntervalDataCenterCharacteristics intchalist=(IntervalDataCenterCharacteristics)chalist;
                		 for (Storage storage : intchalist.getStorageList()) {
                             double rate = storage.getMaxTransferRate();//in M/s
                             if (rate > maxRate) {
                                 maxRate = rate;
                             }
                         }
                	 }
                     
                	 datatransfertime += file.getSize() / (double) Consts.MILLION / maxRate;
                	 
                     break;
                 case LOCAL:
                     double maxbandRate =conf.getBw();//no output source, the trasnfer only depends on the current vm
                   
	        	 	 if ( maxbandRate> 0.0) {
	        	 		datatransfertime += file.getSize() / (double) Consts.MILLION / maxbandRate;
	        	 	 }
                     break;
	        	 }
	        }
	     }
	     return datatransfertime;
	}
	@Override
	/**
	 * ����strjb����job����
	 */
	public void Construct(Task tsk,Map<Integer, DatacenterCharacteristics> datacenterCharacteristicsList)
	{
		
		this.name=tsk.getTaskname();

		this.index=tsk.getIndex();
	
		this.SoftUnit=tsk.getType();
	    this.task=tsk;
	//�����������ڲ�ͬ����������ϵ�ִ��ģ̬
	    for(DatacenterCharacteristics chalist:datacenterCharacteristicsList.values())
    	 {
    		 IntervalDataCenterCharacteristics intchalist=(IntervalDataCenterCharacteristics)chalist;
    		 for(VMconfig conf:intchalist.getVMconfiglist().values())
    		 {
    				double exetime= tsk.getCloudletLength()/conf.getMips();
    				double dtsize=0;
    				for(FileItem file:task.getFileList())
    				{
    					dtsize+=file.getSize();
    				}
    				exetime+=dtsize/(double) Consts.MILLION/conf.getRam();//�ڴ�����ʱ��
	    			double transfertime=getEstimatedDataTransferTimeOnnewVM(tsk,conf,datacenterCharacteristicsList);
    				double duration=exetime+transfertime;	
    				IMode md=new Mode();
    				
    			
    				//md.setDuration(duration);
    				md.setDurationDouble(exetime);
    				md.setTransferTime(transfertime);
    				md.setVMType(conf);
    				
					/**
					 * //duration�ǰ�����㣬price�ǰ�Сʱ�շ�
					 */
					double cost=conf.getPrice()*duration/conf.getInterval();
					md.setCost(cost);
    				modes.add(md);
    		 }
    	 }
			
				
							
			
		/*if((this.name.indexOf("start")>=0||this.name.indexOf("end")>=0)&&modes.size()==0)
		{
			//
			IMode md=new Mode();
			//md.setDuration(0);
			md.setDurationDouble(0);
			md.setTransferTime(0);
			md.setVMType("startorend");
			modes.add(md);
		}*/
		/*if(this.djb==null)
			return;
		String strmodes=this.djb.getModes();
		ArrayList<String> modearray=new ArrayList<String>();
		if(strmodes!=null)
		{
			String[] strmodearray=strmodes.split("\\|");
			modearray.clear();
			for(int i=0;i<strmodearray.length;i++)
			{
				String strtemp=strmodearray[i];
				if(strtemp==null||strtemp.equalsIgnoreCase(""))
					continue;
				String[] items=strtemp.split("-");
					try
					{
						int duration=Integer.valueOf(items[0]);
						int cost=Integer.valueOf(items[1]);
						IMode md=new Mode();
						md.setCost(cost);
						md.setDuration(duration);
						for(int m=2;m<items.length;m++)
						{
							String[] pair=items[m].split(":"); 
							Slot slot=new Slot();
							if(pair.length==2)
							{
								slot.setStartTime(Integer.valueOf(pair[0]));
								slot.setEndTime(Integer.valueOf(pair[1]));
								md.AddFreetimeslot(slot);
							}
							
						}
						modes.add(md);
					}catch(Exception e)
					{
						Clog.LogError("Job:Construct()", e);
					}
				
			}
		}
		//��mode��duration����˳������
		for(int i=0;i<modes.size();i++)
		{
			int min=-1;
			IMode minmode=null;
			for(int j=i;j<modes.size();j++)
			{
				IMode md=modes.get(j);
				if(min==-1||md.getDuration()<min)
				{
					min=md.getDuration();
					minmode=md;
				}
			}
			if(minmode!=null)
			{
				modes.remove(minmode);
				modes.add(i, minmode);
			}
		}*/
		
	}
}
