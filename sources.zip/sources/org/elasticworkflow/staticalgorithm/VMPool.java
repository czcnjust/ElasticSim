package org.elasticworkflow.staticalgorithm;

import java.util.ArrayList;
/**
 * @author czc
 *
 */
public class VMPool {
	
	/**
	 * ���������
	 */
	private static ArrayList<VirtualMachine> VMArray=new ArrayList<VirtualMachine>();

	public  static ArrayList<VirtualMachine> getVMArray() {
		if(VMArray.size()==0)
		{
			construct();
		}
		return VMArray;
	}

	public static void setVMArray(ArrayList<VirtualMachine> vMArray) {
		VMArray = vMArray;
	}
	
	public static VirtualMachine getVirtualMachine(String name)
	{
		if(VMArray.size()==0)
		{
			construct();
		}
		for(int i=0;i<VMArray.size();i++)
		{
			if(VMArray.get(i).getName().endsWith(name))
				return VMArray.get(i);
		}
		return null;
	}
	private static void construct() {
		VMArray.clear();
		String[] Names=new String[]{"N_S","N_M","N_L","N_EL","M_EL","M_DEL","M_QEL","C_M","C_EL"};
		String[] CPUS=new String[]{"1","2","4","8","6.5","13","26","5","20"};
		String[] MEMS=new String[]{"1.7","3.75","7.5","15","17.1","34.2","68.4","1.7","7"};
		String[] IOS=new String[]{"1","1","1","1","1","1","1","1","1"};
		String[] PricesS=new String[]{"0.06","0.12","0.24","0.48","0.41","0.82","1.64","0.145","0.58"};
		for(int i=0;i<CPUS.length;i++)
		{
			VirtualMachine VM=new VirtualMachine();
			VM.setName(Names[i]);
			VM.setCPU(Double.valueOf(CPUS[i]));
			VM.setMEM(Double.valueOf(MEMS[i]));
			VM.setIO(Double.valueOf(IOS[i]));
			VM.setPrice(Double.valueOf(PricesS[i]));
			VMArray.add(VM);
		}
	}
	
}
