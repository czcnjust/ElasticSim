package org.elasticworkflow.staticalgorithm;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.graphics.Image;
import org.elasticworkflow.intervalpricing.*;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import swing2swt.layout.BorderLayout;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.widgets.Scale;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.wb.swt.SWTResourceManager;
import org.elasticworkflow.intervalpricing.*;
import org.elasticworkflow.SystemSetting;
public class DisplayState extends Composite {

	private ServerInstancePool spool=null;
	private RequestQueue reqqueue=null;
	private int leftmargin=100;
	private int oneitemheight=15;
	private int vergap=20;
	private long starttime=0;//��ʼ��ʾ��ʱ��
	private long currenttime=0;
	private long duetime=0;//������ʾ��ʱ��
	private double pixrate=0.04;
	private Composite composite;
	private HashMap<IJob, Color> colorMap=new HashMap<IJob, Color>();
	private ScrolledComposite scrolledComposite;
	private HashMap<VMInstance,Rectangle> recs=new HashMap<VMInstance,Rectangle>();//��¼ÿ�������ʵ����λ��
	private String shuoming="";
	private int Pox=0;
	private boolean DisSU=true;
	private Table table;
	//private TableItem tableItem ;
	//private TableItem tableItem_1;
	private TableColumn tblclmnNewColumn;
	private TableColumn tblclmnNewColumn_1;
	private Composite composite_2;
	private SashForm sashForm;
	private Composite composite_3;
	private Scale scale;
	private Label label;
	private Button button;
	private Button btnSave;
	public boolean isDisSU() {
		return DisSU;
	}
	public void setDisSU(boolean disSU) {
		DisSU = disSU;
		recs.clear();
		composite.redraw();
	}
	public ServerInstancePool getSpool() {
		return spool;
	}
	public void setSpool(ServerInstancePool spool) {
		this.spool = spool;
	}
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public DisplayState(Composite parent, int style,ServerInstancePool ppool) {
		super(parent, style);
		this.spool=ppool;
		
		setLayout(new FillLayout());
		Composite composite_1 = new Composite(this, SWT.NONE);
				composite_1.setLayout(new BorderLayout(0, 0));
				
				sashForm = new SashForm(composite_1, SWT.NONE);
				sashForm.setLayoutData(BorderLayout.CENTER);
				sashForm.setOrientation(SWT.VERTICAL);
				
				
						
						scrolledComposite = new ScrolledComposite(sashForm, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
						//scrolledComposite.setLayout();
						
						
								scrolledComposite.setExpandHorizontal(true);
								scrolledComposite.setExpandVertical(true);
								
								composite = new Composite(scrolledComposite, SWT.NONE);
								composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
								composite.addMouseListener(new MouseAdapter() {
									@Override
									public void mouseDoubleClick(MouseEvent e) {
										SHowSlotInfo(e);
									}
								});
								composite.setLayout(new FillLayout(SWT.HORIZONTAL));
								
								
								composite.addPaintListener(new PaintListener() {
									public void paintControl(PaintEvent arg0) {
										MYpaintControl(arg0);
									}
								});
								//scrolledComposite.setBounds(0, 0, 1000, 500);
								//composite.setSize(1000,500);
								
								scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));
								scrolledComposite.setContent(composite);
								
								composite_2 = new Composite(sashForm, SWT.NONE);
								FillLayout fl_composite_2 = new FillLayout(SWT.HORIZONTAL);
								composite_2.setLayout(fl_composite_2);
								
								table = new Table(composite_2, SWT.BORDER | SWT.FULL_SELECTION);
								table.setHeaderVisible(true);
								table.setLinesVisible(true);
								
								//tableItem = new TableItem(table, SWT.NONE);
								//tableItem.setText("New TableItem");
								
								//tableItem_1 = new TableItem(table, SWT.NONE);
								
								tblclmnNewColumn = new TableColumn(table, SWT.NONE);
								tblclmnNewColumn.setWidth(100);
								tblclmnNewColumn.setText("Item");
								
								tblclmnNewColumn_1 = new TableColumn(table, SWT.NONE);
								tblclmnNewColumn_1.setWidth(327);
								tblclmnNewColumn_1.setText("Value");
								sashForm.setWeights(new int[] {301, 76});
								
								composite_3 = new Composite(composite_1, SWT.NONE);
								composite_3.setLayoutData(BorderLayout.WEST);
								composite_3.setLayout(new FillLayout(SWT.VERTICAL));
								
								scale = new Scale(composite_3, SWT.VERTICAL);
								scale.addSelectionListener(new SelectionAdapter() {
									@Override
									public void widgetSelected(SelectionEvent e) {
										ChangeScale(e);
									}
								});
								scale.setMinimum(1);
								
								label = new Label(composite_3, SWT.CENTER);
								label.setText("Max");
								
								button = new Button(composite_3, SWT.CHECK);
								button.addSelectionListener(new SelectionAdapter() {
									@Override
									public void widgetSelected(SelectionEvent e) {
										ChangeDisplaySU();
									}
								});
								button.setText("SU");
								button.setSelection(true);
								
								btnSave = new Button(composite_3, SWT.NONE);
								btnSave.addSelectionListener(new SelectionAdapter() {
									@Override
									public void widgetSelected(SelectionEvent e) {
										SaveImage();
									}
								});
								btnSave.setText("Save");
				//tableItem_1.setText("New TableItem");
				//composite.setSize(1000,500);
			
				//composite.layout();
		

	}
	private void SaveImage()
	{
		FileDialog dlg=new FileDialog(this.getShell(),SWT.SAVE);
		dlg.setFilterExtensions(new String[]{"*.jpg"});
		dlg.open();
		String path=dlg.getFilterPath()+"\\"+dlg.getFileName();
		
		Rectangle clientArea =composite.getBounds() ;//��ȡ�ͻ�����С
		Image image = new Image(this.composite.getDisplay(), clientArea.width, clientArea.height);
		GC gc = new GC(image);//���� GC
		ShowImage(gc,clientArea.width,clientArea.height);
	
		ImageData imageData = image.getImageData();
		ImageLoader imageLoader = new ImageLoader();
		imageLoader.data = new ImageData[]{imageData};
		imageLoader.save(path, SWT.BITMAP);//�� PNG �ķ�ʽ����ΪͼƬ
		
		image.dispose();
		gc.dispose();
		MessageBox box=new MessageBox(this.getShell());
		box.setMessage("Ok");
		box.open();
		
	}
	private void ChangeDisplaySU()
	{
		setDisSU(button.getSelection());
	}
	private void ChangeScale(SelectionEvent e)
	{
		ChangeScale((double)(scale.getSelection())/100);
	}
	private void SHowSlotInfo(MouseEvent e)
	{
		Iterator<VMInstance> iter= recs.keySet().iterator();
		while(iter.hasNext())
		{
			VMInstance ins=iter.next();
			Rectangle rec=recs.get(ins);
			if(rec.y<=e.y&&e.y<=rec.y+rec.height)
			{
				ArrayList<TimeSlot> usedslots=ins.getUsedslots();
				int AVTextX=0;
				for(int i=0;i<usedslots.size();i++)
				{
					TimeSlot slot=usedslots.get(i);
					int begin=leftmargin+(int)Math.round((slot.getDfrom()-starttime)*this.pixrate);
					int width=(int)Math.ceil((slot.getDto()-slot.getDfrom())*this.pixrate);
					if(width==0)
						width=1;
					
					IJob asjb= slot.getAssignedjb();
					if(e.x>=begin&&e.x<=begin+width)
					{
						double exetime=0;
						if(asjb.getSelMode()!=null)
							exetime=asjb.getSelMode().getDurationDouble();
						else
						{
							IMode selmode=asjb.getMode(slot.getVmins().getVMType());
							exetime=selmode.getDurationDouble();
						}
							
						double sfsetuptime=0;
						if(slot.isReinstalledSU())
							sfsetuptime=	SystemSetting.susetuptime;
						double datatransfertime=slot.getDatatransfertime();
						double estime=0;
						Enumeration<IJob> predeiter=asjb.getPredecessor().elements();
						while(predeiter.hasMoreElements())
						{
							IJob prejb=predeiter.nextElement();
							if(prejb.getAssiganedslot()!=null
									&&prejb.getAssiganedslot().getDto()>estime)
								estime=prejb.getAssiganedslot().getDto();
						}
						this.shuoming="Jb:"+asjb.getGUID()+" , Deadline: "+asjb.getDeadline()+",estime:"+estime+", SoftUnit: "+asjb.getSoftUnit()+",datatransfertime:"+datatransfertime+",exetime:"+exetime+", From:"+slot.getDfrom()+", To:"+slot.getDto()+", SU resetup:"+slot.isReinstalledSU()
						+"Actualtransferfile:"+slot.getTransferedfiles();
						//composite.redraw(0, 0, composite.getSize().x, this.vergap-1,false); 
						MessageBox ms=new MessageBox(this.getShell());
						ms.setMessage(this.shuoming);
						ms.open();
						//Pox=e.x;
						break;
					}
				}
			}
		}
	}
	/**
	 * �ı���ʵ����
	 * @param ppix
	 */
	public void ChangeScale(double ppix)
	{
		this.pixrate=ppix;
		recs.clear();
		ArrayList<VMInstance> instances=spool.getInstances();
		int height= instances.size()*(oneitemheight+vergap);
		int width= (int)((duetime-starttime)*pixrate)+100+this.leftmargin;
		//composite.setBounds(0, 0, width, height);
		
		//width=composite.getSize().x;
		scrolledComposite.setMinSize(width+2,height+2);
		composite.setSize(width, height);
		composite.redraw();
	}
	public void ClockJump(long stime,long ctime,long dtime,RequestQueue rq)
	{
		this.reqqueue=rq;
		colorMap.clear();
		recs.clear();
		starttime=stime;
		currenttime=ctime;
		duetime=dtime;
		ArrayList<VMInstance> instances=spool.getInstances();
		int height= instances.size()*(oneitemheight+vergap);
		int width= (int)((duetime-starttime)*pixrate)+100+this.leftmargin;
		//composite.setBounds(0, 0, width, height);
		
		//width=composite.getSize().x;
		scrolledComposite.setMinSize(width+2,height+2);
		composite.setSize(width, height);
		composite.redraw();
		table.removeAll();
		double rental=0;
		for(int i=0;i<instances.size();i++)
		{
			VMInstance ins=instances.get(i);
			VMconfig conf=ins.getVMType();
		
			rental+=conf.getPrice()*ins.getRentedHours();
			TableItem tableItem=new TableItem(table, SWT.NONE);
			tableItem.setText(new String[]{ins.getGuid(),String.valueOf(conf.getPrice()*ins.getRentedHours())+"="+String.valueOf(conf.getPrice())+"*"+String.valueOf(ins.getRentedHours())});
		}
		TableItem tableItem=new TableItem(table, SWT.NONE);
		tableItem.setText(new String[]{"Total",String.valueOf(spool.getRentalofAllResources())});
		
		TableItem tableItem1=new TableItem(table, SWT.NONE);
		tableItem1.setText(new String[]{"Use Rate",String.valueOf(spool.getAverageUseRate())});
		//composite_2.setSize(table.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		WorkflowRequest req=reqqueue.getRequestArray().get(0);
		TableItem tableItem2=new TableItem(table, SWT.NONE);
		tableItem2.setText(new String[]{"DataTransfer Rate",String.valueOf(req.getDataTransferRate())});
		TableItem tableItem3=new TableItem(table, SWT.NONE);
		tableItem3.setText(new String[]{"SoftwareResetup Rate",String.valueOf(req.getSoftwareResetupRate())});
		//tableItem.setText();
		
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
	public void ShowImage(GC gc,int width,int height)
	{
		ArrayList<VirtualMachine> vmtypes=VMPool.getVMArray();
		ArrayList<VMInstance> instances=spool.getInstances();
		if(instances.size()==0)
			return;
		Color col = new Color(this.getDisplay(),255, 255, 255);
		gc.setBackground(col);
		gc.fillRectangle(0, 0, width, height);
		gc.drawRectangle(width-100, 0, 50, 50);
		gc.drawString(this.shuoming, this.Pox, 2,false);
		
		
	
		//gc.drawLine(leftmargin, vergap, leftmargin,height-vergap);
		recs.clear();
		int BaseY=0;
		//for(int t=0;t<vmtypes.size();t++)
		//{
		//	VirtualMachine vm=vmtypes.get(t);
			for(int i=0;i<instances.size();i++)
			{
				VMInstance ins=instances.get(i);
				//if(ins.getVMType().equalsIgnoreCase(vm.getName()))
				//{
					DisplayOneInstace(ins,gc,BaseY,width,height);
					BaseY+=oneitemheight+vergap;
			//	}
			}
		//}
	}
	public void MYpaintControl(final PaintEvent arg0) {	
		
		if(spool==null)
			return;
		
		
		int width=composite.getSize().x;
		int height=composite.getSize().y;
		//arg0.gc.dispose();
		
		Image image = new Image(this.getDisplay(),width ,height);
		GC gc=new GC(image);
		ShowImage(gc,width,height);
		//arg0.gc=gc;
		
		arg0.gc.drawImage(image, 0, 0);
		gc.dispose();
		image.dispose();	
	}
	private boolean DisplayOneInstace(VMInstance ins,GC gc,int BaseY,int pwidth,int pheight)
	{
		
		Random r = new Random();
		VMconfig conf=ins.getVMType();
		int Y1=BaseY+this.vergap;
		int totalwidth= (int)((duetime-starttime)*pixrate);//10����һ�����ص㣬����һ����һ��
		Color linecolor = new Color(this.getDisplay(),255, 255, 255);
		gc.setBackground(linecolor);
		gc.setLineWidth(2);
		if(ins.getGuid().equalsIgnoreCase("C_M_72"))
		{
			int a=0;
		}
		//gc.drawLine(leftmargin, Y1, totalwidth, Y1);
		//gc.drawLine(leftmargin, Y1+oneitemheight, totalwidth, Y1+oneitemheight);
		//gc.drawRectangle(leftmargin, Y1, totalwidth, oneitemheight);
		gc.drawLine(leftmargin+(int)Math.round((ins.getStartrentingtime()-starttime)*this.pixrate), Y1+oneitemheight+3, leftmargin+totalwidth, Y1+oneitemheight+3);
		recs.put(ins, new Rectangle(leftmargin+(int)ins.getStartrentingtime()-(int)starttime, Y1, totalwidth, oneitemheight));
		gc.drawString(ins.getGuid(), 0, Y1,true);
		
	
		//gc.setForeground(linecolor);
		gc.setBackground(linecolor);
		int hourpoint=this.leftmargin+(int)((ins.getStartrentingtime()-starttime)*this.pixrate);
		
		while(hourpoint<leftmargin+totalwidth)
		{
			
			gc.drawLine(hourpoint, Y1+oneitemheight+3, hourpoint, Y1+oneitemheight+9);
			hourpoint+=Math.ceil(conf.getInterval()*this.pixrate);
		}
		gc.setLineWidth(1);
		ArrayList<TimeSlot> usedslots=ins.getUsedslots();
		int AVTextX=0,base2=0;
		for(int i=0;i<usedslots.size();i++)
		{
			TimeSlot slot=usedslots.get(i);
			int begin=leftmargin+(int)Math.round((slot.getDfrom()-starttime)*this.pixrate);
			int width=(int)Math.ceil((slot.getDto()-slot.getDfrom())*this.pixrate);
			if(begin+width>composite.getSize().x)
			{
				this.shuoming="��������";
			}
			if(width==0)
				width=1;
		
			
			IJob asjb= slot.getAssignedjb();
			
			if(asjb==null)
			{
				continue;
			}
			double exetime=0;
			if(asjb.getSelMode()!=null)
				exetime=asjb.getSelMode().getDurationDouble();
			else
			{
				IMode selmode=asjb.getMode(slot.getVmins().getVMType());
				exetime=selmode.getDurationDouble();
			}
			double sfsetuptime=0;
			if(slot.isReinstalledSU())
				sfsetuptime=	SystemSetting.susetuptime;
			double datatransfertime=slot.getDatatransfertime();
			int sfwidth=(int)Math.ceil((sfsetuptime)*this.pixrate);
			int datawidth=(int)Math.ceil((datatransfertime)*this.pixrate);
			
			String sunit=asjb.getSoftUnit();
			
			Color color=null; 
			if(colorMap.containsKey(asjb))
				color=colorMap.get(asjb);
			else
			{
				color = new Color(getDisplay(),r.nextInt(250), r.nextInt(250), r.nextInt(250));
				colorMap.put(asjb, color);
			}
			String cap=asjb.getGUID();
			int pos=cap.indexOf("ID");
			if(pos>0)
			{
				cap=cap.substring(pos+2, cap.length());
				try
				{
					int va=Integer.valueOf(cap);
					cap=String.valueOf(va);
				}catch(Exception e)
				{
					
				}
			}
			if(sfwidth>0)
			{
				gc.setBackground(new Color(this.getDisplay(),0,0,0));
				gc.fillRectangle(begin, Y1+10, sfwidth, oneitemheight-20);
			}
			if(datawidth>0)
			{
				gc.setBackground(new Color(this.getDisplay(),52,100,100));
				gc.fillRectangle(begin+sfwidth, Y1+10, datawidth, oneitemheight-20);
			}
			
			gc.setBackground(color);
			if(sfwidth>0||datawidth>0)
			{
				int minwidth=Math.max(1, width-sfwidth-datawidth);
				gc.fillRectangle(begin+sfwidth+datawidth, Y1,minwidth , oneitemheight);
			}
			else
				gc.fillRectangle(begin, Y1, width, oneitemheight);
			
			if(this.DisSU)
			{
				if(sfwidth>0||datawidth>0)
					gc.drawString(cap, begin+sfwidth+datawidth, Y1+1,true);
				else
					gc.drawString(cap, begin, Y1+1,true);
			}
			//base2=
			int start=begin;
			if(begin<AVTextX)
			{
				start=AVTextX;
			}
			if(this.DisSU)
				gc.drawString("("+i+")"+asjb.getSoftUnit()+",", start, Y1+oneitemheight+1,true);
			AVTextX=start+gc.textExtent("("+i+")"+asjb.getSoftUnit()+",").x+2;
		}
		return true;
	}
}
