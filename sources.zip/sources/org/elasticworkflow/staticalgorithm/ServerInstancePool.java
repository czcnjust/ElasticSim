/**
 * 
 */
package org.elasticworkflow.staticalgorithm;

import java.util.ArrayList;
import java.util.Hashtable;

import org.elasticworkflow.intervalpricing.*;

/**
 * @author czc
 *
 */
public class ServerInstancePool {
	private double CroudDistance=Double.MAX_VALUE;
	public double getCroudDistance() {
		return CroudDistance;
	}
	public void setCroudDistance(double croudDistance) {
		CroudDistance = croudDistance;
	}
	private ArrayList<VMInstance> instances=new ArrayList<VMInstance>();
	
	/**
	 * ����jb��Ӧ��TimeSlot
	 * @param jb
	 * @return
	 */
	public TimeSlot getJobAssignedSLot(IJob jb)
	{
		for(int i=0;i<instances.size();i++)
		{
			VMInstance ins=instances.get(i);
			TimeSlot slot=ins.getJobmap().get(jb);
			if(slot!=null)
				return slot;
		}
		return null;
	}
	public VMInstance getVMInstance(String name)
	{
		for(int i=0;i<instances.size();i++)
		{
			VMInstance ins=instances.get(i);
			if(ins.getGuid().equalsIgnoreCase(name))
				return ins;
		}
		return null;
	}
	public ServerInstancePool Clone()
	{
		ServerInstancePool newpool=new ServerInstancePool();
		for(int i=0;i<instances.size();i++)
		{
			VMInstance ins=instances.get(i);
			VMInstance newins=ins.Clone();
			newpool.AddNewServerInstances(newins);
		}
		return newpool;
	}
	/**
	 * 
	 */
	public ServerInstancePool() {
		// TODO Auto-generated constructor stub
	}
	public void AddNewServerInstances(VMInstance newins)
	{
		instances.add(newins);
	}
	public boolean RemoveServerInstancesByGuid(VMInstance newins)
	{
		for(int i=0;i<instances.size();i++)
		{
			VMInstance ins=instances.get(i);
			if(ins.getGuid().equalsIgnoreCase(newins.getGuid()))
			{
				instances.remove(ins);
				return true;
			}
		}
		return false;
	}
	public boolean RemoveServerInstances(VMInstance newins)
	{
		if(instances.contains(newins))
		{
			instances.remove(newins);
			return true;
		}
		
		return false;
	}
	public VMInstance AddNewServerInstances(VMconfig VMtype)
	{
		VMInstance sinstance=new VMInstance(VMtype);
		instances.add(sinstance);
		return sinstance;
	}

	public ArrayList<VMInstance> getInstances() {
		return instances;
	}
	
	/**
	 * ����ָ�����͵������ʵ��
	 * @param vmtype
	 * @return
	 */
	public ArrayList<VMInstance> getInstancesByType(VMconfig vmtype)
	{
		ArrayList<VMInstance> temparray=new ArrayList<VMInstance>();
		for(int i=0;i<instances.size();i++)
		{
			VMInstance ins=instances.get(i);
			if(ins.getVMType()==vmtype)
			{
				temparray.add(ins);
			}
		}
		return temparray;
	}
	/**
	 * ���ݸ��� ��ʱ�����䣬����ʱ��Ƭ
	 * @param begin
	 * @param end
	 * @return
	 */
	public ArrayList<TimeSlot> getTimeSlot(double begin,double end)
	{
		ArrayList<TimeSlot> destlist=new ArrayList<TimeSlot>();//Ŀ�����ʱ��Ƭ
		for(int i=0;i<instances.size();i++)
		{
			VMInstance ins=instances.get(i);
			
			/*VirtualMachine vm=VMPool.getVirtualMachine(ins.getVMType());
			if(vm==null)
				continue;*/
		
			ArrayList<TimeSlot> freeslots=ins.getFreeTimeSlot(begin, end);
			for(int j=0;j<freeslots.size();j++)
			{
				TimeSlot tslot=freeslots.get(j);
				destlist.add(tslot);
			}
		}
		return destlist;
	}
	/**
	 * ��ȡ���������ʵ�������޳ɱ�
	 * @return
	 */
	public double getRentalofAllResources()
	{
		double rental=0;
		for(int i=0;i<instances.size();i++)
		{
			VMInstance ins=instances.get(i);
			
		/*	VirtualMachine vm=VMPool.getVirtualMachine(ins.getVMType());
			if(vm==null)
				continue;*/
			rental+=ins.getVMType().getPrice()*ins.getRentedHours();
		}
		return rental;
	}
	
	/**
	 * ��ȡ�����������ʹ�ñ�������֮���˷���
	 * @return
	 */
	public double getAverageUseRate()
	{
		double rate=0;
		int number=0;
		for(int i=0;i<instances.size();i++)
		{
			VMInstance ins=instances.get(i);
			rate+=ins.getUseRate();
			number++;
		}
		if(number==0)
			return 1;
		return rate/number;
	}
	
	public void Clear()
	{
		instances.clear();
	}
	/**
	 * ��ȡ����Դ�������� ���� ����ʱ��
	 * @return
	 */
	public double getMaxTime()
	{
		double maxfinishtime=0;
		for(int i=0;i<instances.size();i++)
		{
			VMInstance ins=instances.get(i);
			ArrayList<TimeSlot> usedslots= ins.getUsedslots();
			TimeSlot lastslot=null;
			if(usedslots.size()>0)
				lastslot=usedslots.get(usedslots.size()-1);
			if(lastslot!=null)
			{
				if(lastslot.getDto()>maxfinishtime)
					maxfinishtime=lastslot.getDto();
			}
		}
		return maxfinishtime;
	}
	public void Destroy()
	{
		for(int i=0;i<instances.size();i++)
		{
			VMInstance ins=instances.get(i);
			ins.Destroy();
		}
		instances.clear();
	}
}
