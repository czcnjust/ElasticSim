package org.elasticworkflow.staticalgorithm;

public class Transferdata {

	private String filename;
	private String type;
	private String size;
	private String jbguid;
	public String getFilename() {
		return filename;
	}
	public String getJbguid() {
		return jbguid;
	}
	public void setJbguid(String jbguid) {
		this.jbguid = jbguid;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
}
