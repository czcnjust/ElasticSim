package org.elasticworkflow.staticalgorithm;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Enumeration;
public class Level implements ILevel{

	private Hashtable<String,SoftUnit> units=new Hashtable<String,SoftUnit>();
	private int level=0;
	
	public Level(int level) {
		super();
		this.level = level;
	}
	/**
	 * ���������ӵ���
	 * @param jb
	 * @return
	 */
	public boolean AddJob(IJob jb)
	{
		String jbunitname=jb.getSoftUnit();
		SoftUnit sunit=null;
		if(units.containsKey(jbunitname))
		{
			sunit=units.get(jbunitname);
		}
		else
		{
			sunit=new SoftUnit();
			sunit.setUnitname(jbunitname);
			units.put(jbunitname, sunit);
		}
		if(jb.getLevel()!=this.level)
			return false;
		return sunit.Addjb(jb);
		
	}
	public int getLevel() {
		return level;
	}
	/**
	 * ���ظò����е�������Ԫ
	 * @return
	 */
	public Enumeration<SoftUnit> getSoftUnits()
	{
		return units.elements();
	}
	/**
	 * ���ظò���е�����������Ϊunitname��������Ԫ
	 * @param unitname
	 * @return
	 */
	public SoftUnit getSoftUnit(String unitname)
	{
		if(units.containsKey(unitname))
		{
			return units.get(unitname);
		}
		else
			return null;
	}
}
