/**
 * 
 */
package org.elasticworkflow.staticalgorithm;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Vector;

/**
 * @author czc
 *
 */
public class WorkflowRequest {
	/**
	 * ������ĵ�ǰ״̬
	 */
	private RequestState state=RequestState.Suspended;
	/**
	 * �����渺�𵥸�����Ĵ���
	 */
	private IProject pjinstance;
	/**
	 * �洢������ĵ��Ƚ��
	 */
    private Schedule sh=new Schedule(); 
    /**
     * ������Ľ�ֹ��
     */
    private double duedate=0;
    public void setState(RequestState state) {
		this.state = state;
	}
   

	/**
     * ���㼶����
     */
    private Vector<ILevel> levels=null;
    /**
     * �Ѿ����ȵĻ
     */
    HashSet<IJob> scheduledset=new HashSet<IJob>();
    
	public HashSet<IJob> getScheduledset() {
		return scheduledset;
	}

	public void setLevels(Vector<ILevel> levels) {
		this.levels = levels;
	}

	public Vector<ILevel> getLevels() {
		return levels;
	}

	public double getDuedate() {
		return duedate;
	}

	public void setDuedate(double duedate) {
		this.duedate = duedate;
	}

	public Schedule getSh() {
		return sh;
	}
	public void setSh(Schedule psh)
	{
		this.sh=psh;
	}
	/**
	 * 
	 */
	public WorkflowRequest(IProject istance) {
		pjinstance=istance;
		// TODO Auto-generated constructor stub
	}
	/**
	 * ֪ͨ������ĳ������ִ�н�����
	 */
	 boolean NoticeJobFinished(IJob jb) {
		return true;
	}
	public RequestState getState() {
		return state;
	}
	public IProject getPjinstance() {
		return pjinstance;
	}
	
	/**
	 * ��ȡ�ܵ����ݴ������
	 * @return
	 */
	public double getDataTransferRate()
	{
		IProject pj=this.getPjinstance();
		int jobcount=pj.getJobNumber();
		double totaldata=0;
		double tdata=0;
		for(int i=1;i<=jobcount;i++)
		{
			IJob tempjb=pj.getJbindextable().get(i); 
			TimeSlot slot=tempjb.getAssiganedslot();
			if(slot==null)
				continue;
			/**
			 * �ж��Ƿ���Ҫ��������
			 */
			/*if(tempjb.getPredecessor()!=null)
			{
				Enumeration<IJob> predeiter=tempjb.getPredecessor().elements();
				while(predeiter.hasMoreElements())
				{
					IJob prejb=predeiter.nextElement();
					double data=tempjb.getInputData(prejb.getGUID());
					try
					{
						if(!prejb.getAssiganedslot().getVmins().equals(slot.getVmins()))
						{
							tdata+=data;
						}
						totaldata+=data;
					}catch(Exception e)
					{
						e.printStackTrace();
					}
				}
			}*/
		}
		return tdata/totaldata;
	}
	
	/**
	 * ��ȡ���°�װ������Ԫ�ı���
	 * @return
	 */
	public double getSoftwareResetupRate()
	{
		IProject pj=this.getPjinstance();
		int jobcount=pj.getJobNumber();
		if(jobcount==0)
			return 1;
		int installcount=0;
		for(int i=1;i<=jobcount;i++)
		{
			IJob tempjb=pj.getJbindextable().get(i);
			TimeSlot slot=tempjb.getAssiganedslot();
			/**
			 * �ж��Ƿ���Ҫ��װ������Ԫ
			 */
			if(slot!=null)
			{
				String preunit=slot.getPreSoftUnit();
				if((preunit==null||!preunit.equalsIgnoreCase(tempjb.getSoftUnit())))
				{
					installcount++;
				}
			}
		}
		double rate=Double.valueOf(installcount)/jobcount;
		return rate;
	}
	

}
