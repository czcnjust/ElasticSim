package org.elasticworkflow.staticalgorithm;

import java.util.ArrayList;

import org.elasticworkflow.intervalpricing.*;

public class Mode implements IMode {

	//private int duration;
	private double durationD;
	private double price;
	private boolean available=true;
	private double transfertime;
	private VMconfig VMType;
	public boolean isAvailable() {
		return available;
	}

	@Override
	public double getDurationDouble() {
		// TODO Auto-generated method stub
		return durationD;
	}

	@Override
	public void setDurationDouble(double duration) {
		// TODO Auto-generated method stub
		this.durationD=duration;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	//@Override
	//public int getDuration() {
		// TODO Auto-generated method stub
	//	return duration;
	//}

	//@Override
	//public void setDuration(int duration) {
		// TODO Auto-generated method stub
	//	this.duration=duration;
	//}

	@Override
	public double getCost() {
		// TODO Auto-generated method stub
		return price;
	}

	@Override
	public void setCost(double cost) {
		// TODO Auto-generated method stub
		this.price=cost;
	}

	@Override
	public double getTransferTime() {
		// TODO Auto-generated method stub
		return transfertime;
	}

	@Override
	public VMconfig getVMType() {
		// TODO Auto-generated method stub
		return this.VMType;
	}

	@Override
	public int getUnitnum() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setUnitnum(int unitnum) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setVMType(VMconfig VM) {
		// TODO Auto-generated method stub
		this.VMType=VM;
	}

	@Override
	public void setTransferTime(double time) {
		// TODO Auto-generated method stub
		this.transfertime=time;
	}


}
