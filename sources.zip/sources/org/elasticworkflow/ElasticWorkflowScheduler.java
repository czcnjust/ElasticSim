package org.elasticworkflow;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletScheduler;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.lists.VmList;
import org.elasticworkflow.SystemParameters.SchedulingAlgorithm;
import org.elasticworkflow.dynamicalgorithm.*;
import org.elasticworkflow.intervalpricing.*;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.elasticworkflow.staticalgorithm.*;
public class ElasticWorkflowScheduler extends DatacenterBroker {

	
	/**
	 * Cost of static algorithms
	 */
    private double staticalgorithmcost;
    
    private double deadlines;
    
	public double getDeadlines() {
		return deadlines;
	}
	public void setDeadlines(double deadlines) {
		this.deadlines = deadlines;
	}
	
	private double staticalfinishtime;
	private double actualfinishtime;
	
	public double getStaticalfinishtime() {
		return staticalfinishtime;
	}
	public void setStaticalfinishtime(double staticalfinishtime) {
		this.staticalfinishtime = staticalfinishtime;
	}
	public double getActualfinishtime() {
		return actualfinishtime;
	}
	public void setActualfinishtime(double actualfinishtime) {
		this.actualfinishtime = actualfinishtime;
	}
	public double getStaticalgorithmcost() {
		return staticalgorithmcost;
	}
	public void setStaticalgorithmcost(double staticalgorithmcost) {
		this.staticalgorithmcost = staticalgorithmcost;
	}
	/**
	 * The workflow list for executing
	 */
	 protected List<WorkflowInstance> workflowList;
	
	
	public List<WorkflowInstance> getWorkflowList() {
		return workflowList;
	}
	protected BaseElasticSchedulingAlgorithm scheduler;
    protected ElasticWorkflowPaser wpaser;
	public ElasticWorkflowScheduler(String name) throws Exception {
		super(name);
		// TODO Auto-generated constructor stub
		scheduler = getScheduler(SystemParameters.getSchedulingAlgorithm());
		workflowList=new ArrayList<>();
	}
	  /**
     * Binds this scheduler to a datacenter
     *
     * @param datacenterId data center id
     */
    public void bindSchedulerDatacenter(int datacenterId) {
        if (datacenterId <= 0) {
            Log.printLine("Error in data center id");
            return;
        }
        this.datacenterIdsList.add(datacenterId);
    }
	@Override
	public void startEntity() {
		// TODO Auto-generated method stub
		  Log.printLine(getName() + " is starting...");
	        // this resource should register to regional GIS.
	        // However, if not specified, then register to system GIS (the
	        // default CloudInformationService) entity.
	        //int gisID = CloudSim.getEntityId(regionalCisName);
	        int gisID = -1;
	        if (gisID == -1) {
	            gisID = CloudSim.getCloudInfoServiceEntityId();
	        }
	     
            //processPlanning();
            //processImpactFactors(getTaskList());
           
	        // send the registration to GIS
	        sendNow(gisID, CloudSimTags.REGISTER_RESOURCE, getId());
	        
	        sendNow(this.getId(), CloudSimTags.RESOURCE_CHARACTERISTICS_REQUEST, getId());
	        
	        //sendNow(this.getId(), WorkflowSimTags.JOB_SUBMIT,workflowList);
	}

	@Override
	public void processEvent(SimEvent ev) {
		// TODO Auto-generated method stub
		   switch (ev.getTag()) {
           // Resource characteristics request
           case CloudSimTags.RESOURCE_CHARACTERISTICS_REQUEST:
               processResourceCharacteristicsRequest(ev);
               break;
               // Resource characteristics answer
           case CloudSimTags.RESOURCE_CHARACTERISTICS:
               processResourceCharacteristics(ev);
               break;
           case CloudSimTags.VM_CREATE_ACK:
               processVmCreate(ev);
               break;
           case ElasticSimTags.CLOUDLET_UPDATE:
               processCloudletUpdate(ev);
               break;
           //this call is from workflow scheduler when all vms are created
           case CloudSimTags.CLOUDLET_SUBMIT:
              // submitJobs();
               break;
           case CloudSimTags.CLOUDLET_RETURN:
        	   processCloudletReturn(ev);
               break;
           case CloudSimTags.END_OF_SIMULATION:
               shutdownEntity();
               break;
           case ElasticSimTags.JOB_SUBMIT:
               processJobSubmit(ev);
               break;
           case  ElasticSimTags.VM_PRICINGPOINT:
        	   processVMPricingPoint(ev);
        	   break;
           default:
              /// processOtherEvent(ev);
               break;
       }
	}

	@Override
	public void shutdownEntity() {
		// TODO Auto-generated method stub
		  clearDatacenters();
	      Log.printLine(getName() + " is shutting down...");
	}
	
	/**
	 * New workflows are submitted by cloud user.
	 * @param ev
	 */
	protected void processJobSubmit(SimEvent ev) {
        List<WorkflowInstance> list = (List) ev.getData();
        if(list==null)
        	return;
        for(int i=0;i<list.size();i++)
        {
        	WorkflowInstance wfs=list.get(i);
        	workflowList.add(wfs);
        }
     //   list.clear();
        Log.printLine(this.getName()+"workflow instances have been submmited....");
    }
	 /**
     * Process a request for the characteristics of a PowerDatacenter.
     *
     * @param ev a SimEvent object
     * @pre ev != $null
     * @post $none
     */
    @Override
    protected void processResourceCharacteristicsRequest(SimEvent ev) {
    
        Log.printLine(CloudSim.clock() + ": " + getName() + ": Cloud Resource List received with "
                + getDatacenterIdsList().size() + " resource(s)");
        Log.printLine(this.getName()+"Sending request....");
        for (Integer datacenterId : getDatacenterIdsList()) {
            sendNow(datacenterId, CloudSimTags.RESOURCE_CHARACTERISTICS, getId());
        }
    }
    /**
	 * Process the return of a request for the characteristics of a PowerDatacenter.
	 * 
	 * @param ev a SimEvent object
	 * @pre ev != $null
	 * @post $none
	 */
	protected void processResourceCharacteristics(SimEvent ev) {
		
		DatacenterCharacteristics characteristics = (DatacenterCharacteristics) ev.getData();
		getDatacenterCharacteristicsList().put(characteristics.getId(), characteristics);
		 Log.printLine(CloudSim.clock() + ": " + getName() + " Received resource characteristics");
		/**
		 * If all of the characteristics has been returned, start to submit jobs
		 */
        if(getDatacenterCharacteristicsList().size()==getDatacenterIdsList().size())
        {
        	 Log.printLine(CloudSim.clock() + ": " + getName() + "Ready to starting executing");
        	sendNow(this.getId(), ElasticSimTags.CLOUDLET_UPDATE);
        }
	}
	/**
     * Switch between multiple schedulers. Based on algorithm.method
     *
     * @param name the SchedulingAlgorithm name
     * @return the algorithm that extends BaseSchedulingAlgorithm
     */
    private BaseElasticSchedulingAlgorithm getScheduler(SchedulingAlgorithm name) {
    	BaseElasticSchedulingAlgorithm algorithm;

        // choose which algorithm to use. Make sure you have add related enum in
        //Parameters.java
        switch (name) {
            //by default it is Static
         
            case STATIC:
            	algorithm=new DelegateAlgorithm(this,getDatacenterCharacteristicsList(),
                		this.getVmsToDatacentersMap());
            	break;
            default:
            	algorithm=new DelegateAlgorithm(this,getDatacenterCharacteristicsList(),
                		this.getVmsToDatacentersMap());
                break;

        }
        return algorithm;
    }
    /**
     * Process a cloudlet (job) return event.
     *
     * @param ev a SimEvent object
     * @pre ev != $null
     * @post $none
     */
    @Override
    protected void processCloudletReturn(SimEvent ev) {
        Cloudlet cloudlet = (Cloudlet) ev.getData();
        Task job = (Task) cloudlet;

        /**
         * Generate a failure if failure rate is not zeros.
         */
      //  FailureGenerator.generate(job);
        if (job.getCloudletStatus() == Cloudlet.FAILED) {
        	
            job.getParent().getJobsSubmittedList().remove(job);
            Log.printLine("����"+job.getTaskname()+"ִ��ʧ��///////////");
           
        }
        else
        {
        	Log.printLine("����"+job.getTaskname()+"ִ����ɣ������"+this.getCloudletReceivedList().size()+"������");
        	if(this.getCloudletReceivedList().size()==384)
        	{
        		int a=0;
        	}
        	job.getParent().getJobsCompletedList().add(job);
            job.getParent().getJobsSubmittedList().remove(job);
            this.getCloudletReceivedList().add(job);
            job.setTaskFinishTime(CloudSim.clock());//�����������ʱ��
        }
        
        
     
        schedule(this.getId(), 0.0, ElasticSimTags.CLOUDLET_UPDATE);

    }

	 /**
     * Update a cloudlet (job)
     *
     * @param ev a simEvent object
     */
    protected void processCloudletUpdate(SimEvent ev) {

        try {
            scheduler.Schedule();
        } catch (Exception e) {
            Log.printLine("Error in configuring scheduler_method");
            e.printStackTrace();
        }

    }
    
    /**
     * Process the ack received due to a request for VM creation.
     *
     * @param ev a SimEvent object
     * @pre ev != null
     * @post $none
     */
    @Override
    protected void processVmCreate(SimEvent ev) {
        int[] data = (int[]) ev.getData();
        int datacenterId = data[0];
        int vmId = data[1];
        int result = data[2];

        if (result == CloudSimTags.TRUE) {
            getVmsToDatacentersMap().put(vmId, datacenterId);
            /**
             * Fix a bug of cloudsim Don't add a null to getVmsCreatedList()
             * June 15, 2013
             */
            IntervalPricingVM newvm=VmList.getById(getVmList(), vmId);
            if (newvm != null) {
                getVmsCreatedList().add(newvm);
                Log.printLine(CloudSim.clock() + ": " + getName() + ": VM #" + vmId
                        + " has been created in Datacenter #" + datacenterId + ", Host #"
                        + VmList.getById(getVmsCreatedList(), vmId).getHost().getId());
              if(SystemSetting.getMainframe()!=null)
                SystemSetting.getMainframe().AddanVM(newvm); 
              scheduler.On_VMCreate(newvm);
              schedule(this.getId(), newvm.getConfig().getInterval(), ElasticSimTags.VM_PRICINGPOINT,newvm);
            }
            
        } else {
            Log.printLine(CloudSim.clock() + ": " + getName() + ": Creation of VM #" + vmId
                    + " failed in Datacenter #" + datacenterId);
        }

    }
    
    /**
     * One VM_DESTROY event is raised at each pricing point for each vm.
     * It is checked that whether the vm should be destroyed.
     * @param ev
     */
    protected void processVMPricingPoint(SimEvent ev) {
    
    	IntervalPricingVM vm =(IntervalPricingVM)ev.getData();
    	
    	if(scheduler.On_VMPricingPoint(vm))
    	{
    		
    		Log.printLine(CloudSim.clock() + ": " + getName() + ": Destroying VM #" + vm.getId());
    		sendNow(getVmsToDatacentersMap().get(vm.getId()), CloudSimTags.VM_DESTROY, vm);
    		getVmsCreatedList().remove(vm);
    	}
    	else
    	{
    		 schedule(this.getId(), vm.getConfig().getInterval(), ElasticSimTags.VM_PRICINGPOINT,vm);
    	}
    	
    }
    /**
     * agency of simentity sendnow
     * @param entityId
     * @param cloudSimTag
     * @param data
     */
    public void SendNowAgency(int entityId, int cloudSimTag, Object data)
    {
    	this.sendNow(entityId, cloudSimTag,data);
    }
}
