package org.elasticworkflow;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.HashSet;
import java.util.Iterator;


public class FuncLib {

	
	public static boolean EqualDouble(double a,double b,int digital)
	{
		double gap=a-b;
		
		if(Math.abs(gap)>Math.pow(10, digital))
		{
			return false;
		}
		else
			return true;
	}
	public static boolean EqualLessDouble(double a,double b,int digital)
	{
		if(a<b)
			return true;
		double gap=a-b;
		
		if(Math.abs(gap)>Math.pow(10, digital))
		{
			return false;
		}
		else
			return true;
	}
	public static boolean LessDouble(double a,double b,int digital)
	{
		double gap=a-b;
		if(Math.abs(gap)>Math.pow(10, digital))
		{
			if(a<b)
				return true;
			else
				return false;
		}
		else
			return false;
	}
}
