%Author: Zhicheng Cai, Nanjing University of Science and Technology, China

package timeseriesanalysis;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.elasticworkflow.ResultOutput;
import org.jdom2.Element;
import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;
import org.rosuda.JRI.RVector;
import java.util.ArrayList;
import org.eclipse.swt.widgets.Shell;
import javax.json.Json;
import javax.json.stream.JsonGenerator;


import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
public class TimeSeriesAnalysis_MarkoveSwitch {

	public TimeSeriesAnalysis_MarkoveSwitch() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		if (!Rengine.versionCheck()) {
		    System.err.println("** Version mismatch - Java files don't match library version.");
		    System.exit(1);
		}
	        System.out.println("Creating Rengine (with arguments)");
			// 1) we pass the arguments from the command line
			// 2) we won't use the main loop at first, we'll start it later
			//    (that's the "false" as second argument)
			// 3) the callbacks are implemented by the TextConsole class above
			Rengine re=new Rengine(null, false, new TextConsole());
	        System.out.println("Rengine created, waiting for R");
			// the engine creates R is a new thread, so we should wait until it's ready
	        if (!re.waitForR()) {
	            System.out.println("Cannot load R");
	            return;
	        }
	        REXP x;
			//x=re.eval("plot(c(2,4,5,5),type='b')");
			REXP rexpSetFolder = re.eval("setwd('C:/Users/CZC/Documents')");
			//REXP rexpSetFolder = re.eval("setwd('C:/Users/Lenovo/Documents')");
		   // REXP rexpFolder = re.eval("getwd()");
			//re.eval("load(file='C:/�����ļ�/Spot�۸�Ԥ��/TSMarkov.RData')", false);
			System.out.println(re.eval(".libPaths()"));
			
			System.out.println(re.eval("Sys.getlocale()"));
			//re.eval(".libPaths('C:/Users/CZC/Documents/R/win-library/3.3')");
			//System.out.println(re.eval(".libPaths()"));
			x=re.eval("library(rjson)");
			x=re.eval("library(TSA)");
			//x=re.eval("library(JavaGD)");
			
			x=re.eval("library(MSwM)");
			
			x=re.eval("library('fpc')");
			
			TimeSeriesAnalysis_MarkoveSwitch analiser=new TimeSeriesAnalysis_MarkoveSwitch();

			DirectoryDialog dialog=new DirectoryDialog(new Shell(), SWT.NONE);
			dialog.setMessage("Please Select the forder of prices");
			String dir=dialog.open();
			if(dir==null)
				return;
			dir=dir.replace("\\", "/");
			File files = new File(dir);
			FileFilter filefilter = new FileFilter() {

				public boolean accept(File file) {
					//if the file extension is .txt return true, else false
					if (file.getName().endsWith(".json")) {
						return true;
					}
					return false;
				}
			};
			File[] filelist = files.listFiles(filefilter);
			for (File cfile : filelist) {
				if(!cfile.getName().contains("PredictError"))
				{
					
					try {
						analiser.ParseOneFile(re,cfile.getAbsolutePath(),dir,dir+"/output");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
	}
	
	void ParseOneFile(Rengine re,String datafile,String datadir,String picdir)
	{
		File inputfile=new File(datafile);
		String outputfilename=picdir+"/"+inputfile.getName().replace(".json", "_PredictError");
		
		String strourputdir=picdir+"/"+inputfile.getName().replace(".json", "");
		File outputdir=new File(strourputdir);
		
		if(!outputdir.exists())
		{
			
				try {
					outputdir.mkdirs();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			
		}
		// TODO Auto-generated method stub
			        try {
			        	datafile=datafile.replace("\\", "/");
						re.eval("json_data<-fromJSON(paste(readLines('"+datafile+"'), collapse=''))",false);
						re.eval("source('"+datadir+"/ParseSpotScript.R')");
						
						REXP length_f=re.eval("length(fsamp)");
						re.eval("eps<-mean(f)/7");
						int totallength=length_f.asInt();
						
						int base=0;
						int learnstep=480;
						int prestep=168;
						
						for(;base<totallength-learnstep-prestep;base=base+10)
						{
							 try {
							String curoutput=strourputdir+"//Result"+base+".json";
							File outputfile=new File(curoutput);
							if(outputfile.exists())
							{
								System.out.println("jump this file��"+outputfile);
								continue;
							}
							
							re.eval("mod.mswm=NULL");
							re.eval("mod=NULL");
							re.eval("residual=NULL");
							re.eval("ar1ma10=NULL");
							re.eval("a=NULL");
							re.eval("predicted=NULL");
							re.eval("curprob=NULL");
							re.eval("ar1maorigi=NULL");
							re.eval("b=NULL");
							
							re.eval("base<-"+String.valueOf(base));
							re.eval("learnstep<-"+String.valueOf(learnstep));
							re.eval("prestep<-"+String.valueOf(prestep));
							re.eval("temp<-fsamp[base:(base+learnstep)]");
							re.eval("prepart<-fsamp[(base+learnstep+1):(base+learnstep+prestep)]");
							
							re.eval("eps<-mean(f)/7");
							re.eval("rw<-data.frame(temp)");
							re.eval("model2 <- dbscan(rw,eps,MinPts=10,showplot=F)");
							double[] clusters=re.eval("model2$cluster").asDoubleArray();
							re.eval("Markovtemp<-temp");
							for(int i=1;i<=clusters.length;i++)
							{
								if(clusters[i-1]==0)//abnormal points
								{
									boolean found=false;
									for(int j=i+1;j<=clusters.length;j++)//find normal data
									{
										if(clusters[j-1]>0)
										{
											re.eval("Markovtemp["+String.valueOf(i)+"]<-temp["+String.valueOf(j)+"]");
											found=true;
											break;
										}
									}
									if(!found)
									{
										for(int j=i-1;j>=1;j--)//find normal data
										{
											if(clusters[j-1]>0)
											{
												re.eval("Markovtemp["+String.valueOf(i)+"]<-temp["+String.valueOf(j)+"]");
												found=true;
												break;
											}
										}
									}
									if(!found)
									{
										System.out.println("ERROR0011");
										return;
									}
								}
							}
						
							
							re.eval("num<-factor(model2$cluster)");
							REXP levels=re.eval("levels(num)");
							String[] strlevels=levels.asStringArray();
							int k=-1;
							if(strlevels.length>0)
							{
								if(strlevels[0].equalsIgnoreCase("0"))
								{
									k=strlevels.length-1;
								}
								else
								{
									k=strlevels.length;
								}
							}
							else
							{
								System.out.println("cannot establish model,base="+base);
								continue;
							}
							
						
							re.eval("mod=lm(Markovtemp~1)");
							k++;
							re.eval("k<-"+String.valueOf(k));
							//re.eval("mod.mswm=msmFit(mod,k,p=24,sw=c(T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T),control=list(parallel=F,maxiter=1000,maxiterOuter=20,maxiterInner=20))");
							re.eval("mod.mswm=msmFit(mod,k,p=24,sw=c(T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T),control=list(parallel=F))");
							REXP mswm=re.eval("mod.mswm");
							
							if(mswm.rtype!=REXP.XT_NULL)
							{
								System.out.println("Model established");
							
							}
							else
							{
								System.out.println("Test state failed number="+k);
								continue;
							}
								
							re.eval("summary(mod.mswm)");
							
							//re.eval("residual=msmResid(mod.mswm)");
							REXP filtmatrix=re.eval("pp=mod.mswm@Fit@filtProb");
							/**get the state information
							*/
							double[][] fmatrix=filtmatrix.asDoubleMatrix();
							ArrayList<ArrayList<Integer>> intervals=new ArrayList<ArrayList<Integer>>();
							ArrayList<ArrayList<Integer>> predictedintervals=new ArrayList<ArrayList<Integer>>();
							int height=re.eval("dim(pp)[1]").asInt();
							int laststate=-1;
							int lastkeeptime=0;
							for(int statei=0;statei<k;statei++)
							{
								ArrayList<Integer> intervali=new ArrayList<Integer>();
								ArrayList<Integer> preintervali=new ArrayList<Integer>();
								int keeptime=0;
								int errotime=0;
								for(int i=0;i<height;i++)
								{
									int maxstate=-1;
									double maxprob=-1;
									for(int j=0;j<k;j++)
									{
										if(fmatrix[i][j]>maxprob)
										{
											maxstate=j;
											maxprob=fmatrix[i][j];
										}
									}
									if(maxstate==statei)
									{
										keeptime++;
										errotime=0;
									}
									else 
									{
											errotime++;
											if(errotime>=2)
											{
												if(keeptime>=2)
												{
													intervali.add(keeptime);
												}
												keeptime=0;
											}
										
									}
									
								}
								if(keeptime>=2)
								{
									laststate=statei;
									lastkeeptime=keeptime;
								}
								intervals.add(intervali);
								String vec="c(";
								for(int w=0;w<intervali.size();w++)
								{
									if(w==intervali.size()-1)
										vec+=intervali.get(w)+")";
									else
										vec+=intervali.get(w)+",";
								}
								
								re.eval("intervalvec="+vec);
								re.eval("intervalmodel=arima(intervalvec,order=c(5,0,5))");
								re.eval("intervalplot=TSA::plot.Arima(intervalmodel,n.ahead=30,type='b',xlab='time',ylab='price',Plot=FALSE)");
								
								double[] dprearray=re.eval("intervalplot$pred").asDoubleArray();
								for(int l=0;l<dprearray.length;l++)
									preintervali.add((int)Math.round(dprearray[l]));
								predictedintervals.add(preintervali);
							}
							
							if(laststate==-1)
							{
								System.out.println("Did not get the last state num");
								continue;
							}
							int curstate=laststate;
							int Rcurstate=curstate+1;
							int keeptime=lastkeeptime;
							ArrayList<Integer> lastpreintervali=predictedintervals.get(curstate);
							int preinterval=0;
							if(lastpreintervali.size()>0)
							{
								preinterval=lastpreintervali.get(0);
								lastpreintervali.remove(0);
							}
							else
							{
								System.out.println("Predicted intervals needed");
								continue;
							}
							re.eval("marpred<-c()");
							for(int p=1;p<=prestep;p++)
							{
								
								if(keeptime<=preinterval)
								{
									keeptime++;
									re.eval("coef=as.vector(mod.mswm@Coef["+Rcurstate+",])");
									re.eval("revcoef=rev(coef)");
									re.eval("current=c(temp,marpred)");
									re.eval("learnpart=current[(length(current)-23):length(current)]");
									re.eval("learnpart=c(learnpart,1)");
									re.eval("re=learnpart*revcoef");
									re.eval("fretp=sum(re)");
									re.eval("marpred=c(marpred,fretp)");
								}
								else//change state
								{
									double[] transmitarray=re.eval("mod.mswm@transMat["+Rcurstate+",]").asDoubleArray();
									int maxstate=-1;
									double maxprob=-1;
									for(int w=0;w<transmitarray.length;w++)
									{
										if(transmitarray[w]>maxprob&&w!=curstate)
										{
											maxstate=w;
											maxprob=transmitarray[w];
										}
									}
									System.out.println("Change to state:"+maxstate+" at step:"+p);
									curstate=maxstate;
									Rcurstate=curstate+1;
									ArrayList<Integer> curpreintervali=predictedintervals.get(curstate);
									if(curpreintervali.size()>0)
									{
										preinterval=curpreintervali.get(0);
										curpreintervali.remove(0);
										keeptime=0;
									}
									else
									{
										System.out.println("Predicted intervals needed");
										return;
									}
									keeptime++;
									re.eval("coef=as.vector(mod.mswm@Coef["+Rcurstate+",])");
									re.eval("revcoef=rev(coef)");
									re.eval("current=c(temp,marpred)");
									re.eval("learnpart=current[(length(current)-23):length(current)]");
									re.eval("learnpart=c(learnpart,1)");
									re.eval("re=learnpart*revcoef");
									re.eval("fretp=sum(re)");
									re.eval("marpred=c(marpred,fretp)");
								}
								
								
							}
							
							
							re.eval("jpeg('"+strourputdir+"//Markove_"+String.valueOf(base)+".jpg')");
							re.eval("plot(c(temp,prepart),type='b')");
							re.eval("par(new=TRUE)");
							re.eval("points((learnstep+2):(learnstep+1+prestep),marpred,col='red',type='b')");
							re.eval("dev.off()");
							
							//use the last state to predict
							re.eval("sgmarpred<-c()");
							int Rlaststate=laststate+1;
							re.eval("coef=as.vector(mod.mswm@Coef[which.max(pp[dim(pp)[1],]),])");
							re.eval("revcoef=rev(coef)");
							for(int p=1;p<=prestep;p++)
							{
									re.eval("current=c(temp,sgmarpred)");
									re.eval("learnpart=current[(length(current)-23):length(current)]");
									re.eval("learnpart=c(learnpart,1)");
									re.eval("re=learnpart*revcoef");
									re.eval("fretp=sum(re)");
									re.eval("sgmarpred=c(sgmarpred,fretp)");
							}
							re.eval("jpeg('"+strourputdir+"//MarkoveSingle_"+String.valueOf(base)+".jpg')");
							re.eval("plot(c(temp,prepart),type='b')");
							re.eval("par(new=TRUE)");
							re.eval("points((learnstep+2):(learnstep+1+prestep),sgmarpred,col='red',type='b')");
							re.eval("dev.off()");
							
							System.out.println(re.eval("prepart"));
							System.out.println(re.eval("marpred"));
							System.out.println(re.eval("sgmarpred"));
							
							try
							{
							re.eval("ar1maorigi=arima(temp,order=c(24,1,0))");
							re.eval("jpeg('"+strourputdir+"//ARIMA_"+String.valueOf(base)+".jpg')");
							re.eval("b=TSA::plot.Arima(ar1maorigi,n.ahead=prestep,type='b',xlab='time',ylab='price',Plot=FALSE)");
							re.eval("plot(c(temp,prepart),type='b')");
							
							re.eval("points((learnstep+2):(learnstep+1+prestep),b$pred,col='red',type='b')");
							re.eval("dev.off()");
							
							
							//re.eval("armamodel=arima(temp,order=c(24,0,0))");
							re.eval("armamodel=arima(temp,order=c(23,0,0),seasonal=list(order=c(1,0,0),period=168),method='CSS')");
							
							re.eval("jpeg('"+strourputdir+"//ARMA_"+String.valueOf(base)+".jpg')");
							re.eval("armaplot=TSA::plot.Arima(armamodel,n.ahead=prestep,type='b',xlab='time',ylab='price',Plot=FALSE)");
							re.eval("plot(c(temp,prepart),type='b')");
							
							re.eval("points((learnstep+2):(learnstep+1+prestep),armaplot$pred,col='red',type='b')");
							re.eval("dev.off()");
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
							REXP actualprepart=re.eval("prepart");
							double[] actuaarray= actualprepart.asDoubleArray();
							
							
							double[] arimaprepartarray=null;
							REXP arimaprepart=re.eval("b$pred");
							if(arimaprepart!=null)
								arimaprepartarray= arimaprepart.asDoubleArray();
							
							
							REXP markoveprepart=re.eval("marpred");
							double[] markovprepartarray= markoveprepart.asDoubleArray();
							
							REXP Sgmarkoveprepart=re.eval("sgmarpred");
							double[] Sgmarkovprepartarray= Sgmarkoveprepart.asDoubleArray();
							
							REXP armaprepart=re.eval("armaplot$pred");
							double[] armaprepartarray=null;
							if(armaprepart!=null)
							{
								armaprepartarray= armaprepart.asDoubleArray();
							}

							if(actuaarray.length==markovprepartarray.length)
							{
								re.eval("library(forecast)");
								ArrayList<Double> markove_MAPElist=new ArrayList<Double>();
								ArrayList<Double> sgmarkove_MAPElist=new ArrayList<Double>();
								ArrayList<Double> ARIMA_MAPElist=new ArrayList<Double>();
								ArrayList<Double> ARMA_MAPElist=new ArrayList<Double>();
								for(int ps=1;ps<=actuaarray.length;ps++)
								{
									double markove_averageerror=re.eval("accuracy(marpred[1:"+ps+"],prepart[1:"+ps+"])[1,5]").asDouble();
									double sgmarkove_averageerror=re.eval("accuracy(sgmarpred[1:"+ps+"],prepart[1:"+ps+"])[1,5]").asDouble();
									
									System.out.println("///////////////////////////////////////////");
									System.out.println("step:"+ps);
									System.out.println("markov_MAPE="+markove_averageerror);
									System.out.println("markovSG_MAPE="+sgmarkove_averageerror);
									markove_MAPElist.add(markove_averageerror);
									sgmarkove_MAPElist.add(sgmarkove_averageerror);
									if(arimaprepartarray!=null&&arimaprepartarray.length==actuaarray.length)
									{
										double arima_averageerror=re.eval("accuracy(b$pred[1:"+ps+"],prepart[1:"+ps+"])[1,5]").asDouble();
										System.out.println("arima_MAPE="+arima_averageerror);
										ARIMA_MAPElist.add(arima_averageerror);
									}
									else
									{
										ARIMA_MAPElist.add(-1d);
									}
									
									if(armaprepartarray!=null&&armaprepartarray.length==actuaarray.length)
									{
										double arma_averageerror=re.eval("accuracy(armaplot$pred[1:"+ps+"],prepart[1:"+ps+"])[1,5]").asDouble();
										System.out.println("arma_MAPE="+arma_averageerror);
										ARMA_MAPElist.add(arma_averageerror);
									}
									else
									{
										ARMA_MAPElist.add(-1d);
									}
									
								}
								
								SavetoJson(markove_MAPElist, ARIMA_MAPElist,ARMA_MAPElist,sgmarkove_MAPElist, curoutput);
								//arima_errorlist.add(arima_averageerror);
								//markov_errorlist.add(markove_averageerror);
								//arma_errorlist.add(arma_averageerror);
							}
							else
							{
								System.out.println("The length of predicted results of algorithms are different");
								continue;
							}
							
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
						      
						}
						
					
						
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			      
	}
	boolean SavetoJson(ArrayList<Double> errorlist1,ArrayList<Double> errorlist2,ArrayList<Double> errorlist3,ArrayList<Double> sgmarkove_MAPElist,String outputfilename)
	{
		File outputfile=new File(outputfilename);
		if(!outputfile.exists())
		{
			try {
				outputfile.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			
			try {
				outputfile.delete();
				outputfile.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			JsonGenerator generator=Json.createGenerator(new FileOutputStream(outputfile));
			generator.writeStartObject(); 
			
			generator.writeStartArray("MAPE");
			
			for(int i=0;i<errorlist1.size();i++)
			{
				generator.writeStartObject(); 
				generator.write("Markov"+i, String.valueOf(errorlist1.get(i)));
				generator.write("MarkovSG"+i,String.valueOf(sgmarkove_MAPElist.get(i)));
				generator.write("ARIMA"+i,String.valueOf(errorlist2.get(i)));
				generator.write("ARMA"+i,String.valueOf(errorlist3.get(i)));
				generator.writeEnd();
			}
			
			
			generator.writeEnd();
			generator.writeEnd();
			generator.close();
			return true;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}

}
