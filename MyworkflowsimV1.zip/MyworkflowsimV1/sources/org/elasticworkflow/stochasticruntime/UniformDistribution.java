package org.elasticworkflow.stochasticruntime;
import java.util.Random;
import org.elasticworkflow.*;
import org.elasticworkflow.SystemParameters;
import org.elasticworkflow.SystemParameters.DistributionType;
public class UniformDistribution extends RuntimeDistribution {

	
	private double seedtime=0;//����ʱ��
	private double maxdev=0;
	public UniformDistribution(double maxdev) {
		// TODO Auto-generated constructor stub
		this.type=DistributionType.Uniform;
		this.maxdev=maxdev;
	}

	@Override
	public double getRunTime() {
		// TODO Auto-generated method stub
		if(this.fixedtime!=-1)
			return this.fixedtime;
		Random rm=new Random();
		double rd=rm.nextDouble();
		double dev=(rd-0.5)*2*maxdev;
		return (1+dev)*seedtime;
	}

	@Override
	public void setSeedTime(double seedtime) {
		// TODO Auto-generated method stub
		this.seedtime=seedtime;
	}

	public double getMaxdev() {
		return maxdev;
	}

	@Override
	public double getAverageTime() {
		// TODO Auto-generated method stub
		return seedtime;
	}

	@Override
	public double getStandardDeviation() {
		// TODO Auto-generated method stub
		return (maxdev*seedtime)/Math.pow(3, 0.5);
	}

	public void setMaxdev(double maxdev) {
		this.maxdev = maxdev;
	}
   
}
