package org.elasticworkflow.stochasticruntime;

import java.util.Random;

import org.elasticworkflow.SystemParameters.DistributionType;

public class GaussianDistribution extends RuntimeDistribution {

	private double maxdev;
	private double mu;
	private double tao;
	public GaussianDistribution(double tao,double maxdev) {
		// TODO Auto-generated constructor stub
		this.tao=tao;
		this.maxdev=maxdev;
		this.type=DistributionType.Gaussian;
	}

	@Override
	public double getRunTime() {
		// TODO Auto-generated method stub
		if(this.fixedtime!=-1)
			return this.fixedtime;
		Random rm=new Random();
		double ga=rm.nextGaussian();
		if(ga>3)
		{
			ga=3;
		}
		else if(ga<-3)
		{
			ga=-3;
		}
		return (1+(ga/3)*maxdev)*mu;
	}

	@Override
	public void setSeedTime(double seedtime) {
		// TODO Auto-generated method stub
		mu=seedtime;
	}
    
	@Override
	public double getAverageTime() {
		// TODO Auto-generated method stub
		return mu;
	}

	@Override
	public double getStandardDeviation() {
		// TODO Auto-generated method stub
		return maxdev*mu/3;
	}

}
