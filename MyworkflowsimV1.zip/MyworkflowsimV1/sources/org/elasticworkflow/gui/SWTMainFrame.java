package org.elasticworkflow.gui;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.graphics.*;
import swing2swt.layout.BorderLayout;
import org.eclipse.swt.widgets.ToolBar;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.core.CloudSim;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.ToolItem;
import org.elasticworkflow.SystemParameters;
import org.elasticworkflow.SystemSetting;
import org.elasticworkflow.SystemParameters.DistributionType;
import org.elasticworkflow.example.*;
import org.elasticworkflow.staticalgorithm.DisplayState;
import org.elasticworkflow.staticalgorithm.RequestQueue;
import org.elasticworkflow.staticalgorithm.ServerInstancePool;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.elasticworkflow.intervalpricing.IntervalPricingVM;
import java.util.ArrayList;
import java.util.HashMap;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.wb.swt.SWTResourceManager;
import java.io.File;
import java.io.FileFilter;
public class SWTMainFrame {

	protected Shell shlElasticworkflowsim;
	protected TabFolder tabFolder;
	protected Display display;
	protected Composite composite;
	private int vargap=10;
	ToolItem tltmNewItem_1;
	ScrolledComposite scrolledComposite;
	public boolean sepbystep=false;
	/**
	 * ��ִ̨���߳�
	 */
	Thread simtd=null;
	/**
	 * ��ʾ��������ʱ��
	 */
	private double displaystarttime=0;
	
	/**
	 * ����߾�
	 */
	private int leftmargin=100;
	/**
	 * ������ؼ����б�
	 */
	private ArrayList<VMcomposit> complist=new ArrayList<VMcomposit>();
	
	private HashMap<IntervalPricingVM,VMcomposit> vmcopmap=new HashMap<IntervalPricingVM,VMcomposit>();
	private ToolItem tltmNewItem_2;
	private ToolItem tltmUncentain;
	/**
	 * Launch the application.
	 * @param args
	 * @wbp.parser.entryPoint
	 * 
	 * 
	 */
	public static void main(String[] args) {
		try {
			SWTMainFrame window = new SWTMainFrame();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 *
	 *
	 */
	public void open() {
		display= Display.getDefault();
		//if(shell==null)
			createContents();
		shlElasticworkflowsim.open();
		shlElasticworkflowsim.layout();
		while (!shlElasticworkflowsim.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * 
	 */
	public void createContents() {
		
		shlElasticworkflowsim = new Shell();
		shlElasticworkflowsim.setImage(SWTResourceManager.getImage("D:\\\u9879\u76EE\u7533\u8BF7\\2015\u9879\u76EE\u7533\u8BF7\\2015\u7701\u57FA\u91D1\u7533\u8BF7\\\u56FE\u7247\\\u7CFB\u7EDF\u56FE\u6807.jpg"));
		shlElasticworkflowsim.setSize(590, 377);
		shlElasticworkflowsim.setText("ElasticWorkflowSim");
		shlElasticworkflowsim.setLayout(new BorderLayout(0, 0));
		
		ToolBar toolBar = new ToolBar(shlElasticworkflowsim, SWT.FLAT | SWT.RIGHT);
		toolBar.setLayoutData(BorderLayout.NORTH);
		
		ToolItem tltmNewItem = new ToolItem(toolBar, SWT.NONE);
		tltmNewItem.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Runstatic();
			}
		});
		tltmNewItem.setText("StaticAlgorithm");
		
		tltmNewItem_1 = new ToolItem(toolBar, SWT.NONE);
		tltmNewItem_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				GoClick(e);
			}
		});
		tltmNewItem_1.setText("Next");
		
		tltmNewItem_2 = new ToolItem(toolBar, SWT.CHECK);
		tltmNewItem_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				sepbystep=tltmNewItem_2.getSelection();
			}
		});
		tltmNewItem_2.setText("Step");
		
		tltmUncentain = new ToolItem(toolBar, SWT.NONE);
		tltmUncentain.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				RunParallel();
			}
		});
		tltmUncentain.setText("UncentainBatch");
		
		tabFolder = new TabFolder(shlElasticworkflowsim, SWT.NONE);
		tabFolder.setLayoutData(BorderLayout.CENTER);
		
		TabItem tbtmConsole = new TabItem(tabFolder, SWT.NONE);
		tbtmConsole.setText("Console");
		
		scrolledComposite = new ScrolledComposite(tabFolder, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		tbtmConsole.setControl(scrolledComposite);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		composite = new Composite(scrolledComposite, SWT.NONE);
		composite.addPaintListener(new PaintListener() {
			public void paintControl(PaintEvent e) {
				M_paintControl(e);
			}
		});
		scrolledComposite.setContent(composite);
		scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));

	}
	public void M_paintControl(PaintEvent e) {
		Color linecolor = new Color(display,255, 255, 255);
		e.gc.setBackground(linecolor);
		e.gc.setLineWidth(2);
	
		int posx = (int) Math.round((CloudSim.clock() - displaystarttime)
				* SystemSetting.getPixrate());
		e.gc.drawLine(leftmargin, 0, leftmargin,composite.getBounds().height);
		e.gc.drawLine(leftmargin+posx, 0, leftmargin+posx,composite.getBounds().height);
		
	}
	 public void DisplayNewResult(String itemname,ServerInstancePool sp,RequestQueue rqueue)
		{
			try {
				 Display display=Display.getDefault();
				 display.syncExec(new Runnable() {
					public void run() {
				TabItem tbtmNewItem = new TabItem(tabFolder, SWT.NONE);
				tbtmNewItem.setText(itemname);
				Composite composite_5 = new Composite(tabFolder, SWT.NONE);
				tbtmNewItem.setControl(composite_5);
				composite_5.setLayout(new FillLayout(SWT.HORIZONTAL));
				DisplayState displayState_1 = new DisplayState(composite_5, SWT.NONE, (ServerInstancePool) sp);
				displayState_1.setSpool(sp);
				displayState_1.ClockJump(0, 0, (long) sp.getMaxTime() + 3600, rqueue);
					}
				 });
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	 public void RunParallel()
	 {
		 try {
			 DirectoryDialog dialog=new DirectoryDialog(shlElasticworkflowsim, SWT.NONE);
			 dialog.setMessage("ѡ�����������ļ���");
			 String dir=dialog.open();
			if(dir==null)
				return;
			
			 dialog.setMessage("ѡ������ļ���");
			 String outdir=dialog.open();
			if(outdir==null)
				return;
			MessageBox box=new MessageBox(shlElasticworkflowsim,SWT.NO|SWT.YES);
			box.setMessage("ѡ����ȷֲ�?");
			int re=box.open();
			
			File files = new File(dir);
			FileFilter filefilter = new FileFilter() {

				public boolean accept(File file) {
					//if the file extension is .txt return true, else false
					if (file.getName().endsWith(".dax")) {
						return true;
					}
					return false;
				}
			};
			File[] filelist = files.listFiles(filefilter);
			double[] deadlinefactorlist = new double[] { 1.5, 3, 6, 12, 24 };
			double[] maxdevlist = new double[] { 0,0.1, 0.2, 0.3, 0.4, 0.5 };
			double[] pricingintervallist = new double[] { 300, 600, 900, 1200, 1500, 1800, 2100, 2400, 2700, 3000, 3300,
					3600 };
			for (File cfile : filelist) {

				for (double deadlinefactor : deadlinefactorlist) {
					for (double maxdev : maxdevlist) {
						for (double pricinginterval : pricingintervallist) {
							// String daxPath = "D:\\�о�\\���򿪷�\\WorkflowSim-1.0\\config\\dax\\Sipht_1000.xml";

							if (!cfile.exists()) {
								Log.printLine(
										"Warning: Please replace daxPath with the physical path in your working environment!");
								continue;
							}
							SystemParameters.deadlinefactor = deadlinefactor;
							SystemParameters.maxdev = maxdev;
							SystemParameters.pricinginterval = pricinginterval;
							SystemParameters.seltype = DistributionType.Uniform;
							if(re==SWT.NO)
							{
								SystemParameters.seltype = DistributionType.Gaussian;
							}
							String distype = "";
							if (SystemParameters.seltype == DistributionType.Gaussian)
								distype = "Gaussian";
							if (SystemParameters.seltype == DistributionType.Uniform)
								distype = "Uniform";
							SystemParameters.outputfile = outdir +"\\"+ cfile.getName() + "D_"
									+ SystemParameters.deadlinefactor + "V_" + SystemParameters.maxdev + "I_"
									+ SystemParameters.pricinginterval + "B_" + distype + ".xml";
							File file = new File(SystemParameters.outputfile);
							if (file.exists())
							{
								Log.printLine(SystemParameters.outputfile+"�Ѿ������������");
								continue;
							}
							SystemParameters.instancename = cfile.getName();
							SystemSetting.vmsetuptime=50; //s
							SystemSetting.storagetransferrate=15;//M/s
							WorkflowSimIntervalBasicExampleStatic st = new WorkflowSimIntervalBasicExampleStatic();
							st.RunBatch(cfile.getPath());
						}
					}
				}
			} 
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.exit(0);
		}
		 
	 }
	
	 public void Runstatic()
	 {
		  FileDialog dia=new FileDialog(new Shell(),SWT.NONE);
          String daxPath = dia.open();
          
          ParameterSetting pasetdialog=new ParameterSetting(new Shell(),SWT.TITLE);
          
          if(pasetdialog.open()!=SWT.OK)
         	 return;
		 SystemSetting.setMainframe(this);
		
		 simtd = new Thread(new Runnable() { 
			    public void run() { 
			        //Do business action 
			        WorkflowSimIntervalBasicExampleStatic st=new WorkflowSimIntervalBasicExampleStatic();
			        SystemParameters.deadlinefactor=pasetdialog.deadlinefactor;
		            SystemParameters.maxdev=pasetdialog.maxdev;
		            SystemParameters.pricinginterval=pasetdialog.pricinginterval;
		            SystemParameters.seltype=pasetdialog.distype;
		            SystemSetting.storagetransferrate=pasetdialog.storagetransferrate;
		            SystemSetting.vmsetuptime=pasetdialog.vmsetuptime;
			        st.Run(daxPath);
			    }
		 });
			            
		 simtd.start();
		
	 }
	
	
	 public void AddanVM(IntervalPricingVM vm)
	 {
		
		 try {
			 Display display=Display.getDefault();
			 display.syncExec(new Runnable() {
				public void run() {
					VMcomposit vmcop = new VMcomposit(composite, SWT.NONE, vm);
					int posx = (int) Math.round((vm.getPricemodel().getPricingStarttime() - displaystarttime)
							* SystemSetting.getPixrate());

					int posy = 10;
					if (complist.size() > 0) {
						VMcomposit lastcomp = complist.get(complist.size() - 1);
						posy = lastcomp.getBounds().y + lastcomp.getBounds().height + vargap;
						/*try {
							if(!vm.getHost().getDatacenter().getName().equalsIgnoreCase(lastcomp.getVm().getHost().getDatacenter().getName()))
							{
								Label lblNewLabel = new Label(composite,SWT.NONE );
								lblNewLabel.setLocation(leftmargin, posy);
								lblNewLabel.setText("�������ģ�"+vm.getHost().getDatacenter().getName());
								posy = lastcomp.getBounds().y + lastcomp.getBounds().height + vargap+lblNewLabel.getBounds().height+50;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
					}
					
					
					vmcop.setLocation(leftmargin+posx, posy);
					vmcop.UpdateTasks();
					
					Label lblNewLabel = new Label(composite,SWT.NONE );
					lblNewLabel.setBounds(leftmargin+posx-80, posy, 70, vmcop.getBounds().height);
					lblNewLabel.setText(vm.getConfig().getVmtype()+" "+vm.getUid());
					
					vmcopmap.put(vm, vmcop);
					complist.add(vmcop);
					composite.setSize(leftmargin+composite.getBounds().width+2, posy+vmcop.getBounds().height + 10);
					//composite.redraw();
					scrolledComposite.setMinSize(leftmargin+composite.getBounds().width+5, posy+vmcop.getBounds().height + 15);
				}
			});
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
			  
		
		 
		
	 }
	 public void UpdateVMs()
	 {
		 try {
		 Display.getDefault().syncExec(new Runnable() { 
			   public void run()
	            { 
					 for(VMcomposit comp:complist)
					 {
						 comp.UpdateTasks();
					 }
				//	 Log.printLine("composite.getBounds().width:"+composite.getBounds().width);
					// scrolledComposite.setMinSize(composite.getBounds().width+2, composite.getBounds().height+2);
					 Point bestsize=composite.computeSize(SWT.DEFAULT, SWT.DEFAULT);
					 scrolledComposite.setMinSize(bestsize.x+10,bestsize.y+10);
	            }
	        });
		 if(sepbystep)
		 {
			 synchronized(this){
					// tltmNewItem_1.setEnabled(true);
					 this.wait();
				 }
		 }
		 else
		 {
			 synchronized(this){
					// tltmNewItem_1.setEnabled(true);
					// this.wait(1);
				 }
		 }
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	 }
	 public void UpdateVMs(IntervalPricingVM vm)
	 {
		 try {
			 Display display=Display.getDefault();
			 display.syncExec(new Runnable() { 
			   public void run()
	            { 
					 VMcomposit comp=vmcopmap.get(vm);
					 if(comp!=null)
					 {
						 comp.UpdateTasks();
						// Log.printLine("composite.getBounds().width:"+composite.getBounds().width);
						// scrolledComposite.setMinSize(composite.getBounds().width+10, composite.getBounds().height+2);
						 Point bestsize=composite.computeSize(SWT.DEFAULT, SWT.DEFAULT);
						 scrolledComposite.setMinSize(bestsize.x+10,bestsize.y+10);
						// scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));
					 }
	            }
	        });
		
		
			 if(sepbystep)
			 {
				 synchronized(this){
						// tltmNewItem_1.setEnabled(true);
						 this.wait();
					 }
			 }
			 else
			 {
				 synchronized(this){
						// tltmNewItem_1.setEnabled(true);
						// this.wait(1);
					 }
			 }
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	 }
	public void GoClick(SelectionEvent e) {
		 try {
			 synchronized(this){
				this.notify();
			//	tltmNewItem_1.setEnabled(false);
			 }
			} catch (Exception ex) {
				// TODO: handle exception
				ex.printStackTrace();
			}
	}
}
