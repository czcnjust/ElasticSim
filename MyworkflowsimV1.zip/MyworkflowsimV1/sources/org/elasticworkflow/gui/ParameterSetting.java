package org.elasticworkflow.gui;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;
import org.elasticworkflow.SystemParameters;
import org.elasticworkflow.SystemSetting;
import org.elasticworkflow.SystemParameters.DistributionType;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class ParameterSetting extends Dialog {

	protected int result;
	protected Shell shlParameterSetting;
	private Text text;
	private Text text_1;
	private Text text_2;

	public double  deadlinefactor=15;
    public double  maxdev=0;
    public double  pricinginterval=300;
    public DistributionType distype;
    public double vmsetuptime=50;
    public double  storagetransferrate=15;
    private Text text_3;
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public ParameterSetting(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public int open() {
		createContents();
		shlParameterSetting.open();
		shlParameterSetting.layout();
		Display display = getParent().getDisplay();
		while (!shlParameterSetting.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shlParameterSetting = new Shell(getParent(), getStyle());
		shlParameterSetting.setSize(450, 360);
		shlParameterSetting.setText("Parameter Setting");
		shlParameterSetting.setLayout(null);
		
		Label lblNewLabel = new Label(shlParameterSetting, SWT.NONE);
		lblNewLabel.setBounds(24, 30, 96, 17);
		lblNewLabel.setText("DeadlineFactor");
		
		Label lblMaxdeviationrate = new Label(shlParameterSetting, SWT.NONE);
		lblMaxdeviationrate.setText("MaxDeviationRate");
		lblMaxdeviationrate.setBounds(24, 71, 113, 17);
		
		Label lblPricingInterval = new Label(shlParameterSetting, SWT.NONE);
		lblPricingInterval.setText("Pricing Interval");
		lblPricingInterval.setBounds(24, 126, 113, 17);
		
		Spinner spinner_2 = new Spinner(shlParameterSetting, SWT.BORDER);
		spinner_2.setMaximum(10000);
		spinner_2.setSelection(1200);
		spinner_2.setBounds(137, 120, 73, 23);
		
		text = new Text(shlParameterSetting, SWT.BORDER);
		text.setText("0.3");
		text.setBounds(137, 71, 73, 23);
		
		text_1 = new Text(shlParameterSetting, SWT.BORDER);
		text_1.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				//deadlinefactor=
			}
		});
		text_1.setText("10");
		text_1.setBounds(137, 27, 73, 23);
		
		Label lblRuntimeDistributionType = new Label(shlParameterSetting, SWT.NONE);
		lblRuntimeDistributionType.setText("Runtime Distribution Type");
		lblRuntimeDistributionType.setBounds(24, 175, 156, 17);
		
		Composite composite = new Composite(shlParameterSetting, SWT.NONE);
		composite.setBounds(198, 157, 214, 64);
		
		Button btnRadioButton_1 = new Button(composite, SWT.RADIO);
		btnRadioButton_1.setBounds(113, 21, 97, 17);
		btnRadioButton_1.setText("Normal");
		
		Button btnRadioButton = new Button(composite, SWT.RADIO);
		btnRadioButton.setBounds(10, 21, 97, 17);
		btnRadioButton.setSelection(true);
		btnRadioButton.setText("Uniform");
		
		Label lblSystemBandwidth = new Label(shlParameterSetting, SWT.NONE);
		lblSystemBandwidth.setText("System BandWidth");
		lblSystemBandwidth.setBounds(24, 234, 109, 17);
		
		text_2 = new Text(shlParameterSetting, SWT.BORDER);
		text_2.setText("15");
		text_2.setBounds(137, 231, 73, 23);
		
		Label lblMbs = new Label(shlParameterSetting, SWT.NONE);
		lblMbs.setText("Mb/s");
		lblMbs.setBounds(221, 234, 156, 17);
		
		Button btnNewButton = new Button(shlParameterSetting, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				deadlinefactor=Double.valueOf(text_1.getText());
			    maxdev=Double.valueOf(text.getText());
			    pricinginterval=Double.valueOf(spinner_2.getText());
			    if(btnRadioButton_1.getSelection())
			    	distype=DistributionType.Gaussian;
			    else
			    	distype=DistributionType.Uniform;
			    
			    storagetransferrate=Double.valueOf(text_2.getText());
			    vmsetuptime=Double.valueOf(text_3.getText());
			   
			
			    result=SWT.OK;
			  
			    shlParameterSetting.close();
			}
		});
		btnNewButton.setSelection(true);
		btnNewButton.setBounds(261, 295, 80, 27);
		btnNewButton.setText("OK");
		
		Button btnNewButton_1 = new Button(shlParameterSetting, SWT.NONE);
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				  result=SWT.CANCEL;
				  shlParameterSetting.close();
			}
		});
		btnNewButton_1.setBounds(354, 295, 80, 27);
		btnNewButton_1.setText("Cancel");
		
		Label lblVmSetupTime = new Label(shlParameterSetting, SWT.NONE);
		lblVmSetupTime.setText("VM Setup Time");
		lblVmSetupTime.setBounds(24, 273, 113, 17);
		
		text_3 = new Text(shlParameterSetting, SWT.BORDER);
		text_3.setText("50");
		text_3.setBounds(137, 270, 73, 23);
		
		Label lblSeconds = new Label(shlParameterSetting, SWT.NONE);
		lblSeconds.setText("Seconds");
		lblSeconds.setBounds(221, 272, 156, 17);

	}
}
