package org.elasticworkflow.intervalpricing;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletScheduler;
import org.cloudbus.cloudsim.Consts;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicy;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEvent;
import org.elasticworkflow.FileItem;
import org.elasticworkflow.SystemSetting;
import org.elasticworkflow.Task;
import org.cloudbus.cloudsim.Datacenter;
import org.elasticworkflow.SystemParameters;
import org.elasticworkflow.SystemParameters.FileType;;
/**
 * IntervalPricingDataCenter extends WorkflowDatacenter( extends Datacenter)
 * supporting interval based pricing model
 * @author Zhicheng Cai
 * @since WorkflowSimPricing Toolkit 1.0
 * @date Nov 11, 2015
 */
public class IntervalPricingDataCenter extends Datacenter {
	
	
	/**
	 * store the rental cost of each borker
	 */
	private Map<Integer, Double> RentalCostMap;
	
	public IntervalPricingDataCenter(String name, IntervalDataCenterCharacteristics characteristics,
			VmAllocationPolicy vmAllocationPolicy, List<Storage> storageList, double schedulingInterval)
					throws Exception {
		super(name, characteristics, vmAllocationPolicy, storageList, schedulingInterval);
		// TODO Auto-generated constructor stub
		RentalCostMap=new HashMap<Integer, Double>();
		characteristics.setStorageList(storageList);
		characteristics.setdatacenterid(this.getId());
	}

	/**
     * Add the pricing object when vreating vm
     * @author Zhicheng Cai
     * @since WorkflowSimPricing 1.0
     */
    @Override
	protected void processVmCreate(SimEvent ev, boolean ack) {
		// TODO Auto-generated method stub
    	
    	IntervalPricingVM vm = (IntervalPricingVM) ev.getData();
		boolean result = getVmAllocationPolicy().allocateHostForVm(vm);

		if (ack) {
			int[] data = new int[3];
			data[0] = getId();
			data[1] = vm.getId();

			if (result) {
				data[2] = CloudSimTags.TRUE;
			} else {
				data[2] = CloudSimTags.FALSE;
			}
			//CloudSim.getMinTimeBetweenEvents()+
			//Send message after Setup time 
			send(vm.getUserId(), vm.getConfig().getSetuptime(), CloudSimTags.VM_CREATE_ACK, data);
		}

		if (result) {
			getVmList().add(vm);

			if (vm.isBeingInstantiated()) {
				vm.setBeingInstantiated(false);
			}

			vm.updateVmProcessing(CloudSim.clock()+vm.getConfig().getSetuptime(), getVmAllocationPolicy().getHost(vm).getVmScheduler()
					.getAllocatedMipsForVm(vm));
		}

		
		/**
		 * Create a pricing object and add to vm
		 * �趨�Ʒѿ�ʼʱ�䣬��ʽ
		 */
		vm.setPricemodel(getPricingModelObject(vm));
		
	}

	@Override
	protected void processVmDestroy(SimEvent ev, boolean ack) {
		// TODO Auto-generated method stub
		IntervalPricingVM vm = (IntervalPricingVM) ev.getData();
		if(vm!=null)
		{
			double rental=vm.getPricemodel().getCost(CloudSim.clock());
			if(RentalCostMap.containsKey(vm.getUserId()))
			{
				double oldcost=RentalCostMap.get(vm.getUserId());
				oldcost+=rental;
				RentalCostMap.put(vm.getUserId(), oldcost);
			}
			else
			{
				RentalCostMap.put(vm.getUserId(), rental);
			}
		}
		else
		{
			Log.printLine(getName() + ": Error in processing processVmDestroy in IntervalPricingDataCenter");
		}
		super.processVmDestroy(ev, ack);
		
	}

	/**
	 * generate a pricing object
	 * @param vm,  VM which the pricing object added to 
	 * @return pmodel, a pricing object
	 */
	private PricingModelInterface getPricingModelObject(IntervalPricingVM vm)
	{
		
		IntervalbasedPricingModel pmodel=new IntervalbasedPricingModel(CloudSim.clock()+vm.getConfig().getSetuptime(),vm.getConfig().getPrice(),vm.getConfig().getInterval());
		return pmodel; 
	}
	
	/**
	 * get the cost of a broker
	 * @param borkerid
	 * @return
	 */
	public double getCostofaBroker(Integer borkerid)
	{
		if(RentalCostMap.containsKey(borkerid))
		{
			return RentalCostMap.get(borkerid);
		}
		else
			return 0;
		
	}
	/**
     * Processes a Cloudlet submission. The cloudlet is actually a job which can
     * be cast to org.workflowsim.Job
     *
     * @param ev a SimEvent object
     * @param ack an acknowledgement
     * @pre ev != null
     * @post $none
     */
    @Override
    protected void processCloudletSubmit(SimEvent ev, boolean ack) {
        updateCloudletProcessing();

        try {
            /**
             * cl is actually a job but it is not necessary to cast it to a job
             */
            Task job = (Task) ev.getData();

            if (job.isFinished()) {
                String name = CloudSim.getEntityName(job.getUserId());
                Log.printLine(getName() + ": Warning - Cloudlet #" + job.getTaskname() + " owned by " + name
                        + " is already completed/finished.");
                Log.printLine("Therefore, it is not being executed again");
                Log.printLine();

                // NOTE: If a Cloudlet has finished, then it won't be processed.
                // So, if ack is required, this method sends back a result.
                // If ack is not required, this method don't send back a result.
                // Hence, this might cause CloudSim to be hanged since waiting
                // for this Cloudlet back.
                if (ack) {
                    int[] data = new int[3];
                    data[0] = getId();
                    data[1] = job.getCloudletId();
                    data[2] = CloudSimTags.FALSE;

                    // unique tag = operation tag
                    int tag = CloudSimTags.CLOUDLET_SUBMIT_ACK;
                    sendNow(job.getUserId(), tag, data);
                }

                sendNow(job.getUserId(), CloudSimTags.CLOUDLET_RETURN, job);

                return;
            }

            int userId = job.getUserId();
            int vmId = job.getVmId();
            Host host = getVmAllocationPolicy().getHost(vmId, userId);
            IntervalPricingVM vm = (IntervalPricingVM) host.getVm(vmId, userId);

            switch (SystemParameters.getCostModel()) {
                case DATACENTER:
                    // process this Cloudlet to this CloudResource
                    job.setResourceParameter(vmId, getCharacteristics().getCostPerSecond(),
                            getCharacteristics().getCostPerBw());
                    break;
                case VM:
                    job.setResourceParameter(vmId, vm.getCost(), vm.getCostPerBW());
                    break;
                default:
                    break;
            }
             
            /**
             * �������ִ��ʱ��
             */
            if(job.getDistributeobj()!=null)
            {
            	long actuallength=(long)job.getDistributeobj().getRunTime();
            	job.getDistributeobj().setFixedTime(actuallength);//��ͬ�㷨����ͬ�ķֲ�
            //	Log.printLine("estimatedlength:"+job.getCloudletLength()+",actuallength:"+actuallength);
            	job.setCloudletLength(actuallength);
            }
          
            
            /**
             * Stage-in file && Shared based on the file.system
             */
          /*  if (job.getClassType() == ClassType.STAGE_IN.value) {
                stageInFile2FileSystem(job);
            }*/

            /**
             * Add data transfer time (communication cost
             */
            double fileTransferTime = 0.0;
        /*    if(job.getTaskname().contains("00802"))
            {
            	int a=0;
            }*/
            fileTransferTime = processDataStageInForComputeJob(job.getFileList(), job);
          
            /**
             * �ڴ�����ʱ��Ҳ�ӵ�����ʱ����
             */
            double dtsize=job.getTotalfilesize();
		/*	for(FileItem file:job.getFileList())
			{
				dtsize+=file.getSize();
			}*/
			fileTransferTime+=dtsize/(double) Consts.MILLION/vm.getRam();//�ڴ�����ʱ��
			
			/**
			 * ִ�й���ͬ����������Ҫ��װʱ��
			 */
			if(!vm.getInstalledSoftware().contains(job.getType()))
			{
				vm.getInstalledSoftware().add(job.getType());
				fileTransferTime+=SystemSetting.susetuptime;
			}
			
            CloudletScheduler scheduler = vm.getCloudletScheduler();
            register(job);//ע���ļ�
            double estimatedFinishTime = scheduler.cloudletSubmit(job, fileTransferTime);
           // Log.printLine("����"+job.getTaskname()+"�Ѿ��������"+vm.getId()+"��ʼִ��");
            job.setAvm(vm);

            // if this cloudlet is in the exec queue
            if (estimatedFinishTime > 0.0 && !Double.isInfinite(estimatedFinishTime)) {
                send(getId(), estimatedFinishTime, CloudSimTags.VM_DATACENTER_EVENT);
                if(SystemSetting.getMainframe()!=null)
                	SystemSetting.getMainframe().UpdateVMs(vm); 
            } else {
               // Log.printLine("Warning: You schedule cloudlet to a busy VM");
            }

            if (ack) {
                int[] data = new int[3];
                data[0] = getId();
                data[1] = job.getCloudletId();
                data[2] = CloudSimTags.TRUE;

                int tag = CloudSimTags.CLOUDLET_SUBMIT_ACK;
                sendNow(job.getUserId(), tag, data);
            }
           
        } catch (ClassCastException c) {
            Log.printLine(getName() + ".processCloudletSubmit(): " + "ClassCastException error.");
        } catch (Exception e) {
            Log.printLine(getName() + ".processCloudletSubmit(): " + "Exception error.");
            e.printStackTrace();
        }
        checkCloudletCompletion();
    }
    /*
     * Stage in for a single job (both stage-in job and compute job)
     * @param requiredFiles, all files to be stage-in
     * @param job, the job to be processed
     * @pre  $none
     * @post $none
     */
    protected double processDataStageInForComputeJob(List<FileItem> requiredFiles, Task job) throws Exception {
        double time = 0.0;
        for (FileItem file : requiredFiles) {
            //The input file is not an output File 
            if (file.isRealInputFile(requiredFiles)) {
                double maxBwth = 0.0;
                List siteList = SystemSetting.getStorageList(file.getName());
                if (siteList==null) {
                   
                    int vmId = job.getVmId();
                    int userId = job.getUserId();
                    Host host = getVmAllocationPolicy().getHost(vmId, userId);
                    Vm vm = host.getVm(vmId, userId);
                    double minrate=vm.getBw();
                    if(SystemSetting.storagetransferrate<vm.getBw())
                    	minrate=SystemSetting.storagetransferrate;
                    if (minrate> 0.0) {
                        double ttime= file.getSize() / (double) Consts.MILLION / minrate;
                        time +=ttime;
                     //   Log.printLine("���ⲿ�����ļ�"+file.getName()+",transfertime:"+ttime);
                    }
                    else
                    {
                    	Log.printLine("ReplicaCatalog.storagetransferrate==0 error��������������������������������������������������������������");
                    }
                }
                else
                {
                	boolean requiredFileStagein = true;
                	 int vmId = job.getVmId();
                     int userId = job.getUserId();
                     Host host = getVmAllocationPolicy().getHost(vmId, userId);
                     Vm vm = host.getVm(vmId, userId);
	                switch (SystemSetting.getFileSystem()) 
	                {
	                    case SHARED:
	                        //stage-in job
	                       
	                     //data can not be transfered from other vm
	                    	//It can only be transfered from the shared storage or just at the local vm which generated it
	                        for (Iterator it = siteList.iterator(); it.hasNext();) 
	                        {
	                            //data is at the shared storage of the datacenter
	                            String site = (String) it.next();
	                            if (site.equals(this.getName())) {
	                            	double maxRate = Double.MIN_VALUE;
	       	                        for (Storage storage : getStorageList()) {
	       	                            double rate = storage.getMaxTransferRate();
	       	                            if (rate > maxRate) {
	       	                                maxRate = rate;
	       	                            }
	       	                        }
	       	                        if (maxRate > maxBwth) {
	 	                                maxBwth = Math.min(vm.getBw(),maxRate);
	 	                            }
	       	                        
	                            }
	                            /**
	                             * This file is already in the local vm and thus it
	                             * is no need to transfer
	                             */
	                            else if (site.equals(Integer.toString(vmId))) {
	                                requiredFileStagein = false;
	                                break;
	                            }
	                        }
	                        if (requiredFileStagein && maxBwth > 0.0) {
	                        double ttime=file.getSize() / (double) Consts.MILLION / maxBwth;
	                        time += ttime;
	                       // Log.printLine("����ƽ̨�ļ�ϵͳ�����ļ�"+file.getName()+",transfertime:"+ttime);
	                        }
	                        break;
	                    case LOCAL:
	                       
	
	                      
	                        for (Iterator it = siteList.iterator(); it.hasNext();) 
	                        {
	                            //site is where one replica of this data is located at
	                            String site = (String) it.next();
	                            if (site.equals(this.getName())) {
	                                continue;
	                            }
	                            /**
	                             * This file is already in the local vm and thus it
	                             * is no need to transfer
	                             */
	                            if (site.equals(Integer.toString(vmId))) {
	                                requiredFileStagein = false;
	                                break;
	                            }
	                            double bwth=0;
	                            if (site.equals(SystemParameters.SOURCE)) {
	                                //transfers from the source to the VM is limited to the VM bw only
	                                bwth = vm.getBw();
	                                //bwth = dcStorage.getBaseBandwidth();
	                            } else {
	                                //transfers between two VMs is limited to both VMs
	                            	//Zhicheng Cai, It may case eeception when coresponding tasks are scheduled to 
	                            	//different data centers.
	                            	Host sourcehost=getVmAllocationPolicy().getHost(Integer.parseInt(site), userId);
	                            	if(sourcehost!=null)
	                            	{
	                            		Vm sourcevm=sourcehost.getVm(Integer.parseInt(site), userId);
	                            		if(sourcevm!=null)//makesure the vm has not been destroyed
	                            			bwth = Math.min(vm.getBw(), sourcevm.getBw());
	                            	}
	                                
	                                //bwth = dcStorage.getBandwidth(Integer.parseInt(site), vmId);
	                            }
	                            if (bwth > maxBwth) {
	                                maxBwth = bwth;
	                            }
	                        }
	                        if (requiredFileStagein && maxBwth > 0.0) {
	                            time += file.getSize() / (double) Consts.MILLION / maxBwth;
	                        }
	
	                        /**
	                         * For the case when storage is too small it is not
	                         * handled here
	                         */
	                        //We should add but since CondorVm has a small capability it often fails
	                        //We currently don't use this storage to do anything meaningful. It is left for future. 
	                        //condorVm.addLocalFile(file);
	                        SystemSetting.addFileToStorage(file.getName(), Integer.toString(vmId));
	                        break;
	                }
                }
            }
        }
        return time;
    }
    @Override
    protected void updateCloudletProcessing() {
        // if some time passed since last processing
        // R: for term is to allow loop at simulation start. Otherwise, one initial
        // simulation step is skipped and schedulers are not properly initialized
        //this is a bug of CloudSim if the runtime is smaller than 0.1 (now is 0.01) it doesn't work at all
       // if (CloudSim.clock() < 0.111 || CloudSim.clock() > getLastProcessTime() + 0.000000001) {
    	if (CloudSim.clock() < 0.111 || CloudSim.clock() > getLastProcessTime()) {
            List<? extends Host> list = getVmAllocationPolicy().getHostList();
            double smallerTime = Double.MAX_VALUE;
            // for each host...
            for (Host host : list) {
                // inform VMs to update processing
                double time = host.updateVmsProcessing(CloudSim.clock());
                // what time do we expect that the next cloudlet will finish?
                if (time < smallerTime) {
                    smallerTime = time;
                }
            }
            // gurantees a minimal interval before scheduling the event
            if (smallerTime < CloudSim.clock() +CloudSim.getMinTimeBetweenEvents()) {
                smallerTime = CloudSim.clock() +CloudSim.getMinTimeBetweenEvents();
            }
            if (smallerTime != Double.MAX_VALUE) {
                schedule(getId(), (smallerTime - CloudSim.clock()), CloudSimTags.VM_DATACENTER_EVENT);
            }
            setLastProcessTime(CloudSim.clock());
            if(SystemSetting.getMainframe()!=null)
            	SystemSetting.getMainframe().UpdateVMs();
        }
    }

    /**
     * Verifies if some cloudlet inside this PowerDatacenter already finished.
     * If yes, send it to the User/Broker
     *
     * @pre $none
     * @post $none
     */
    @Override
    protected void checkCloudletCompletion() {
        List<? extends Host> list = getVmAllocationPolicy().getHostList();
        for (Host host : list) {
            for (Vm vm : host.getVmList()) {
                while (vm.getCloudletScheduler().isFinishedCloudlets()) {
                    Cloudlet cl = vm.getCloudletScheduler().getNextFinishedCloudlet();
                    if (cl != null) {
                        sendNow(cl.getUserId(), CloudSimTags.CLOUDLET_RETURN, cl);
                   /*  Task tsk=(Task)cl;
                     if(tsk.getTaskname().contains("00332"))
                     {
                     	int a=0;
                     	int b=a;
                     }
                   
                      
                        register(cl);*/
                        //����ط�ע���ļ������µȴ����������ɵ��ļ����ܱ����á��ƶ����������͵��ȴ����е�ʱ��
                    }
                }
            }
        }
    }
    /*
     * Register a file to the storage if it is an output file
     * @param requiredFiles, all files to be stage-in
     * @param job, the job to be processed
     * @pre  $none
     * @post $none
     */

    private void register(Cloudlet cl) {
        Task tl = (Task) cl;
        List<FileItem> fList = tl.getFileList();
        for (FileItem file : fList) {
            if (file.getType() == FileType.OUTPUT)//output file
            {
            	  int vmId = cl.getVmId();
                 // int userId = cl.getUserId();
                 // Host host = getVmAllocationPolicy().getHost(vmId, userId);
                switch (SystemSetting.getFileSystem()) {
                    case SHARED:
                        SystemSetting.addFileToStorage(file.getName(), this.getName());
                        
                      
                        /**
                         * Add to local file system too
                         */
                      //  CondorVM vm = (CondorVM) host.getVm(vmId, userId);
                        SystemSetting.addFileToStorage(file.getName(), Integer.toString(vmId));
                        
                        break;
                    case LOCAL:
                      
                        /**
                         * Left here for future work
                         */
                       // CondorVM vm = (CondorVM) host.getVm(vmId, userId);
                        SystemSetting.addFileToStorage(file.getName(), Integer.toString(vmId));
                        break;
                }
            }
        }
    }
   
}
