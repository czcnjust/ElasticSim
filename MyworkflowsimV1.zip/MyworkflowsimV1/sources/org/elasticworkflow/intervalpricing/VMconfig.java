package org.elasticworkflow.intervalpricing;

/**
 * The class to store the configuration of VMs used in the datacenter
 * we can model the comercial public clouds
 * @author Zhicheng Cai
 *@since WorkflowSimPricing Toolkit 1.0
 * @date Nov 11, 2015
 */
public class VMconfig {
	
	private int datacenterid;
	/**
	 * the vm type, e.g., the vm type of Amazon EC2
	 */
    private String vmtype;
	/** The storage size. */
	private long storagesize;

	/** The MIPS. */
	private double mips;

	/** The number of PEs. */
	private int numberOfPes;

	/** The ram. */
	private int ram;

	/** The bw. */
	private long bw;

	/** The vmm. */
	private String vmm;
	
	/**
	 * price per interval
	 */
	private double price;
	/**
	 * length of pricing interval
	 */
	private double interval;
	
	/**
	 * the setup time for initializing a vm
	 */
	private double setuptime;
	public double getSetuptime() {
		return setuptime;
	}



	public void setSetuptime(double setuptime) {
		this.setuptime = setuptime;
	}



	public double getCostPerMem() {
		return costPerMem;
	}



	public double getCostPerStorage() {
		return costPerStorage;
	}



	public double getCostPerBW() {
		return costPerBW;
	}

	private double costPerMem;
	
	private double costPerStorage;
	
	private double costPerBW;
	
	public int getDatacenterid() {
		return datacenterid;
	}



	protected void setDatacenterid(int datacenterid) {
		this.datacenterid = datacenterid;
	}



	public VMconfig(String vmtype, long storagesize, double mips, int numberOfPes, int ram, long bw, String vmm,
			double price, double interval, double costPerMem, double costPerStorage, double costPerBW,int centerid,
			double setuptime) {
		super();
		this.vmtype = vmtype;
		this.storagesize = storagesize;
		this.mips = mips;
		this.numberOfPes = numberOfPes;
		this.ram = ram;
		this.bw = bw;
		this.vmm = vmm;
		this.price = price;
		this.interval = interval;
		this.costPerMem = costPerMem;
		this.costPerStorage = costPerStorage;
		this.costPerBW = costPerBW;
		this.datacenterid= centerid;
		this.setuptime=setuptime;
	}



	public VMconfig(String vmtype, long storagesize, double mips, int numberOfPes, int ram, long bw, String vmm,
			double price, double interval,int centerid) {
		super();
		this.vmtype = vmtype;
		this.storagesize = storagesize;
		this.mips = mips;
		this.numberOfPes = numberOfPes;
		this.ram = ram;
		this.bw = bw;
		this.vmm = vmm;
		this.price = price;
		this.interval = interval;
		this.datacenterid= centerid;
	}

	

	public double getPrice() {
		return price;
	}



	public double getInterval() {
		return interval;
	}



	public String getVmtype() {
		return vmtype;
	}

	public long getStoragesize() {
		return storagesize;
	}

	public double getMips() {
		return mips;
	}

	public int getNumberOfPes() {
		return numberOfPes;
	}

	public int getRam() {
		return ram;
	}

	public long getBw() {
		return bw;
	}

	public String getVmm() {
		return vmm;
	}
	
}
