package org.elasticworkflow.intervalpricing;

import java.util.List;

/**
 * 
 * @author Zhicheng Cai
 * @since WorkflowSimPrincing Toolkit 1.0
 */
public interface PricingModelInterface {

	/**
     * Get the cost from starting time until current
     * @param curtime current time
     */
    public double getCost(double curtime);
    
    /**
     * Get the time of starting pricing
     * 
     */
    public double getPricingStarttime();
    
    /**
     * Get the price of per unit
     * 
     */
    public double getPricePerUnit();
    
    /**
     * Get the length of pricing interval
     * 
     */
    public double getLengthofPriceInterval();
}
