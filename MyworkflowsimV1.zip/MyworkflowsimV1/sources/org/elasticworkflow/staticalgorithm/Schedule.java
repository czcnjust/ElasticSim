package org.elasticworkflow.staticalgorithm;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;

import org.elasticworkflow.intervalpricing.*;
public class Schedule {
	Hashtable<IJob,IMode> schedule=new Hashtable<IJob,IMode>();
	private Hashtable<VMconfig,ArrayList<VMInstance>> instances=new Hashtable<VMconfig,ArrayList<VMInstance>>();
	private Hashtable<IJob,VMInstance> VMmap=new Hashtable<IJob,VMInstance>();
	private Hashtable<IJob,Double> ST=new Hashtable<IJob,Double>();
	private Hashtable<IJob,Double> FT=new Hashtable<IJob,Double>();
	private Hashtable<IJob,Double> EST=new Hashtable<IJob,Double>();
	private Hashtable<IJob,Double> LFT=new Hashtable<IJob,Double>();
	
	public void Initilize(ArrayList<VMInstance> instancearray)
	{
		for(int i=0;i<instancearray.size();i++)
		{
			VMInstance ins=instancearray.get(i);
			ArrayList<VMInstance> tempinstancearray=instances.get(ins.getVMType());
			if(tempinstancearray==null)
			{
				tempinstancearray=new ArrayList<VMInstance>();
				instances.put(ins.getVMType(), tempinstancearray);
			}
			tempinstancearray.add(ins);
		}
	}
	public void Commit(ArrayList<VMInstance> origiarray)
	{
		origiarray.clear();
		Enumeration<VMconfig> typeiter= instances.keys();
		while(typeiter.hasMoreElements())
		{
			VMconfig type=typeiter.nextElement();
			ArrayList<VMInstance> instancearray=instances.get(type);
			
			for(int i=0;i<instancearray.size();i++)
			{
				VMInstance vmi=instancearray.get(i);
				origiarray.add(vmi);
			}
		}
	}
	public VMInstance AddNewInstance(VMconfig type)
	{
		VMInstance vmi=new VMInstance(type);
		ArrayList<VMInstance> tempinstancearray=instances.get(type);
		if(tempinstancearray==null)
		{
			tempinstancearray=new ArrayList<VMInstance>();
			instances.put(type, tempinstancearray);
		}
		tempinstancearray.add(vmi);
		return vmi;
	}
	public Hashtable<IJob, Double> getST() {
		return ST;
	}
	public Hashtable<IJob, Double> getEST() {
		return EST;
	}
	public void setEST(Hashtable<IJob, Double> eST) {
		EST = eST;
	}
	public Hashtable<IJob, Double> getLFT() {
		return LFT;
	}
	public void setLFT(Hashtable<IJob, Double> lFT) {
		LFT = lFT;
	}
	public void setST(Hashtable<IJob, Double> sT) {
		ST = sT;
	}
	public Hashtable<IJob, Double> getFT() {
		return FT;
	}
	public void setFT(Hashtable<IJob, Double> fT) {
		FT = fT;
	}
	public Hashtable<VMconfig, ArrayList<VMInstance>> getInstances() {
		return instances;
	}
	public void setInstances(Hashtable<VMconfig, ArrayList<VMInstance>> instances) {
		this.instances = instances;
	}
	public Hashtable<IJob, VMInstance> getVMmap() {
		return VMmap;
	}
	public void setVMmap(Hashtable<IJob, VMInstance> vMmap) {
		VMmap = vMmap;
	}
	private double cost=0;
	public void setSeledMode(IJob jb,IMode mode)
	{
		if(schedule.containsKey(jb))
		{
			IMode lastmode=schedule.get(jb);
			cost=cost+mode.getCost()-lastmode.getCost();
		}
		else
			cost+=mode.getCost();
		schedule.put(jb, mode);
		
	}
	public IMode getSeledMode(IJob jb)
	{
		return schedule.get(jb);
	}
	public void RemoveSelection(IJob jb)
	{
		if(schedule.containsKey(jb))
		{
			IMode lastmode=schedule.get(jb);
			cost=cost-lastmode.getCost();
			schedule.remove(jb);
		}
		
	}
	public void Clear()
	{
		schedule.clear();
	}
	public double getCost()
	{
		return cost;
	}
	/**
	 * ��¡����
	 * @return
	 */
	public Schedule Clone()
	{
		//TimeMeasure measure=new TimeMeasure();
		//measure.start();
		Schedule newsh=new Schedule();
		Enumeration<IJob> jobiter= schedule.keys();
		while(jobiter.hasMoreElements())
		{
			IJob tempjb=jobiter.nextElement();
			IMode seledmode=schedule.get(tempjb);
			newsh.setSeledMode(tempjb, seledmode);
		}
		/**
		 * ���������ʵ��
		 */
		Enumeration<VMconfig> typeiter= instances.keys();
		while(typeiter.hasMoreElements())
		{
			VMconfig type=typeiter.nextElement();
			ArrayList<VMInstance> instancearray=instances.get(type);
			ArrayList<VMInstance> newinstancearray=new ArrayList<VMInstance>();
			newsh.getInstances().put(type, newinstancearray);
			for(int i=0;i<instancearray.size();i++)
			{
				VMInstance vmi=instancearray.get(i);
				VMInstance newvmi=vmi.Clone();
				//measure.end("vmi.Clone()");
				newinstancearray.add(newvmi);
				ArrayList<TimeSlot> slots= newvmi.getUsedslots();
				for(int j=0;j<slots.size();j++)
				{
					TimeSlot slot=slots.get(j);
					newsh.getVMmap().put(slot.getAssignedjb(), newvmi);
				}
			}
		}
		//measure.end("step1");
		Enumeration<IJob> jbiter= this.FT.keys();
		while(jbiter.hasMoreElements())
		{
			IJob tjb=jbiter.nextElement();
			newsh.getFT().put(tjb, this.FT.get(tjb));
			
		}
		Enumeration<IJob> jbiter1= this.ST.keys();
		while(jbiter1.hasMoreElements())
		{
			IJob tjb=jbiter1.nextElement();
			newsh.getST().put(tjb, this.ST.get(tjb));
			
		}
		Enumeration<IJob> jbiter2= this.EST.keys();
		while(jbiter2.hasMoreElements())
		{
			IJob tjb=jbiter2.nextElement();
			newsh.getEST().put(tjb, this.EST.get(tjb));
			
		}
		
		Enumeration<IJob> jbiter3= this.LFT.keys();
		while(jbiter3.hasMoreElements())
		{
			IJob tjb=jbiter3.nextElement();
			newsh.getLFT().put(tjb, this.LFT.get(tjb));
			
		}
		//measure.end("step2");
		return newsh;
	}
	public double getResourceRentCost()
	{
		//Clog.setEnable(false);
		double rental=0;
		Enumeration<VMconfig> typeiter= instances.keys();
		while(typeiter.hasMoreElements())
		{
			VMconfig type=typeiter.nextElement();
			ArrayList<VMInstance> instancearray=instances.get(type);
			int totalhour=0;
			for(int i=0;i<instancearray.size();i++)
			{
				VMInstance vmi=instancearray.get(i);
				int renthours=vmi.getRentedHours();
				totalhour+=renthours;
				Clog.LogInfo("�������"+vmi.getGuid()+"������"+renthours+"��Сʱ");
			}
			
			double cost=totalhour*type.getPrice();
			Clog.LogInfo(type+"��������:"+totalhour+"��Сʱ�����ۣ�"+type.getPrice()+"�ܼۣ�"+cost);
			rental+=cost;
		}
		//Clog.setEnable(true);
		Clog.LogInfo("����������������޳ɱ��ǣ�"+rental);
		Clog.LogInfo("-------------------------------------------------------------------------");
		
		return rental;
	}
	public void Display()
	{
		Enumeration<IJob> jobiter= schedule.keys();
		while(jobiter.hasMoreElements())
		{
			IJob tempjb=jobiter.nextElement();
			IMode seledmode=schedule.get(tempjb);
			
			Clog.LogInfo(tempjb.getGUID()+"(duration:"+seledmode.getDurationDouble()+"Transfer:"+seledmode.getTransferTime()+"_"+seledmode.getVMType()+",Cost:"+seledmode.getCost()+")");
		}
		Clog.LogInfo("Cost1:"+this.cost);
		
		Enumeration<VMconfig> typeiter= instances.keys();
		while(typeiter.hasMoreElements())
		{
			VMconfig type=typeiter.nextElement();
			ArrayList<VMInstance> instancearray=instances.get(type);
			for(int i=0;i<instancearray.size();i++)
			{
				VMInstance vmi=instancearray.get(i);
				String jobs="";
				for(int j=0;j<vmi.getUsedslots().size();j++)
				{
					TimeSlot slot=vmi.getUsedslots().get(j);
					jobs+=slot.getAssignedjb().getGUID()+",Time:"+slot.getDfrom()+"-"+slot.getDto()+ "----";
				}
				Clog.LogInfo("�������"+vmi.getGuid()+"������"+jobs);
			}  
		}
	}
}
