package org.elasticworkflow.staticalgorithm;
public interface ILevel {

}
