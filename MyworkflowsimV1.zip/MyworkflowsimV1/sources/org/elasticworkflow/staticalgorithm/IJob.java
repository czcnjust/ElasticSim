package org.elasticworkflow.staticalgorithm;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;

import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.elasticworkflow.Task;
import org.elasticworkflow.intervalpricing.*;
public interface IJob {
	/**
	 * @return  Returns the guid.
	 * @uml.property  name="GUID"
	 */
	public String getGUID();
	
	public void setGUID(String name);
	/**
	 * ��ȡ��̵��ַ�����ʾ
	 * @return
	 */
	public String getSuccessors();
	public void setSuccessors(String successors);
	/**
	 * ��ȡ���������index
	 * @return
	 */
	public Integer getInerIndex();
	
	public void serInerIndex(int index);
		/**
		 * @return  Returns the predecessor.
		 * @uml.property  name="Predecessor"
		 */
	public Hashtable<String,IJob> getPredecessor();

		/**
		 * Setter of the property <tt>Predecessor</tt>
		 * @param Predecessor  The predecessor to set.
		 * @uml.property  name="Predecessor"
		 */
	public void AddPredecessor(IJob jb);

		/**
		 * @return  Returns the successor.
		 * @uml.property  name="Successor"
		 */
	public Hashtable<String,IJob> getSuccessor();
		/**
		 * Setter of the property <tt>Successor</tt>
		 * @param Successor  The successor to set.
		 * @uml.property  name="Successor"
		 */
	public void AddSuccessor(IJob jb);

		/**
		 * @return  Returns the duration.
		 * @uml.property  name="duration"
		 */
	public ArrayList<IMode> getModes();
	public void AddMode(IMode md);
	
	/**
	 * ��ȡjob���ַ�����ʾ
	 * @return
	 */
	public String getJobString();
	/**
	 * ���ַ��� ����job
	 * @param strjb
	 */
	public void Construct(Task tsk,Map<Integer, DatacenterCharacteristics> datacenterCharacteristicsList);
	/**
	 * ��ȡ������Ԫ
	 */
	public String getSoftUnit();
	public void setSoftUnit(String su);
	
	/**
	 * ��ȡ���������������
	 * @return
	 */
	public TASKTYPE getTASKTYPE();
	public void setTASKTYPE(TASKTYPE type);
	
	public double getMEMTASK();
	public void setMEMTASK(double mEMTASK);
	public double getCPUTASK();
	public void setCPUTASK(double cPUTASK);
	
	public int getLevel();
	public void setLevel(int level);
	public IMode getSelMode();
	public void setSelMode(IMode selmode);
	public double getFloatduration();
	public void setFloatduration(double floatduration);
	public double getSeedtime();
	public void setSeedtime(double seedtime) ;
	public double getDeadline();
	public void setDeadline(double deadline) ;
	public TimeSlot getAssiganedslot();
	public void setAssiganedslot(TimeSlot assiganedslot);
	public IMode getNextCandidateMode(IMode origmode);
	public IMode getLongestCheapestMode();
	public IMode getMode(VMconfig VMtype);
	public double getInputData(String jb);
	public Hashtable<String, Double> getDatatransferfrom();
	public double getMaximumDatatransfertime(double bandwidth);
	public boolean setSelMode(VMconfig vmtype);
	public int getBackdepth();
	public void setBackdepth(int backdepth);
	public ISoftUnit getSunitobject();
	public void setSunitobject(ISoftUnit sunitobject);
	public Task getTask();
	public void setTask(Task task);
}
