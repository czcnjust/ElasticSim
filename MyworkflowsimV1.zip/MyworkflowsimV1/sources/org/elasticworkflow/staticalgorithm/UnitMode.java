package org.elasticworkflow.staticalgorithm;
import org.elasticworkflow.intervalpricing.*;
public class UnitMode{

	/**
	 * ��unitʹ�õ����������
	 */
	private VMconfig VMType;
	/**
	 * ��
	 * unit����������ִ��ʱ�䣬������softwaresetuptime
	 */
	private double maxProcessingTime=0;
	/**
	 * �ܵ�ʵ��ִ�гɱ�
	 */
	private double totalcost=0;
	/**
	 * �ܵ�ʱ��Ƭ���޳ɱ�
	 */
	private double totalintervalrental=0;
	
	/**
	 * �ܵ���Ч����ʱ�� ������softwaresetuptime
	 */
	private double totalprocessingtime=0;
	public VMconfig getVMType() {
		return VMType;
	}
	public void setVMType(VMconfig vMType) {
		VMType = vMType;
	}
	public double getMaxProcessingTime() {
		return maxProcessingTime;
	}
	public void setMaxProcessingTime(double maxProcessingTime) {
		this.maxProcessingTime = maxProcessingTime;
	}
	public double getTotalcost() {
		return totalcost;
	}
	public void setTotalcost(double totalcost) {
		this.totalcost = totalcost;
	}
	public double getTotalintervalrental() {
		return totalintervalrental;
	}
	public void setTotalintervalrental(double totalintervalrental) {
		this.totalintervalrental = totalintervalrental;
	}
	public double getTotalprocessingtime() {
		return totalprocessingtime;
	}
	public void setTotalprocessingtime(double totalprocessingtime) {
		this.totalprocessingtime = totalprocessingtime;
	}
	
}
