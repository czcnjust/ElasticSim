package org.elasticworkflow.staticalgorithm;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.HashSet;
import java.util.Enumeration;
import java.util.Iterator;

import org.elasticworkflow.FileItem;
import org.elasticworkflow.SystemParameters.FileType;
import org.elasticworkflow.intervalpricing.*;

public class VMInstance {

	private static int id=0;
	private String Guid;
	private VMconfig VMType;
	private double startrentingtime=0;
	private ArrayList<TimeSlot> usedslots=new ArrayList<TimeSlot>();
	private Hashtable<IJob,TimeSlot> jobmap=new Hashtable<IJob,TimeSlot>();
	//private ArrayList<TimeSlot> freeslots=new ArrayList<TimeSlot>();
	public HashSet<Long> rentedhour=new HashSet<Long>();
	private HashSet<String> containedfiles=new HashSet<>();
	public void Destroy()
	{
		usedslots.clear();
		jobmap.clear();
		rentedhour.clear();
	}
	public double getStartrentingtime() {
		return startrentingtime;
	}
	/**
	 * ��ʼ����ʱ��
	 * @param startrentingtime
	 */
	public void setStartrentingtime(double startrentingtime) {
		this.startrentingtime = startrentingtime;
	}
	public boolean ContainsFile(String file)
	{
		if(containedfiles.contains(file))
			return true;
		else
			return false;
	}
	/**
	 * ��¡�����ʵ��
	 * @return
	 */
	public VMInstance Clone()
	{
		//TimeMeasure measure=new TimeMeasure();
		//measure.start();
		VMInstance newvmi=new VMInstance(VMType);
		newvmi.Guid=this.Guid;
		//measure.end("new VMInstance(VMType);");
		for(int i=0;i<usedslots.size();i++)
		{
			TimeSlot slot=usedslots.get(i);
			TimeSlot newslot=new TimeSlot(newvmi,slot.getDfrom(),slot.getDto());
			if(slot.getAssignedjb()!=null)
			{
				newslot.setAssignedjb(slot.getAssignedjb());
				slot.getAssignedjb().setAssiganedslot(newslot);
				newvmi.getJobmap().put(slot.getAssignedjb(), newslot);
			}
			newvmi.usedslots.add(newslot);
			
			//measure.end("usedslots.size()");
		}
		//measure.end("VMInstance Clone()");
		for(int i=0;i<newvmi.getUsedslots().size();i++)
		{
			TimeSlot slot=newvmi.getUsedslots().get(i);
			int preindex=i-1;
			int surindex=i+1;
			TimeSlot preslot=null,surslot=null;
			if(preindex>=0)
			{
				preslot=newvmi.getUsedslots().get(preindex);
				slot.setPredecessor(preslot);
				preslot.setSucessor(slot);
			}
			if(surindex<newvmi.getUsedslots().size())
			{
				surslot=newvmi.getUsedslots().get(surindex);
				slot.setSucessor(surslot);
				surslot.setPredecessor(slot);
			}
		}
		
		Iterator<Long> riter= rentedhour.iterator();
		while(riter.hasNext())
		{
			Long va=riter.next();
			newvmi.rentedhour.add(va);
		}
		//newvmi.freeslots.clear();
		//measure.end("VMInstance Clone()");
		return newvmi;
	}
	public ArrayList<TimeSlot> getUsedslots() {
		return usedslots;
	}
	
	public String getGuid() {
		return Guid;
	}
	
	public VMInstance(VMconfig VMtype) {
		//super();
		//TimeMeasure measure=new TimeMeasure();
		//measure.start();
		this.VMType=VMtype;
		id++;
		this.Guid=VMtype.getVmtype()+"_"+id;
		//measure.end("this.Guid=VMtype++FuncLib.GetGuid();");
		// TODO Auto-generated constructor stub
	}
	public VMconfig getVMType() {
		return VMType;
	}
	
	public Hashtable<IJob, TimeSlot> getJobmap() {
		return jobmap;
	}
	
	public TimeSlot AssignJob(IJob jb, double fromtime, double totime)
	{
		boolean conflicted=false;
		TimeSlot sucessorslot=null;
		int index=-1;
		for(int i=0;i<usedslots.size();i++)
		{
			TimeSlot slot=usedslots.get(i);
			double begin=slot.getDfrom();
			double end=slot.getDto();
			if(end<fromtime)
				continue;
			if(fromtime!=totime
			  &&(fromtime>=begin&&fromtime<end
					||totime>begin&&totime<=end
					||fromtime>=begin&&totime<=end))
			/*if(!FuncLib.EqualDouble(fromtime, totime, 6)
					&&(FuncLib.EqualLessDouble(begin, fromtime, 6)&&FuncLib.LessDouble(fromtime, end, 6)
					||FuncLib.LessDouble(begin, totime, 6)&&FuncLib.EqualLessDouble(totime, end, 6)
					||FuncLib.EqualLessDouble(begin, fromtime, 6)&&FuncLib.EqualLessDouble(totime, end, 6)))*/
			{
				conflicted=true;
				return null;
			}
			if(begin>totime)
			{
				sucessorslot=slot;
				index=i;
				break;
			}
			else if(begin==totime)
			{
				if(begin!=end)//��0����
				{
					sucessorslot=slot;
					index=i;
					break;
				}
				else//���г���Ϊ0����
				{
					if(fromtime!=totime)//�������䳤�Ȳ�Ϊ0
					{
						sucessorslot=slot;
						index=i;
						break;
					}
					else//�������䳤��Ϊ0
					{
						//������Ҫ��ǰ��
						if(jb.getInerIndex()<slot.getAssignedjb().getInerIndex())
						{
							sucessorslot=slot;
							index=i;
							break;
						}
					}
				}
			}
		}
		if(this.startrentingtime>fromtime)
			this.startrentingtime=fromtime;
		TimeSlot newslot=new TimeSlot(this,fromtime,totime);
		newslot.setAssignedjb(jb);
	
	
		if(index==-1)
		{
			usedslots.add(newslot);
			if(usedslots.size()>1)
			{
				TimeSlot preslot=usedslots.get(usedslots.size()-2);
				newslot.setPredecessor(preslot);
				preslot.setSucessor(newslot);	
			}
		}
		else
		{
			
			usedslots.add(index, newslot);
			int preindex=index-1;
			int surindex=index+1;
			TimeSlot preslot=null,surslot=null;
			if(preindex>=0)
			{
				preslot=usedslots.get(preindex);
				newslot.setPredecessor(preslot);
				preslot.setSucessor(newslot);
			}
			if(surindex<usedslots.size())
			{
				surslot=usedslots.get(surindex);
				newslot.setSucessor(surslot);
				surslot.setPredecessor(newslot);
			}
			
		}
		jobmap.put(jb, newslot);
		jb.setAssiganedslot(newslot);
		 for (FileItem file : jb.getTask().getFileList()) 
	          if (file.getType() == FileType.OUTPUT)//output file
	           {
	        	  this.containedfiles.add(file.getName());
	           }
		
		//ˢ�����޵�����
		this.rentedhour.clear();
		for(int i=0;i<usedslots.size();i++)
		{
			TimeSlot slot=usedslots.get(i);
			slot.RentSlot();//���޸�ʱ��Ƭ
		}
		//freeslots.clear();
		return newslot;
	}

	/**
	 * �Ӹ�ʵ��ȡ����job
	 * @param jb
	 * @return
	 */
	public boolean RemoveJob(IJob jb)
	{
		TimeSlot slot= jobmap.get(jb);
		if(slot==null)
			return false;
		jobmap.remove(jb);
		TimeSlot preslot= slot.getPredecessor();
		TimeSlot surslot=slot.getSucessor();
		if(preslot!=null&&surslot!=null)
		{
			preslot.setSucessor(surslot);
			surslot.setPredecessor(preslot);
		}
		else if(preslot!=null&&surslot==null)
		{
			preslot.setSucessor(null);
		}
		else if(preslot==null&&surslot!=null)
		{
			surslot.setPredecessor(null);
		}
		slot.ReleaseSlot();//�ͷ��Ѿ����޵�Сʱ
		this.containedfiles.removeAll(jb.getTask().getFileList());
		//freeslots.clear();
		return usedslots.remove(slot);
	}
	/**
	 *��ȡbegin ��endʱ�������ڵĿ���ʱ��Ƭ
	 * @param deadline
	 * @return
	 */
	public ArrayList<TimeSlot> getFreeTimeSlot(double from,double to)
	{
		ArrayList<TimeSlot> freeslots1=new ArrayList<TimeSlot>();
		double fbegin=-1;
		for(int i=0;i<usedslots.size();i++)
		{
			TimeSlot slot=usedslots.get(i);
			double begin=slot.getDfrom();
			double end=slot.getDto();
			if(end<=from)
				continue;
			if(fbegin==-1)
			{
				if(begin<=from)
				{
					fbegin=end;
					continue;
				}
				else
				{
					fbegin=from;
				}
			}
			if(begin!=fbegin)
			{
				double fend=begin>to? to:begin;
				TimeSlot freeslot=new TimeSlot(this,fbegin,fend);
				freeslots1.add(freeslot);
				if(i>0)
				{
					TimeSlot preslot=usedslots.get(i-1);
					freeslot.setPredecessor(preslot);
				}
				if(begin>to)
				{
					fbegin=end;
					break;
				}
			}
			fbegin=end;
		}
		if(fbegin==-1)
		{
			fbegin=from;
		}
		if(fbegin<=to)
		{
			TimeSlot freeslot=new TimeSlot(this,fbegin,to);
			freeslots1.add(freeslot);
			if(usedslots.size()>0)
			{
				TimeSlot preslot=usedslots.get(usedslots.size()-1);
				freeslot.setPredecessor(preslot);
			}
		}
		return freeslots1;
	}

	/**
	 * ��ȡ�Ѿ����޵�ʱ����
	 * @return
	 */
	public int getRentedHours()
	{
		return rentedhour.size();
	}
	
	/**
	 * ��ȡ����������˷ѱ���
	 * @return
	 */
	public double getUseRate()
	{
		double dtotalused=0;
		for(int i=0;i<usedslots.size();i++)
		{
			TimeSlot slot=usedslots.get(i);
			double duration=slot.getDto()-slot.getDfrom();
			dtotalused+=duration;
		}
		double totalrentedtime=rentedhour.size()*VMType.getInterval();
		if(totalrentedtime==0)
			return 0;
		return dtotalused/totalrentedtime;
		
	}
}
