package org.elasticworkflow.staticalgorithm;

import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.HashSet;
import java.util.Iterator;

import org.cloudbus.cloudsim.Log;


public class FuncLib {

	
	/**
	 * ÿ���ѡ�����������ģ̬,Schedule�п�����Щ���ģ̬�Ѿ�ȷ��,�����Ƿ���Ŀ���ʱ������
	 * @param pj
	 * @param schedule
	 * @param EFT
	 * @param EST
	 * @return
	 */
	public static boolean GenerateEarliestFinishSchedule2(IProject pj,Schedule schedule,Hashtable<IJob,Double> EFT,Hashtable<IJob,Double> EST,double bandwidth,double sfsetuptime)
	{
		int jobcount=pj.getJobNumber();
		for(int i=1;i<=jobcount;i++)
		{
			IJob tempjb=pj.getJbindextable().get(i);
			/**
			 * �����翪ʼʱ��
			 */
			double EStime=0;
			if(tempjb.getPredecessor()!=null)
			{
				Enumeration<IJob> predeiter=tempjb.getPredecessor().elements();
				while(predeiter.hasMoreElements())
				{
					try
					{
						IJob prejb=predeiter.nextElement();
						if(!EFT.containsKey(prejb))
						{
							Clog.LogInfo(prejb.getGUID()+"û����EFT��");
						}
						double eFT=EFT.get(prejb);
						if(eFT>EStime)
						{
							EStime=eFT;
						}
					}catch(Exception e)
					{
						Clog.LogError("", e);
					}
				}
			}
			EST.put(tempjb, EStime);
			IMode EFmode=schedule.getSeledMode(tempjb);//�������ģ̬
		
			ArrayList<IMode> modes=tempjb.getModes();
			if(EFmode!=null)//����û��ģ̬�Ѿ�Ԥ��ȷ����
			{
				modes=new ArrayList<IMode>();
				modes.add(EFmode);
			}
			double EFTime=-1;
			for(int j=0;j<modes.size();j++)
			{
				IMode tempmode=modes.get(j);
				double duration=tempmode.getDurationDouble()+tempmode.getTransferTime()+sfsetuptime;
				if(EFTime==-1||EStime+duration<EFTime)
				{
					EFTime=EStime+duration;
					EFmode=tempmode;
				}
			}
			if(EFmode!=null)
			{
				schedule.setSeledMode(tempjb, EFmode);
			//	Log.printLine(tempjb.getTask().getTaskname()+":Cloudledlength:"+tempjb.getTask().getCloudletLength()+",shijian "+EFmode.getDurationDouble());
				EFT.put(tempjb, EFTime);
			}
			else
			{
				EFT.put(tempjb, EStime);
				//Clog.LogInfo("GenerateEarliestFinishSchedule������Ŀû�п��е��ȣ�");
				//return false;
			}
		}
		return true;
	}
	public static  boolean IsConected(IJob start,IJob end)
	{
		ArrayList<IJob> queue=new ArrayList<IJob>();
		IJob curjb=start;
		while(curjb!=null)
		{
			Enumeration<IJob> suriter= curjb.getSuccessor().elements();
			while(suriter.hasMoreElements())
			{
				IJob tjb=suriter.nextElement();
				if(tjb.equals(end))
				{
					return true;
				}
				else
				{
					queue.add(tjb);
				}
			}
			curjb=null;
			if(queue.size()>0)
				curjb=queue.remove(0);
		}
		return false;
	}
	/**
	 * �������� ���ȣ����Ǵ���ʱ��
	 * @param pj
	 * @param schedule
	 * @param EFT
	 * @param EST
	 * @return
	 */
	public static boolean GenerateLatestFinishSchedule2(IProject pj,Schedule schedule,Hashtable<IJob,Double> LFT,Hashtable<IJob,Double> EST,double bandwidth,double sfsetuptime)
	{
		int jobcount=pj.getJobNumber();
		for(int i=1;i<=jobcount;i++)
		{
			IJob tempjb=pj.getJbindextable().get(i);
			/**
			 * �����翪ʼʱ��
			 */
			double EStime=0;
			if(tempjb.getPredecessor()!=null)
			{
				Enumeration<IJob> predeiter=tempjb.getPredecessor().elements();
				while(predeiter.hasMoreElements())
				{
					try
					{
						IJob prejb=predeiter.nextElement();
						if(!LFT.containsKey(prejb))
						{
							Clog.LogInfo(prejb.getGUID()+"û����EFT��");
						}
						double eFT=LFT.get(prejb);
						if(eFT>EStime)
						{
							EStime=eFT;
						}
					}catch(Exception e)
					{
						Clog.LogError("", e);
					}
				}
			}
			EST.put(tempjb, EStime);
			IMode EFmode=schedule.getSeledMode(tempjb);//�������ģ̬
		
			ArrayList<IMode> modes=tempjb.getModes();
			if(EFmode!=null)//����û��ģ̬�Ѿ�Ԥ��ȷ����
			{
				modes=new ArrayList<IMode>();
				modes.add(EFmode);
			}
			double LFTime=-1;
			for(int j=0;j<modes.size();j++)
			{
				IMode tempmode=modes.get(j);
				double duration=tempmode.getDurationDouble()+tempmode.getTransferTime()+sfsetuptime;
			
				if(LFTime==-1||EStime+duration>LFTime)
				{
					LFTime=EStime+duration;
					EFmode=tempmode;
				}
			}
			if(EFmode!=null)
			{
				schedule.setSeledMode(tempjb, EFmode);
				LFT.put(tempjb, LFTime);
			}
			else
			{
				LFT.put(tempjb, EStime);
				//Clog.LogInfo("GenerateEarliestFinishSchedule������Ŀû�п��е��ȣ�");
				//return false;
			}
		}
		return true;
	}
	/**
	 * ö�ٸ���Ŀ������·��
	 * @return
	 */
	public static ArrayList<String> PathEnumration(IProject pj)
	{
		ArrayList<String> pathlist=new ArrayList<String>();
		ArrayList<IJob> pjstack=new ArrayList<IJob>();
		ArrayList<Integer> statestack=new ArrayList<Integer>();
		pjstack.add(pj.getStartjb());
		statestack.add(0);
		while(pjstack.size()>0)
		{
			IJob current_jb=pjstack.get(pjstack.size()-1);
			int curid=statestack.get(pjstack.size()-1);
			//Clog.LogInfo(String.valueOf(current_jb.getInerIndex()));
			Hashtable<String,IJob> sucessors=current_jb.getSuccessor();
			if(sucessors.size()==0)
			{
				/**
				 * �����ǰ·��
				 */
				String strpath="";
				for(int i=0;i<pjstack.size();i++)
				{
					strpath+=String.valueOf(pjstack.get(i).getInerIndex())+",";
				}
				Clog.LogInfo(strpath);
				pathlist.add(strpath);
				pjstack.remove(pjstack.size()-1);
				statestack.remove(statestack.size()-1);
				continue;
			}
			
			/**
			 * ����Ƿ��пɱ����������ڵ�
			 */
			IJob avajb=null;
			Enumeration<IJob> suc_iter=sucessors.elements();
			while(suc_iter.hasMoreElements())
			{
				IJob tempjb=suc_iter.nextElement();
				int id=tempjb.getInerIndex();
				if(id>curid)
				{
					if(avajb==null||avajb.getInerIndex()>tempjb.getInerIndex())
						avajb=tempjb;
				}
			}
			if(avajb!=null)
			{
				/**
				 * ����û�м����ӽڵ�
				 */
				pjstack.add(avajb);
			
				statestack.set(statestack.size()-1,avajb.getInerIndex());
				statestack.add(0);
			}
			else
			{
				/**
				 *  û���������нڵ���
				 */
				pjstack.remove(pjstack.size()-1);
				statestack.remove(statestack.size()-1);
			}
			
		}
		return pathlist;
	}
	/**
	 * ���ݵ��ȷ�����ؼ�·��
	 * @param pj
	 * @param schedule
	 * @return
	 */
	public static ArrayList<IJob> getCriticalPath(IProject pj,Hashtable<IJob,Integer> FT)
	{
		
		ArrayList<IJob> CP=new ArrayList<IJob>();
		//����FT��ؼ�·��
		IJob cjb=pj.getEndjb();
		while(cjb!=null)
		{
			if(cjb!=null)
			{
				CP.add(0, cjb);
			}
			int EStime=-1;
			IJob parentjb=null;
			if(cjb.getPredecessor()!=null)
			{
				Enumeration<IJob> predeiter=cjb.getPredecessor().elements();
				while(predeiter.hasMoreElements())
				{
					IJob prejb=predeiter.nextElement();
					int eFT=FT.get(prejb);
					if(eFT>EStime)
					{
						EStime=eFT;
						parentjb=prejb;
					}
				}
			}
			cjb=parentjb;
		}
		return CP;
	}
	/**
	 * ����schedule�����У�ÿһ������������ʱ��
	 * @param schedule
	 * @return
	 */
	public static Hashtable<IJob,Double> GetFinishTimeofSchedule(IProject pj,Schedule schedule)
	{
		
		Hashtable<IJob,Double> FT=new Hashtable<IJob,Double>();//����ʱ��
		int jobcount=pj.getJobNumber();
		for(int i=1;i<=jobcount;i++)
		{
			IJob tempjb=pj.getJbindextable().get(i);
			/**
			 * �����翪ʼʱ��
			 */
			double EStime=0;
			if(tempjb.getPredecessor()!=null)
			{
				Enumeration<IJob> predeiter=tempjb.getPredecessor().elements();
				while(predeiter.hasMoreElements())
				{
					IJob prejb=predeiter.nextElement();
					double eFT=FT.get(prejb);
					if(eFT>EStime)
					{
						EStime=eFT;
					}
				}
			}
			IMode EFmode=schedule.getSeledMode(tempjb);//�������ģ̬
		
			ArrayList<IMode> modes=tempjb.getModes();
			if(EFmode!=null)//����û��ģ̬�Ѿ�Ԥ��ȷ����
			{
				modes=new ArrayList<IMode>();
				modes.add(EFmode);
			}
			double EFTime=-1;
			for(int j=0;j<modes.size();j++)
			{
				IMode tempmode=modes.get(j);
				double duration=tempmode.getDurationDouble();
				if(EFTime==-1||EStime+duration<EFTime)
				{
					EFTime=EStime+duration;
					EFmode=tempmode;
				}
			}
			if(EFmode!=null)
			{
				FT.put(tempjb, EFTime);
			}
			else
			{
				FT.put(tempjb, EStime);
			//	Clog.LogInfo("GenerateEarliestFinishSchedule������Ŀû�п��е��ȣ�");
				//return null;
			}
		}
		return FT;
	}
	/**
	 * ���� order strength
	 * @param pj
	 * @return
	 */
	public static double CaculateOrderStrength(IProject pj,int nodenum)
	{
		int[] connections=new int[nodenum+1];
		Hashtable<Integer,HashSet<Integer>> arrivetable=new Hashtable<Integer,HashSet<Integer>>();
		int maxconnection=((nodenum-2)*(nodenum-3))/2;
		for(int i=nodenum-1;i>=2;i--)
		{
			IJob tempjb=pj.getJbindextable().get(i);
			HashSet<Integer> arriveset=new HashSet<Integer>();
			int surcount=0;
			if(tempjb.getSuccessor()!=null)
			{
				Enumeration<IJob> sureiter=tempjb.getSuccessor().elements();
				while(sureiter.hasMoreElements())
				{
					IJob surjb=sureiter.nextElement();
					if(!surjb.equals(pj.getEndjb()))
					{
						HashSet<Integer> surarrive=arrivetable.get(surjb.getInerIndex());
						Iterator<Integer> arriveiter=surarrive.iterator();
						while(arriveiter.hasNext())
						{
							Integer arrivejb=arriveiter.next();
							if(!arriveset.contains(arrivejb))
							{
								arriveset.add(arrivejb);
							}
						}
						if(!arriveset.contains(surjb.getInerIndex()))
						{
							arriveset.add(surjb.getInerIndex());
						}
					}
				}
			}
			arrivetable.put(i, arriveset);
		}
		int totalconnection=0;
		for(int i=nodenum-1;i>=2;i--)
		{
			HashSet<Integer> surarrive=arrivetable.get(i);
			totalconnection+=surarrive.size();
		}
		
		double os=Double.valueOf(totalconnection)/maxconnection;
		if(os>1)
		{
			Clog.LogInfo("os>1");
		}
		return os;
	}
	/**
	 * ÿ���ѡ������˵�ģ̬,Schedule�п�����Щ���ģ̬�Ѿ�ȷ��,�����Ƿ���Ŀ���ʱ������
	 * @param pj
	 * @param schedule
	 * @param EFT
	 * @param EST
	 * @return
	 */
	public static boolean GenerateCheapestSchedule(IProject pj,Schedule schedule,Hashtable<IJob,Double> EFT,Hashtable<IJob,Double> EST)
	{
		int jobcount=pj.getJobNumber();
		for(int i=1;i<=jobcount;i++)
		{
			IJob tempjb=pj.getJbindextable().get(i);
			/**
			 * �����翪ʼʱ��
			 */
			double EStime=0;
			if(tempjb.getPredecessor()!=null)
			{
				Enumeration<IJob> predeiter=tempjb.getPredecessor().elements();
				while(predeiter.hasMoreElements())
				{
					IJob prejb=predeiter.nextElement();
					double eFT=EFT.get(prejb);
					if(eFT>EStime)
					{
						EStime=eFT;
					}
				}
			}
			EST.put(tempjb, EStime);
			IMode Cheapmode=schedule.getSeledMode(tempjb);//�������ģ̬
		
			ArrayList<IMode> modes=tempjb.getModes();
			if(Cheapmode!=null)//����û��ģ̬�Ѿ�Ԥ��ȷ����
			{
				modes=new ArrayList<IMode>();
				modes.add(Cheapmode);
			}
			double EFTime=-1;
			double cheapcost=-1;
			for(int j=0;j<modes.size();j++)
			{
				IMode tempmode=modes.get(j);
				double duration=tempmode.getDurationDouble()+tempmode.getTransferTime();
				double cost=tempmode.getCost();
				if(cheapcost==-1||cost<cheapcost)
				{
					EFTime=EStime+duration;
					Cheapmode=tempmode;
					cheapcost=cost;
				}
			}
			if(Cheapmode!=null)
			{
				schedule.setSeledMode(tempjb, Cheapmode);
				EFT.put(tempjb, EFTime);
			}
			else
			{
				EFT.put(tempjb, EStime);
				//Clog.LogInfo("GenerateEarliestFinishSchedule������Ŀû�п��е��ȣ�");
				//return false;
			}
		}
		return true;
	}
	private static Date basedate=new Date();
	public static String GetGuid()
	{
		Date d=new Date();
		while(!d.after(basedate))
		{
			d=new Date();
		}
		basedate=d;
		return String.valueOf(d.getTime());
		
	}
	public static boolean EqualDouble(double a,double b,int digital)
	{
		double gap=a-b;
		
		if(Math.abs(gap)>Math.pow(10, digital))
		{
			return false;
		}
		else
			return true;
	}
	public static boolean EqualLessDouble(double a,double b,int digital)
	{
		if(a<b)
			return true;
		double gap=a-b;
		
		if(Math.abs(gap)>Math.pow(10, digital))
		{
			return false;
		}
		else
			return true;
	}
	public static boolean LessDouble(double a,double b,int digital)
	{
		double gap=a-b;
		if(Math.abs(gap)>Math.pow(10, digital))
		{
			if(a<b)
				return true;
			else
				return false;
		}
		else
			return false;
	}
}
