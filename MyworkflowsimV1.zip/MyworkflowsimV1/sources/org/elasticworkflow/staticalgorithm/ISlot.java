package org.elasticworkflow.staticalgorithm;

public interface ISlot {
	/**
	 * ��ʼʱ��
	 */
	public int getStartTime();
	public void setStartTime(int stime);
	/**
	 * ����ʱ��
	 */
	public int getEndTime();
	public void setEndTime(int etime);
	/**
	 * ��ʼʱ��double
	 */
	public double getStartTimeDouble();
	public void setStartTimeDouble(double stime);
	/**
	 * ����ʱ��double
	 */
	public double getEndTimeDouble();
	public void setEndTimeDouble(double etime);
	
	public double getDatatransfertime();
	public void setDatatransfertime(double datatransfertime);
	
	public String getTransferedfiles();
	public void setTransferedfiles(String transferedfiles);
}
