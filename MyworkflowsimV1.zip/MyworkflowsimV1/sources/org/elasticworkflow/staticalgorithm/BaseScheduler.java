package org.elasticworkflow.staticalgorithm;

import java.util.Map;

import org.cloudbus.cloudsim.DatacenterCharacteristics;

public abstract class BaseScheduler {

	/**
	 * ��������
	 */
	public ServerInstancePool spool=null;
	/**
	 * �������
	 */
	public RequestQueue rqque=null;
	/**
	 * ʱ���źŴ�����һ������
	 */
	public abstract void  ClockJump(long time,Map<Integer, DatacenterCharacteristics> datacenterCharacteristicsList);
	 /**
	  * 
	  * @param tpool
	  * @param tqueue
	  */
	 public BaseScheduler(ServerInstancePool tpool,RequestQueue tqueue)
	 {
		 spool=tpool;
		 rqque=tqueue;
	 }
	 public abstract ISlot  getScheduleInfo(WorkflowRequest req, IJob jb);
}
