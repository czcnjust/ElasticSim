package org.elasticworkflow.staticalgorithm;

import org.cloudbus.cloudsim.Log;

public class Clog {
	private static boolean enable=true;
	public static boolean isEnable() {
		return enable;
	}
	public static void setEnable(boolean enable) {
		Clog.enable = enable;
	}
	/**
	 * ��¼�쳣
	 * @param e
	 */
	public static void LogError(String strmessage,Exception e)
	{
		Log.printLine(strmessage+"::"+e.getMessage());
		
	}
	/**
	 * ��¼��־
	 * @param strmessage
	 */
	public static void LogInfo(String strmessage)
	{
		if(enable)
			Log.printLine(strmessage);
	}
}
