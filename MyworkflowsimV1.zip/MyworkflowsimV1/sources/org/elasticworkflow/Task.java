
package org.elasticworkflow;

import java.util.ArrayList;
import java.util.List;
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Consts;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.elasticworkflow.stochasticruntime.*;
import org.elasticworkflow.intervalpricing.*;

public class Task extends Cloudlet {

	private Cluster cluster;
	private long cloudletlengthbackup=-1;
	private RuntimeDistribution distributeobj=null;//ִ��ʱ��ֲ�
	private IntervalPricingVM avm;
	public RuntimeDistribution getDistributeobj() {
		return distributeobj;
	}
	public void setDistributeobj(RuntimeDistribution distributeobj) {
		this.distributeobj = distributeobj;
	}
	public Cluster getCluster() {
		return cluster;
	}
	public void setCluster(Cluster cluster) {
		this.cluster = cluster;
	}
	/**
	 * ����������
	 * @return
	 */
	public IntervalPricingVM getAvm() {
		return avm;
	}
	/**
	 * ���÷���������
	 * @param avm
	 */
	public void setAvm(IntervalPricingVM avm) {
		this.avm = avm;
	}

	private double estimatedlength;
	private WorkflowInstance parent;
	/**
	 * Toplogy index of tasks in the workflow
	 */
	private int index;
    public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public WorkflowInstance getParent() {
		return parent;
	}

	public double getEstimatedlength() {
		return estimatedlength;
	}

	public void setEstimatedlength(double estimatedlength) {
		this.estimatedlength = estimatedlength;
	}

	public void setParent(WorkflowInstance parent) {
		this.parent = parent;
	}
    public boolean RecoveryCloudletlength()
    {
    	if(this.cloudletlengthbackup==-1)
    		return false;
    	this.setCloudletLength(this.cloudletlengthbackup);
    	return true;
    }
	/*
     * The list of parent tasks. 
     */
    private List<Task> parentList;
    /*
     * The list of child tasks. 
     */
    private List<Task> childList;
    /*
     * The list of all files (input data and ouput data)
     */
    private List<FileItem> fileList;
    
    private double totalfilesize=0;
    
    public double getTotalfilesize() {
		return totalfilesize;
	}

	/**
     * �����ֹ��ʱ�õ���
     */
    private double Floatduration=0;
    public double getFloatduration() {
		return Floatduration;
	}

	public void setFloatduration(double floatduration) {
		Floatduration = floatduration;
	}

	public double getTaskdeadline() {
		return taskdeadline;
	}

	public void setTaskdeadline(double taskdeadline) {
		this.taskdeadline = taskdeadline;
	}

	/**
     * The deadline of this task
     * @author Zhicheng Cai
     */
    private double taskdeadline;
    /*
     * The priority used for research. Not used in current version. 
     */
    private int priority;
    /*
     * The depth of this task. Depth of a task is defined as the furthest path 
     * from the root task to this task. It is set during the workflow parsing 
     * stage. 
     */
    private int depth;
    /*
     * The impact of a task. It is used in research. 
     */
    private double impact;

    /*
     * The type of a task. 
     */
    private String type;
    
    
    /**
     * Name of the task
     */
    private String Taskname;

    public String getTaskname() {
		return Taskname;
	}

	/**
     * The finish time of a task (Because cloudlet does not allow WorkflowSim to
     * update finish_time)
     */
    private double taskFinishTime;

    /**
     * Allocates a new Task object. The task length should be greater than or
     * equal to 1.
     *
     * @param taskId the unique ID of this Task
     * @param taskLength the length or size (in MI) of this task to be executed
     * in a PowerDatacenter
     * @pre taskId >= 0
     * @pre taskLength >= 0.0
     * @post $none
     */
    public Task(
            final int taskId,
            final long taskLength) {
        /**
         * We do not use cloudletFileSize and cloudletOutputSize here. We have
         * added a list to task and thus we don't need a cloudletFileSize or
         * cloudletOutputSize here The utilizationModelCpu, utilizationModelRam,
         * and utilizationModelBw are just set to be the default mode. You can
         * change it for your own purpose.
         */
        super(taskId, taskLength, 1, 0, 0, new UtilizationModelFull(), new UtilizationModelFull(), new UtilizationModelFull());

        this.childList = new ArrayList<>();
        this.parentList = new ArrayList<>();
        this.fileList = new ArrayList<>();
        this.impact = 0.0;
        this.taskFinishTime = -1.0;
      //  this.Taskname=Taskname;
        this.cloudletlengthbackup=taskLength;
    }

    public void setTaskname(String taskname) {
		Taskname = taskname;
	}

	/**
     * Sets the type of the task
     *
     * @param type the type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the type of the task
     *
     * @return the type of the task
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the priority of the task
     *
     * @param priority the priority
     */
    public void setPriority(int priority) {
        this.priority = priority;
    }

    /**
     * Sets the depth of the task
     *
     * @param depth the depth
     */
    public void setDepth(int depth) {
        this.depth = depth;
    }

    /**
     * Gets the priority of the task
     *
     * @return the priority of the task
     * @pre $none
     * @post $none
     */
    public int getPriority() {
        return this.priority;
    }

    /**
     * Gets the depth of the task
     *
     * @return the depth of the task
     */
    public int getDepth() {
        return this.depth;
    }

    /**
     * Gets the child list of the task
     *
     * @return the list of the children
     */
    public List<Task> getChildList() {
        return this.childList;
    }

    /**
     * Sets the child list of the task
     *
     * @param list, child list of the task
     */
    public void setChildList(List<Task> list) {
        this.childList = list;
    }

    /**
     * Sets the parent list of the task
     *
     * @param list, parent list of the task
     */
    public void setParentList(List<Task> list) {
        this.parentList = list;
    }

    /**
     * Adds the list to existing child list
     *
     * @param list, the child list to be added
     */
    public void addChildList(List<Task> list) {
        this.childList.addAll(list);
    }

    /**
     * Adds the list to existing parent list
     *
     * @param list, the parent list to be added
     */
    public void addParentList(List<Task> list) {
        this.parentList.addAll(list);
    }

    /**
     * Gets the list of the parent tasks
     *
     * @return the list of the parents
     */
    public List<Task> getParentList() {
        return this.parentList;
    }

    /**
     * Adds a task to existing child list
     *
     * @param task, the child task to be added
     */
    public void addChild(Task task) {
        this.childList.add(task);
    }

    /**
     * Adds a task to existing parent list
     *
     * @param task, the parent task to be added
     */
    public void addParent(Task task) {
        this.parentList.add(task);
    }

    /**
     * Gets the list of the files
     *
     * @return the list of files
     * @pre $none
     * @post $none
     */
    public List<FileItem> getFileList() {
        return this.fileList;
    }

    /**
     * Adds a file to existing file list
     *
     * @param file, the file to be added
     */
    public void addFile(FileItem file) {
        this.fileList.add(file);
        this.totalfilesize=0;
        for(FileItem cfile:fileList)
		{
        	this.totalfilesize+=cfile.getSize();
		}
    }

    /**
     * Sets a file list
     *
     * @param list, the file list
     */
    public void setFileList(List<FileItem> list) {
        this.fileList = list;
        this.totalfilesize=0;
        for(FileItem file:fileList)
		{
        	this.totalfilesize+=file.getSize();
		}
    }

    /**
     * Sets the impact factor
     *
     * @param impact, the impact factor
     */
    public void setImpact(double impact) {
        this.impact = impact;
    }

    /**
     * Gets the impact of the task
     *
     * @return the impact of the task
     * @pre $none
     * @post $none
     */
    public double getImpact() {
        return this.impact;
    }

    /**
     * Sets the finish time of the task (different to the one used in Cloudlet)
     *
     * @param time finish time
     */
    public void setTaskFinishTime(double time) {
        this.taskFinishTime = time;
    }

    /**
     * Gets the finish time of a task (different to the one used in Cloudlet)
     *
     * @return
     */
    public double getTaskFinishTime() {
        return this.taskFinishTime;
    }

    /**
     * Gets the total cost of processing or executing this task The original
     * getProcessingCost does not take cpu cost into it also the data file in
     * Task is stored in fileList <tt>Processing Cost = input data transfer +
     * processing cost + output transfer cost</tt> .
     *
     * @return the total cost of processing Cloudlet
     * @pre $none
     * @post $result >= 0.0
     */
    @Override
    public double getProcessingCost() {
        // cloudlet cost: execution cost...

        double cost = getCostPerSec() * getActualCPUTime();

        // ...plus input data transfer cost...
        long fileSize = 0;
        for (FileItem file : getFileList()) {
            fileSize += file.getSize() / Consts.MILLION;
        }
        cost += costPerBw * fileSize;
        return cost;
    }
}
