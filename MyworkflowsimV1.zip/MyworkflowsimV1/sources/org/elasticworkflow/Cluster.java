package org.elasticworkflow;
import java.util.ArrayList;
import java.util.HashSet;;
public class Cluster {

	
	public Cluster(String tasktype, int depth) {
		super();
		this.tasktype = tasktype;
		this.depth = depth;
	}
	/**
	 * ��������
	 */
	private String tasktype;
	/**
	 * �������
	 */
	private int depth;
	/**
	 * ���񼯺�
	 */
	private ArrayList<Task> tasklist=new ArrayList<Task>();
	public ArrayList<Task> getTasklist() {
		return tasklist;
	}
	public String getKey()
	{
		return tasktype+"_"+depth;
	}
	public boolean AddTask(Task tsk)
	{
		if(tsk.getDepth()==this.depth&&tsk.getType().equalsIgnoreCase(tasktype))
		{
			tsk.setCluster(this);
			tasklist.add(tsk);
			return true;
		}
		else
			return false;
			
	}
}
