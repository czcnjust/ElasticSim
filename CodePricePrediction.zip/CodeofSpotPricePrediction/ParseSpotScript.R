f<-1;i<-1 
L<-length(json_data$SpotPriceHistory)
for(i in 1:L){
f[L+1-i]<-json_data$SpotPriceHistory[[i]]$SpotPrice
i<-i+1
}
fsamp<-1;i<-1;
k<-1;
count<-0;
for(i in 1:L){
     count<-count+1;
     if(count==60)
     {
		fsamp[k]<-max(f[(i-59):i]);
		k<-k+1;
           count<-0;
     } 
}