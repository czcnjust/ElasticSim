package cn.edu.njust.fpm

import cn.edu.njust.fpm.FPGrowth._

import org.apache.spark.rdd.RDD
import org.apache.spark.storage._
import org.apache.spark.internal.Logging
import org.apache.spark.{HashPartitioner, Partitioner, SparkContext, SparkException}
import scala.reflect.ClassTag
import scala.collection._
import java.{ util => ju }

class FPGrowth (
  private var minSupport: Double,
  private var numPartitions: Int) extends Logging with Serializable {
  
  def this() = this(0.3, -1)

  def setMinSupport(minSupport: Double): this.type = {
    require(minSupport >= 0.0 && minSupport <= 1.0,
      s"Minimal support level must be in range [0, 1] but got ${minSupport}")
    this.minSupport = minSupport
    this
  }

  def setNumPartitions(numPartitions: Int): this.type = {
    require(numPartitions > 0,
      s"Number of partitions must be positive but got ${numPartitions}")
    this.numPartitions = numPartitions
    this
  }

  /**
   * Computes an FP-Growth model that contains frequent itemsets.
   * @param data input data set, each element contains a transaction
   * @return an [[FPGrowthModel]]
   *
   */
  def run[Item: ClassTag](data: RDD[Array[Item]]): FPGrowthModel[Item] = {
    if (data.getStorageLevel == StorageLevel.NONE) {
      logWarning("Input data is not cached.")
    }
    val count = data.count()
    val minCount = math.ceil(minSupport * count).toLong
    //获取分区数
    val numParts = if (numPartitions > 0) numPartitions else data.partitions.length 
    //创建HashPartitioner分区
    val partitioner = new HashPartitioner(numParts)
    //生成频繁项
    val freqItems = genFreqItems(data, minCount, partitioner)
    //生成频繁项集
    val freqItemsets = genFreqItemsets(data, minCount, freqItems, partitioner)
    freqItemsets.persist(StorageLevel.DISK_ONLY)
    //生成FPGrowthModel
    new FPGrowthModel(freqItemsets)
  }


  /**
   * 计算满足最小支持度的Items项
   * 统计每个Items项的频次，对于小于minCount的Items项过滤，返回Items项
   * @return Array[freItem]  
   */
  private def genFreqItems[Item: ClassTag](
      data: RDD[Array[Item]],
      minCount: Long,
      partitioner: Partitioner): Array[Item] = {
    data.flatMap { t =>
      val uniq = t.toSet
      if (t.length != uniq.size) {  //判断单行元素是否有重复的项
        throw new SparkException(s"Items in a transaction must be unique but got ${t.toSeq}.")
      }
      t
    }.map(v => (v, 1L))
      .reduceByKey(partitioner, _ + _)  //将每一个item根据hash分配到各个分区，并求其频次
      .filter(_._2 >= minCount)
      .collect()
      .sortBy(-_._2)  //按频次降序排列
      .map(_._1)
  }

  /**
   * genFreqItemsets 计算频繁项集: 生成FP-Tree,挖掘FP-Tree
   * 在每个分区上进行操作,通过构建FP-Tree生成频繁项集
   * @return an RDD of (frequent itemset, count)
   */
  private def genFreqItemsets[Item: ClassTag](
      data: RDD[Array[Item]],
      minCount: Long,
      freqItems: Array[Item],
      partitioner: Partitioner): RDD[FreqItemset[Item]] = {
    val itemToRank = freqItems.zipWithIndex.toMap
    data.flatMap { 
      transaction => genCondTransactions(transaction, itemToRank, partitioner)
    }// RDD[Map(part: Int, Array[Int])]
    //对每个分区及其包含的所有事务,构建一棵FPTree
    .persist(StorageLevel.DISK_ONLY)
    .aggregateByKey(new FPTree[Int], partitioner.numPartitions)(  //生成FP-Tree
      (tree, transaction) => tree.add(transaction, 1L),  //一条事务作为只有一条分支的树
      (tree1, tree2) => tree1.merge(tree2))   //所有单分支树进行合并成为一颗树（各个分区分别进行这两个操作）
//    .persist(StorageLevel.DISK_ONLY)
    .flatMap { case (part, tree) =>
      //分别从各个分区对应树进行频繁模式抽取, FP-Tree挖掘频繁项
      tree.extract(minCount, x => partitioner.getPartition(x) == part)
    }
//    .persist(StorageLevel.DISK_ONLY)
    .map { case (ranks, count) =>
      new FreqItemset(ranks.map(i => freqItems(i)).toArray, count)
    }
  }

  /**
   * 将每条事务进行列切割，并分配给对应的哈希分区
   * @return  Map[Int, Array[Int]] --- Map(分区， 事务)
   */
  private def genCondTransactions[Item: ClassTag](
      transaction: Array[Item],
      itemToRank: Map[Item, Int],
      partitioner: Partitioner): mutable.Map[Int, Array[Int]] = {
    val output = mutable.Map.empty[Int, Array[Int]]
    //过滤掉非频繁项（若不存在于itemToRank，get() 返回None ,即空 ），只保留频繁项index
    val filtered = transaction.flatMap(itemToRank.get)
    //根据index进行快速排序，即为频度降序序列
    ju.Arrays.sort(filtered)
    val n = filtered.length
    var i = n - 1
    while (i >= 0) {
      val item = filtered(i)
      //获取item哈希映射所在分区index  (item%numPartitions)
      val part = partitioner.getPartition(item)
      if (!output.contains(part)) {
        //将项最大序列分配给对应分区，若已存在，无需再分配（项序列比之前的小）
        output(part) = filtered.slice(0, i + 1)
      }
      i -= 1
    }
    output
  }
}


object FPGrowth {
  
  //频繁项集模型
  class FreqItemset[Item]  (
     val items: Array[Item],
     val freq: Long) extends Serializable {

    override def toString: String = {
      s"${items.mkString("{", ",", "}")}: $freq"
    }
  }
}

