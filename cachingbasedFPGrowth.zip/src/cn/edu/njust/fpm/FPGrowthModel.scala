package cn.edu.njust.fpm

import cn.edu.njust.fpm.FPGrowth._

import org.apache.spark.{HashPartitioner, Partitioner, SparkContext, SparkException}
import org.apache.spark.rdd.RDD
import scala.reflect.ClassTag
import scala.collection._
import scala.reflect.api.JavaUniverse
import java.{ util => ju }

import org.json4s.DefaultFormats
import org.json4s.JsonDSL._
import org.json4s.jackson.JsonMethods.{compact, render}

/**
 * FPGrowth 模型
 */
class FPGrowthModel[Item: ClassTag] (
    //FPGrowth 的频繁项集
  val freqItemsets: RDD[FreqItemset[Item]]) 
  extends Serializable {
  
  def generateAssociationRules(confidence: Double): RDD[AssociationRules.Rule[Item]] = {
    val associationRules = new AssociationRules(confidence)
    associationRules.run(freqItemsets)
  }
}
object FPGrowthModel {

}