package cn.edu.njust.fpm


import scala.collection.mutable
import scala.collection.mutable.ListBuffer

class FPTree[T] extends Serializable {

  import FPTree._

  val root: Node[T] = new Node(null)

  private val summaries: mutable.Map[T, Summary[T]] = mutable.Map.empty

  //树增加事务
  def add(t: Iterable[T], count: Long = 1L): this.type = {
    require(count > 0)
    var curr = root
    curr.count += count
    
     /**
     * 可以将一个transaction看作树的一个分枝
     * 接下来就是将这个分枝添加到树中，对应层上有包含相同item的Node时就只更新count
     * 没有就要生成新的结点。。。
     */
    t.foreach { item =>
      val summary = summaries.getOrElseUpdate(item, new Summary) //如果item在树中已经存在，获取其结点链，否则生成一个
      summary.count += count
      //首先从当前结点的孩子结点中看item是否存在,存在则获取该节点
      val child = curr.children.getOrElseUpdate(item, { 
        //如果不存在，生成一个新的以curr为父结点的newNode，并加入curr数组，并返回该节点
        val newNode = new Node(curr)
        newNode.item = item
        summary.nodes += newNode
        newNode
      })
      child.count += count
      //以并入树的item节点为当前结点，向下t遍历
      curr = child
    }
    this
  }

  //树合并
  def merge(other: FPTree[T]): this.type = {
    other.transactions.foreach { case (t, c) =>
      add(t, c)
    }
    this
  }

  /**
   * 取后缀树
   * 以事务中某项item为后缀，向上遍历FPTree
   * 得到一颗以包含item的Node为叶子结点的子树
   * 但是该方法是从item的父结点开始的，所以子树中不包含item
   * 这是因为extract方法中递归提取的原因
   */
  private def project(suffix: T): FPTree[T] = {
    val tree = new FPTree[T]
    if (summaries.contains(suffix)) { //判断结点链中是否包含该后缀项
      val summary = summaries(suffix) //获取该suffix对应的结点链
      summary.nodes.foreach { node =>
        var t = List.empty[T]
        var curr = node.parent //从父结点开始
        while (!curr.isRoot) { //一直向上遍历直到根结点
          t = curr.item :: t
          curr = curr.parent
        }
        //t中是一条以item为结点的分枝
        tree.add(t, node.count)
      }
    }
    tree
  }
  def transactions: Iterator[(List[T], Long)] = getTransactions(root)
  //取该节点下所有事务
  private def getTransactions(node: Node[T]): Iterator[(List[T], Long)] = {
    var count = node.count
    node.children.iterator.flatMap { case (item, child) =>
      getTransactions(child).map { case (t, c) =>
        count -= c
        (item :: t, c)
      }
    } ++ {
      if (count > 0) {
        Iterator.single((Nil, count))
      } else {
        Iterator.empty
      }
    }
  }

  
  /**
   * 提取频繁项集
   * 分别以summaries一个item为后缀，递归输出所有的频繁项
   */
  def extract(
      minCount: Long,
      validateSuffix: T => Boolean = _ => true): Iterator[(List[T], Long)] = {
    summaries.iterator.flatMap { case (item, summary) =>   //每一项和它对应结点链
      
      /**
       * validateSuffix只在第一次进行判断，判断该item是否属于FPTree对应的分区part
       * 在FPGrowth的genFreqItemSets方法中，可以看到一行代码 tree.extract(minCount, x=> partitioner.getPartition(x) == part)
       * PFP算法中将所有item进行组划分，假设有3组。那么每个item都有一个组号，在spark中是分区号。
       * 另外，每组都对应着一颗FPTree，对每一组的FPTree提取频繁模式的时候，
       * 只能以属于该组的那些项items为后缀来提取，不属于该分区的则忽略
       * 但是提取过程中是不需要再判断的
       */
      if (validateSuffix(item) && summary.count >= minCount) {
        Iterator.single((item :: Nil, summary.count)) ++  //单item为频繁一项集中的一个
          project(item).extract(minCount).map { case (t, c) =>  //递归的抽取item所在分枝上所有大于minCount的项集
            (item :: t, c)
          }
      } else {
        Iterator.empty
      }
    }
  }
}

object FPTree {

  /**
   * FP-Tree 的节点类
   */
  class Node[T](
      //该节点的父节点，即为参数也为属性
      val parent: Node[T]) extends Serializable {
    var item: T = _   //节点中包含的item
    var count: Long = 0L  //对应的计数
    
    /**
     * children表示孩子结点，用一个item->Node[item]的映射表示
     * 根据FPTree的特点，一个结点的孩子结点中包含的项item肯定是互不相同的；
     * 或者一个item在树的每一层最多只能出现一次，在树的每个分枝也只可能出现一次
     */
    val children: mutable.Map[T, Node[T]] = mutable.Map.empty

    //判断是否到达根节点
    def isRoot: Boolean = (parent == null)
  }

  /**
   * 同一个项item对应的结点链
   */
  private class Summary[T] extends Serializable {
    var count: Long = 0L  //item(商品)在数据样本（transactions）中出现的次数
    val nodes: ListBuffer[Node[T]] = ListBuffer.empty   //FPTree中包该item的所有结点列表
  }
}
