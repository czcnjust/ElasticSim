package cn.edu.njust.fpm


import org.apache.spark.internal.Logging
import org.apache.spark.api.java
import org.apache.spark.rdd.RDD
import org.apache.spark.{HashPartitioner, Partitioner, SparkContext, SparkException}
import scala.reflect.ClassTag
import scala.collection._
import cn.edu.njust.fpm.FPGrowth._
import cn.edu.njust.fpm.AssociationRules._
import org.apache.spark.storage.StorageLevel


class AssociationRules (
    private var minConfidence: Double) extends Logging with Serializable{

   def this() = this(0.8)
   
   //设置最小置信度
   def setMinConfidence(minConfidence: Double): this.type = {
    require(minConfidence >= 0.0 && minConfidence <= 1.0,
      s"Minimal confidence must be in range [0, 1] but got ${minConfidence}")
    this.minConfidence = minConfidence
    this
  }
   //AssociationRules 入口函数
  def run[Item: ClassTag](freqItemsets: RDD[FreqItemset[Item]]): RDD[Rule[Item]] = {
    // 生成 (X, X_freq)  用来作为前项频度  （显然生成的RDD有很多 的Seq[Item] 包括下面可作为前项的X
    //RDD[FreqItemset[Item]] -map-> RDD((Seq[Item], Long))
    val freqAntecedentMap = freqItemsets.map(x => (x.items.toSeq, x.freq))
    freqAntecedentMap.count()
    //候选规则 X => Y 生成 (X, (Y, freq(X union Y)))  
    //RDD[FreqItemset[Item]] -flatMap->  RDD[(Seq[Item], (Seq[Item], Long))]
    val candidates = freqItemsets.flatMap { itemset =>
      val items = itemset.items
      items.flatMap { item =>
        items.partition(_ == item) match {
          case (consequent, antecedent) if !antecedent.isEmpty =>
            Some((antecedent.toSeq, (consequent.toSeq, itemset.freq)))
          case _ => None
        }
      }
    } 
    // Join to get (X, ((Y, freq(X union Y)), freq(X))), generate rules, and filter by confidence
    val result = candidates.join(freqAntecedentMap).map { 
      case (antecendent, ((consequent, freqUnion), freqAntecedent)) =>
      new Rule(antecendent.toArray, consequent.toArray, freqUnion, freqAntecedent)
    }.filter(_.confidence >= minConfidence)
    result.count()
    result
  }
}

object AssociationRules {
  class Rule[Item] (
      val antecedent: Array[Item], //前项X
      val consequent: Array[Item], //后项Y
      freqUnion: Double,           // X union Y 频度
      freqAntecedent: Double       // X 频度
      ) extends Serializable {
    /**
     * Returns the confidence of the rule.
     *
     */
    def confidence: Double = freqUnion.toDouble / freqAntecedent
    
    require(antecedent.toSet.intersect(consequent.toSet).isEmpty, {
      val sharedItems = antecedent.toSet.intersect(consequent.toSet)
      s"A valid association rule must have disjoint antecedent and " +
        s"consequent but ${sharedItems} is present in both."
    })

    override def toString: String = {
      s"${antecedent.mkString("{", ",", "}")} => " +
        s"${consequent.mkString("{", ",", "}")}: ${confidence}"
    }
  }
}