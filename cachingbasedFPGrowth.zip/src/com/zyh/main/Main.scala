package com.zyh.main

import cn.edu.njust.fpm.FPGrowth
import org.apache.spark.rdd.RDD
import org.apache.spark.SparkConf 
import org.apache.spark.SparkContext 
import org.apache.spark.storage._

object Main {
  
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf() 
    val sc = new SparkContext(conf) 
    //最小支持度
    val minSupport = args(0).toDouble
    //最小置信度
    val minConfidence = args(1).toDouble
    //数据分区数
    val numPartitions = args(2).toInt
    //hdfs input url 
    val inputUrl = "hdfs://master:9000/data/"
    //hdfs out url 
    val outputUrl = "hdfs://master:9000/testOut/diskonly/" + args(3)
    //读取数据
    val data = sc.textFile(inputUrl + args(4),numPartitions)
    val user = sc.textFile(inputUrl + args(5),numPartitions)
    //转换为Int数组，并去重，更节省内存空间
    val transactions = data.map(line => line.trim.split(" ").map(_.toInt).distinct)
    transactions.persist(StorageLevel.DISK_ONLY)
    //用户购买记录Set
    val usrSet = user.map(line => line.trim.split(" ").map(_.toInt).distinct).map(_.toSet)
    //创建一个FPGrowth的算法实列,设置计算的最小支持度和数据分区
    val fpg = new FPGrowth().setMinSupport(minSupport).setNumPartitions(numPartitions)
    //获得FPGrowth计算结果
    val model = fpg.run(transactions)
    
    //推荐规则[前项, (后项, 置信度)]
    val AllAssociationRules = model.generateAssociationRules(minConfidence).map(x => (x.antecedent.toSet, (x.consequent, x.confidence)))
    AllAssociationRules.persist(StorageLevel.DISK_ONLY)
    //根据前项聚合产生的规则 [前项，[(后项，置信度)]]
    //不知道combineByKey是否平均分配到每个分区.repartition(numPartitions)
    val rulesList =AllAssociationRules.combineByKey(List(_), (x:List[(Array[Int], Double)], y:(Array[Int], Double)) => y :: x, (x:List[(Array[Int], Double)], y:List[(Array[Int], Double)]) => x ::: y)
    //保存关联规则与置信度[a,b] --> [ c : 0.9 ] | [ d : 0.8 ]
    rulesList.map(rule => (rule._1.mkString("[", ",", "]") + " --> " + rule._2.map(x => (x._1.mkString(",") + " : " + x._2.toString())).mkString("[", " | ", "]") )).saveAsTextFile(outputUrl+"rulesList") 
    
    //计算非聚合: 关联规则置信度到达minConfigdence即算作推荐项
    //并不需要聚合最高的RDD[(Set(前项),Array(后项))]
    val allRules = rulesList.map(rule => (rule._1, rule._2.reduceLeft((a, b) => (a._1 ++ b._1, a._2))._1))
    allRules.persist(StorageLevel.DISK_ONLY)
    //保存所有规则
    allRules.map(rule => rule._1.mkString("[", ",", "]") + " --> " + rule._2.mkString("[", ",", "]")).saveAsTextFile(outputUrl + "allRules")
    ///共享变量，使每个executor都缓存一份AllRules的所有集
    val broadcastAllRules = sc.broadcast(allRules.collect())
    //计算推荐项，去重过滤
    val userAllRecItems = usrSet.map(oneUser => (broadcastAllRules.value.filter(x => x._1.subsetOf(oneUser)), oneUser)).map(u => if(u._1.isEmpty) (Array(), u._2) else (u._1.flatMap(x => x._2).distinct , u._2)).map(t => (t._1.filter(e => !t._2.contains(e)), t._2))
    userAllRecItems.persist(StorageLevel.DISK_ONLY)
    val allresult = userAllRecItems.map(item => (item._1.mkString("[", ",", "]")))
    allresult.saveAsTextFile(outputUrl+"userAllRecItems")
   }
}