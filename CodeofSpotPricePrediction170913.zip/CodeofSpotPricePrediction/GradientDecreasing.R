GDTimeseriesModel<-function(fsamp, base, learnstep,monthorder=3, hourorder=23)
{
      temp<-fsamp[(base-hourorder):base];
       for(mo in 1:monthorder)
	{
		temp<-c(fsamp[base-mo*720],temp);
	}
	inputmatrix<-matrix(temp,nrow=1,byrow=T);
	base<-base+1;
	for(i in 1:learnstep)
	{
 		temp<-fsamp[(base-hourorder):base];
       	for(mo in 1:monthorder)
		{
			temp<-c(fsamp[base-mo*720],temp);
		}
		row1<-matrix(temp,nrow=1,byrow=T);
		inputmatrix<-rbind(inputmatrix,row1);
      	base<-base+1;
	}
	inputset<-data.frame(inputmatrix);
      print("/////////////////////////////////////training set")
      print(inputset);
	cl<- list(alpha = 0.001, maxIter = 20000, momentum = 0.9, batchRate = 0.9)
	modelObject <- gradDescentR.learn(inputset,learningMethod = "SGD",control=cl)
	GDTimeseriesModel<-list(modelObject=modelObject,monthorder=monthorder,hourorder=hourorder);
      return(GDTimeseriesModel);
}




SeasonARPredict<- function(GDTimeseriesModel, fsamp, period, current)
{
       input<-fsamp[(current-GDTimeseriesModel$hourorder+1):current];
       for(mo in 1:GDTimeseriesModel$monthorder)
	{
		input<-c(fsamp[current-mo*720],input);
	}
	inputmatrix<-matrix(c(input,0),nrow=1,byrow=T);
	inputrow<-data.frame(inputmatrix);
     	prediction_data <- predict(GDTimeseriesModel$modelObject, inputrow);
 	print(prediction_data);

      totalpredictedva<-prediction_data [1,"V1"];
      totaldata<-c(input,totalpredictedva);
      for(k in 2:period)
	{
       	current<-current+1;
 		input<-totaldata[(length(totaldata)-GDTimeseriesModel$hourorder+1):length(totaldata)]
       	for(mo in 1:GDTimeseriesModel$monthorder)
		{
			input<-c(fsamp[current-mo*720],input);
		}

      	inputmatrix<-matrix(c(input,0),nrow=1,byrow=T);
		      	
		inputrow<-data.frame(inputmatrix);
		prediction_data <- predict(GDTimeseriesModel$modelObject, inputrow);
      	totalpredictedva<-c(totalpredictedva,prediction_data [1,"V1"]);
		totaldata<-c(input,totalpredictedva);
		print(prediction_data);

      }
      print(totalpredictedva);
      return (totalpredictedva);
}
