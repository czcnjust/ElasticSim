These prices have been sampled by taking the maximum price of each minutes
In the experiment, these prices then be sampled again by taking the maximum of prices of each hour.